from linuxmusterTools.ldapconnector.urls import router as reader_router
from linuxmusterTools.ldapconnector.ldap_writer import ldap_writer


LMNLdapReader = reader_router
LMNLdapWriter = ldap_writer
