from linuxmusterTools.ldapconnector.urls import router

LMNLdapReader = router
