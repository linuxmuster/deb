from dataclasses import dataclass

@dataclass
class LMNSchool:
    ou: str
    displayName: str
    distinguishedName: str