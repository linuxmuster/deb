import os
import logging
import warnings
from collections import OrderedDict
from configparser import ConfigParser
from dataclasses import dataclass
from pathlib import Path

from linuxmusterTools.lmnfile import LMNFile


logger = logging.getLogger(__name__)

SOPHOMORIX_INI_PATH = "/usr/share/sophomorix/devel/sophomorix.ini"

# What an installation without COMPUTERROLE_DEFAULT is assumed to mean.
FALLBACK_DEFAULT_ROLE = 'classroom-studentcomputer'

class SchoolConfig:

    def __init__(self, school='default-school'):
        prefix = ""
        if school != 'default-school':
            prefix = f"{school}."
        sophomorix_config_path = f'/etc/linuxmuster/sophomorix/{school}/{prefix}school.conf'

        if os.path.isfile(sophomorix_config_path):
            with LMNFile(sophomorix_config_path, 'r') as config:
                self.config = config.read()
        else:
            logger.warning(f"No sophomorix school config found for the school {school}")
            self.config = {}

class MultiOrderedDict(OrderedDict):

    def __setitem__(self, key, value):
        if isinstance(value, list) and key in self:
            self[key].extend(value)
        else:
            super().__setitem__(key, value)

@dataclass(frozen=True)
class ComputerRoles:
    """
    What sophomorix.ini says about computer roles: the ones getting a
    machine account in the AD, the ones getting a DNS node only, and the one
    an empty role field means.

    Read by SophomorixIni into its computer_roles attribute, or built by hand
    to pin what a caller reads - a test, or a check run against an inventory
    coming from somewhere else.
    """

    accounts: tuple = ()
    dns_only: tuple = ()
    default: str = FALLBACK_DEFAULT_ROLE

    @property
    def roles(self):
        return self.accounts + self.dns_only

    def __contains__(self, role):
        return role in self.accounts or role in self.dns_only


class SophomorixIni:

    def __init__(self):
        self.path = SOPHOMORIX_INI_PATH
        self.data = ConfigParser(delimiters=("=",), dict_type=MultiOrderedDict, strict=False)
        self.data.read_string(self._read_expanded())
        self.sections = list(self.data.keys())

        self.dict = {}
        for section in self.sections:
            self.dict[section] = {}
            for key,value in self.data[section].items():
                self.dict[section][key] = self.sanitize(value)

        # Whether a computer role gets a real machine account in the AD, as
        # opposed to a DNS node only. This is what decides if the NetBIOS
        # limits apply to the hostname of a device: an account name is a
        # sAMAccountName, capped at 15 characters plus the trailing '$'.
        # https://learn.microsoft.com/en-us/troubleshoot/windows-server/active-directory/naming-conventions-for-computer-domain-site-ou
        accounts, dns_only = [], []
        for section in self.sections:
            if not section.startswith('computerrole.'):
                continue
            role = section.replace('computerrole.', '', 1)
            value = self.dict[section].get('computer_account')
            if value is None:
                logger.warning(
                    f"{section} has no COMPUTER_ACCOUNT in {self.path}, assuming FALSE"
                )
            if str(value).strip().upper() == 'TRUE':
                accounts.append(role)
            else:
                dns_only.append(role)

        # The role sophomorix substitutes for an empty role field.
        try:
            default = self.get('GLOBAL', 'COMPUTERROLE_DEFAULT')
        except KeyError:
            default = FALLBACK_DEFAULT_ROLE
            logger.warning(
                f"No COMPUTERROLE_DEFAULT in {self.path}, assuming {FALLBACK_DEFAULT_ROLE}"
            )

        self.computer_roles = ComputerRoles(tuple(accounts), tuple(dns_only), default)

        # TODO: should be loaded, not hardcoded
        self.clientrole = [
            'classroom-teachercomputer',
            'classroom-studentcomputer',
            'faculty-teachercomputer',
            'staffcomputer',
            'thinclient',
            'iponly',
        ]
        self.userrole = list(self.dict['ROLE_USER'].keys())

    def _read_expanded(self):
        """
        Read sophomorix.ini and expand its tabs.

        The file indents its keys with a tabulation in most sections and
        with eight spaces in others, sometimes within the same section.
        configparser reads a line indented deeper than the previous key as
        a continuation of its value, so a space indented key following a
        tab indented one is swallowed into the value above it: 53 keys of
        the shipped file are lost that way, the COMPUTER_ACCOUNT of all 15
        computer roles among them. Expanding tabs to eight columns puts
        both forms at the same level, and leaves genuine continuation
        lines - indented further than eight columns - untouched.

        :return: The content of the file, empty if it can not be read
        :rtype: str
        """


        try:
            return Path(self.path).read_text().expandtabs(8)
        except OSError as e:
            logger.warning(f"Could not read {self.path}: {e}")
            return ""

    @property
    def computerrole(self):
        """
        Deprecated, use computer_roles.roles.

        :return: Every computer role, 'computerrole.' prefix stripped
        :rtype: list
        """


        warnings.warn(
            "SophomorixIni.computerrole is deprecated, use SophomorixIni.computer_roles.roles",
            DeprecationWarning,
            stacklevel=2,
        )
        return list(self.computer_roles.roles)

    @staticmethod
    def sanitize(value):
        if '\n' in value:
            result = value.split('\n')
            for idx,v in enumerate(result):
                result[idx] = v.split("#")[0].strip()
            return result
        else:
            return value.split("#")[0].strip()

    def get(self, section, key):
        if section not in self.sections:
            raise KeyError(f"Section {section} not found in sophomorix.ini.")

        section = self.data[section]

        if key not in section:
            raise KeyError(f"Key {key} not found in the section {section} of sophomorix.ini.")

        return self.sanitize(section[key])


class SophomorixConf:

    def __init__(self):
        self.path = f'/etc/linuxmuster/sophomorix/sophomorix.conf'

        if os.path.isfile(self.path):
            with LMNFile(self.path, 'r') as config:
                self.data = config.data
        else:
            logger.warning(f"No sophomorix.conf found on the server.")
            self.data = {}
