from pathlib import Path

from ..lmnfile import LMNFile
from ..common.checks import NameChecker
from ..common.timestamps import get_utc_mtime
from ..lmnconfig import SophomorixIni

sophomorix_ini = SophomorixIni()
CLIENT_ROLES = sophomorix_ini.clientrole
COMPUTER_ROLES = sophomorix_ini.computerrole

name_checker = NameChecker()

class Devices:
    def __init__(self, school='default-school'):
        self.school = school
        self.switch(self.school)

    def switch(self, school):
        self.school = school
        if self.school != 'default-school':
            # Two different prefixes, do not mix them up: the inventory file
            # is <school>.devices.csv, while a host of that school is named
            # <school>-<hostname> everywhere it is seen from outside its own
            # school - sophomorix' own SCHOOLS.<school>.PREFIX.
            self.prefix = f'{self.school}.'
            self.hostname_prefix = f'{self.school}-'
        else:
            self.prefix = ''
            self.hostname_prefix = ''

        self.path = f'/etc/linuxmuster/sophomorix/{self.school}/{self.prefix}devices.csv'
        self.load()

    def load(self):
        self.devices = []

        try:
            with LMNFile(self.path, 'r') as devices_csv:
                for device in devices_csv.read():
                    if not device['room'].startswith('#'):
                        # TODO: special cases for linbo docker
                        device['school'] = self.school
                        device['mac'] = name_checker.normalize_mac(device['mac'])
                        device['pxeEnabled'] = self._check_pxe_flag(device)

                        self.devices.append(device)
        except FileNotFoundError:
            # No devices.csv yet, e.g. fresh install not provisioned yet
            pass

        self.groups = list(set([d['group'] for d in self.devices if d.get('group', False)]))
        self.macs = list(set([d['mac'] for d in self.devices if d.get('mac', False)]))
        self.ips = list(set([d['ip'] for d in self.devices if d.get('ip', False)]))
        self.rooms = list(set([d['room'] for d in self.devices if d.get('room', False)]))
        self.hostnames = list(set([d['hostname'] for d in self.devices if d.get('hostname', False)]))
        # Same hosts, named as anything school-agnostic writes them: LINBO
        # logs, hwinfo files, AD objects. Answers "is this host mine?" for a
        # caller holding a name that came from outside the school.
        self.prefixed_hostnames = {f'{self.hostname_prefix}{h}' for h in self.hostnames}
        self.clients = self.filter(roles=CLIENT_ROLES)
        self.csv_mtime = get_utc_mtime(Path(self.path)) # check if I can replace all paths with Path instances

    @staticmethod
    def _check_pxe_flag(device):
        pxeflag = device['pxeFlag'].strip()
        try:
            # If pxeflag is not provided, should be 0
            int_pxeflag = int(pxeflag) if pxeflag else 0
        except ValueError:
            int_pxeflag = 0

        return int_pxeflag > 0 and device['group'].lower() != "nopxe"

    def filter(self, roles=[], groups=[], macs=[]):
        """
        Filter the devices list per attributes.
        The filters roles and groups can be combined, but the filter macs must
        be used alone.
        """


        if roles and groups:
            return [device for device in self.devices if device['sophomorixRole'] in roles and device['group'] in groups]
        elif roles:
            return [device for device in self.devices if device['sophomorixRole'] in roles]
        elif groups:
            return [device for device in self.devices if device['group'] in groups]
        elif macs:
            macs_normalized = [name_checker.normalize_mac(mac) for mac in macs]
            return [
                device
                for device in self.devices
                if name_checker.normalize_mac(device['mac']) in macs_normalized]
        return self.devices

    def get_host(self, hostname, roles=[], groups=[]):
        for device in self.filter(roles, groups):
            if device['hostname'] == hostname:
                return device
        return None

    def get_hosts_by_macs(self, macs=[]):
        return self.filter(macs=macs)

    def get_client(self, hostname, groups=[]):
        return self.get_host(hostname, roles=CLIENT_ROLES, groups=groups)

    def get_clients(self, groups=[]):
        return self.filter(roles=CLIENT_ROLES, groups=groups)

    def check_conf(self):
        # TODO check
        # MS SOFTWARE KEYS ?
        # COMPUTER_ACCOUNT/HOST_GROUP/HOST_GROUP_TYPE flags ?

        report = []

        # Check values
        ip_rev = {}
        mac_rev = {}
        for device in self.devices:
            ip = device['ip']
            mac = device['mac']

            if ip in ip_rev:
                ip_rev[ip].append(device['hostname'])
            else:
                ip_rev[ip] = [device['hostname']]

            if mac in mac_rev:
                mac_rev[mac].append(device['hostname'])
            else:
                mac_rev[mac] = [device['hostname']]

            # Check values
            if not name_checker.check_ip_name(ip):
                report.append(f"{ip} is not a valid ip address")

            if not name_checker.normalize_mac(mac):
                report.append(f"{mac} is not a valid mac address")

            if not name_checker.check_group_name(device['group']):
                report.append(f"{device['group']} is not a valid Linbo group")

            if not name_checker.check_room_name(device['room']):
                report.append(f"{device['room']} is not a valid room name")

            if not name_checker.check_host_name(device['hostname']):
                report.append(f"{device['hostname']} is not a valid hostname")

            if device['pxeFlag'] not in ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']:
                report.append(f"{device['pxeFlag']} is not a valid pxe flag")

            if device['sophomorixRole'] not in COMPUTER_ROLES:
                report.append(f"{device['sophomorixRole']} is not a valid computer role")

        # Check uniqueness
        for ip, hosts in ip_rev.items():
            if len(hosts) > 1:
                report.append(f"{','.join(hosts)} have the same ip {ip}")

        for mac, hosts in mac_rev.items():
            if len(hosts) > 1:
                report.append(f"{','.join(hosts)} have the same mac {mac}")

        if report:
            return report

        return False




