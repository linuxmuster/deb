import os
import pwd
import re
import logging
import subprocess
from datetime import datetime

from ..samba_util import SAMBA_WORKGROUP, SAMBA_DOMAIN, SAMBA_NETBIOS, DFS, SHARES_LIST
from ..ldapconnector import LMNLdapReader as lr
from ..common import format_size


logger = logging.getLogger(__name__)

smbclient = None
SMBAuthenticationError = None


def _load_smb_bindings():
    """
    Import smbclient/smbprotocol on first use only, instead of at module
    import time: this pulls in spnego/gssapi/cryptography (~60ms in
    practice), and only the samba_root_tree()/samba_dir_size() family below
    actually needs it.
    """

    global smbclient, SMBAuthenticationError
    if smbclient is not None:
        return

    import smbclient as _smbclient
    from smbprotocol.exceptions import SMBAuthenticationError as _SMBAuthenticationError

    smbclient = _smbclient
    SMBAuthenticationError = _SMBAuthenticationError

def timestamp2date(t):
    return datetime.fromtimestamp(t).strftime("%Y-%m-%dT%H:%M:%S")

def _get_recursive_dir_properties(path):
    """
    Get properties of folder, and call itself recursively for subfolders.

    :param path: Current SAMBA path to scan
    :type path: basestring
    :return: Files, subfolders, and their size, last modified date.
    :rtype: dict
    """

    _load_smb_bindings()

    properties = {
            'name': path.split('/')[-1],
            'type': "directory",
            'size':0,
            'lastModified': timestamp2date(smbclient.stat(path).st_mtime),
            'contents': [],
            'path': path,
    }

    for item in smbclient.scandir(path):
        if item.is_file():
            stats = item.stat()
            properties['contents'].append({
                    'name': item.name,
                    'type': "file",
                    "path": f"{path}/{item.name}",
                    'size': stats.st_size,
                    'lastModified': timestamp2date(stats.st_mtime),
                }
            )

        elif item.is_dir():
            dir_path = f"{path}/{item.name}"
            properties['contents'].append(_get_recursive_dir_properties(dir_path))

    return properties

def _sum_dir_size(d):
    for item in d['contents']:
        if item["type"] == "file":
            d['size'] += item['size']
        else:
            d['size'] += _sum_dir_size(item)
    return d['size']

def samba_root_tree(user):
    """
    Recursively list files and folder of a school root share, with size and last-modified properties.
    This function can only be called with a valid kerberos ticket.

    :param user: LDAP User
    :type user: basestring
    :return: All folders and files owned by user
    :rtype: dict
    """

    _load_smb_bindings()

    try:
        school = lr.getval(f'/users/{user}', 'sophomorixSchoolname')
        path = f'//{SAMBA_NETBIOS}/{school}'
        directories = _get_recursive_dir_properties(path)
        directories['school'] = school
        _sum_dir_size(directories)
        return directories
    except SMBAuthenticationError as e:
        print(f"Please check if you have a valid Kerberos Ticket for the user {user}.")
        return None

def _samba_dir_size(user, path=None):
    _load_smb_bindings()

    if not path:
        # Scanning from root share
        school = lr.getval(f'/users/{user}', 'sophomorixSchoolname')
        path = f'//{SAMBA_NETBIOS}/{school}'

    total = 0
    for item in smbclient.scandir(path):
        if item.is_file():
            total += item.stat().st_size
        elif item.is_dir():
            total += _samba_dir_size(user, path=item.path)
    return total

def samba_dir_size(user, path=None, raw=False):
    size = _samba_dir_size(user, path)
    if raw:
        return size
    else:
        return format_size(size)

def list_user_files(user):
    path = '/srv/samba'
    user = f'{SAMBA_WORKGROUP}\\{user}'

    directories = {}

    for root, dirs, files in os.walk(path):
        for f in files:
            stats = os.stat(os.path.join(root, f))
            owner = pwd.getpwuid(stats.st_uid).pw_name
            size = stats.st_size
            if owner == user:
                for directory, _ in directories.items():
                    if root.startswith(directory):
                        directories[directory]['total'] += size
                        directories[directory]['files'][f] = f"{format_size(size)}"
                        break
                else:
                    directories[root] = {'total': size, 'files':{f: f"{format_size(size)}"}}

    total = 0
    for directory, details in directories.items():
        size = details['total']
        total += size
        directories[directory]['total'] = f"{format_size(size)}"

    return {'directories': directories, 'total': f"{format_size(total)}"}

def get_user_quotas(user):
    attributes =  lr.get(f'/users/{user}',
                             attributes=[
                                 'sophomorixCloudQuotaCalculated',
                                 'sophomorixMailQuotaCalculated',
                                 'sophomorixSchoolname',
                                 'sophomorixRole'
                             ])
    if not attributes:
        raise Exception(f'User {user} not found in ldap')

    if 'administrator' in attributes['sophomorixRole']:
        quotas = {share: None for share in SHARES_LIST}
    else:
        quotas = {
            attributes['sophomorixSchoolname']: None,
            'linuxmuster-global': None,
        }

    with open('/etc/linuxmuster/.secret/administrator', 'r') as adm_pw:
        pw = adm_pw.readline().strip()

    def _format_quota(quota):
        if "NO LIMIT" in quota:
            return quota
        return round(int(quota) / 1024 /1024, 2)

    # TODO: parallel ?
    for share in quotas.keys():
        # Search for DFS paths
        if share in DFS.keys():
            share_path = DFS[share]['dfs_proxy']
        else:
            # Default school
            share_path = f'//{SAMBA_DOMAIN}/{share}'

        cmd = ['smbcquotas', '-U', f'administrator%{pw}', '-u', user, share_path]
        smbc_output = subprocess.run(cmd, capture_output=True)
        out, err = smbc_output.stdout.decode().strip(),  smbc_output.stderr.decode().strip()
        if smbc_output.returncode > 0:
            # Catch Samba error
            # error_code =  err.split("(")[1].strip(")")
            error = f"""Can not get quota from {share}: 
    - Output: {out}
    - Returncode: {smbc_output.returncode}
    - Error: {err}"""

            logger.warning(error)
            quotas[share] = {'ERROR': {'output':out, 'error':err, 'code':smbc_output.returncode}}

        else:
            used, soft, hard = [value.strip("/") for value in re.split(r"\s{2,}", out)[2:]]
            quotas[share] = {
                "used": _format_quota(used),
                "soft_limit": _format_quota(soft),
                "hard_limit": _format_quota(hard),
            }

    pw = ''
    quotas['cloud'] = attributes['sophomorixCloudQuotaCalculated'][0].split()[0]
    quotas['mail'] = attributes['sophomorixMailQuotaCalculated'][0]

    return quotas