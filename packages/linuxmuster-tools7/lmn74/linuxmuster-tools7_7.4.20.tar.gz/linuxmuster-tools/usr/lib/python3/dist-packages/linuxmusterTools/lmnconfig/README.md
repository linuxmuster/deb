# lmnconfig

System configuration loader for [linuxmuster.net](https://www.linuxmuster.net), exposing Samba, sophomorix, setup, server and webui settings as ready-to-use Python constants and small config objects.

`lmnconfig` has no factory or single entry point: each submodule reads its own configuration source (`smb.conf`, `setup.ini`, `sophomorix.conf`, …) at import time or on instantiation, and everything is re-exported at the package level via `from linuxmusterTools.lmnconfig import ...`.

---

## Requirements

- Python 3.8+
- [`configobj`](https://pypi.org/project/configobj/)
- A configured Samba/AD server (`/etc/samba/smb.conf`, `net conf list`) for `samba.py`
- A running [linuxmuster.net](https://www.linuxmuster.net) setup for `setup.py` and `sophomorix.py` (`/var/lib/linuxmuster/setup.ini`, `/etc/linuxmuster/sophomorix/`)

---

## Usage

```python
from linuxmusterTools.lmnconfig import SAMBA_REALM, SAMBA_DOMAIN, LDAP_CONTEXT
```

### `samba.py` — module-level constants

Computed once at import time by parsing `/etc/samba/smb.conf` and the output of `net conf list`.

| Name | Type | Description |
|---|---|---|
| `SAMBA_REALM` | `str` | Kerberos realm, lowercased (`school.lan`) |
| `SAMBA_WORKGROUP` | `str` | Samba workgroup |
| `SAMBA_NETBIOS` | `str` | NetBIOS name, lowercased |
| `SAMBA_DOMAIN` | `str` | `f'{SAMBA_NETBIOS}.{SAMBA_REALM}'` |
| `SAMBA_TLD` | `str` | Top-level domain component of the realm, uppercased |
| `LDAP_DC` | `str` | Realm as LDAP `DC=` components (`DC=SCHOOL,DC=LAN`) |
| `LDAP_CONTEXT` | `str` | `f'OU=SCHOOLS,{LDAP_DC}'` |
| `LOG_LEVEL` | `dict` | Parsed `log level` directive, e.g. `{'general': 1, 'auth_audit': 3}` |
| `SHARES_LIST` | `list[str]` | All share names from `net conf list` |
| `DFS` | `dict` | Shares with `msdfs root = yes`, mapped to their `dfs_proxy` (UNC form) |

```python
from linuxmusterTools.lmnconfig import SAMBA_REALM, SAMBA_DOMAIN, LDAP_CONTEXT

print(SAMBA_DOMAIN)      # 'server.school.lan'
print(LDAP_CONTEXT)      # 'OU=SCHOOLS,DC=SCHOOL,DC=LAN'
```

`SHARES_LIST` and `DFS` are read from `net conf list` once, at import. A long running process like linuxmuster-api therefore keeps the shares it found at start: restart it after moving a share to a fileserver. `load_shares()` reads them again, updating both objects in place, so every module which imported them sees the new values. `quotas.get_user_quotas()` calls it once by itself when a share is not found at its known place.

```python
from linuxmusterTools.lmnconfig import DFS, load_shares

load_shares()
print(DFS)               # {'default-school': {'dfs_proxy': '\\\\file01.school.lan\\default-school'}}
```

If `/etc/samba/smb.conf` is missing or unreadable, the constants read from it default to `''` (or `{}`) and a warning/error is logged. `net conf list` is not guarded: if it fails (Samba not provisioned yet, process not running as root), importing the module raises `subprocess.CalledProcessError`.

### `server.py` — module-level constants

| Name | Type | Description |
|---|---|---|
| `SERVER_HOSTNAME` | `str` | Result of `socket.gethostname()` |
| `SERVER_IP` | `str` | First non-loopback IP of the server, or an error string if none is found. If the host name does not resolve, importing the module raises `socket.gaierror` |

### `setup.py` — `SetupConfig`

Reads `/var/lib/linuxmuster/setup.ini` (installer configuration).

```python
from linuxmusterTools.lmnconfig import SetupConfig

setup = SetupConfig(school='default-school')
setup.config['setup']['schoolname']
```

`config` is `{}` if the school is not `'default-school'` or the file does not exist.

### `sophomorix.py` — school and sophomorix configuration

```python
from linuxmusterTools.lmnconfig import SchoolConfig, SophomorixIni, SophomorixConf

school = SchoolConfig(school='default-school')
school.config['global']['SCHOOLNAME']

ini = SophomorixIni()
ini.get('ROLE_USER', 'teacher')
ini.userrole          # ['teacher', 'student', ...], keys of section ROLE_USER
ini.computer_roles     # ComputerRoles, see below
ini.clientrole         # hardcoded list of LINBO client roles

conf = SophomorixConf()
conf.data['global']['LANG']
```

| Class | Source file | Description |
|---|---|---|
| `SchoolConfig` | `/etc/linuxmuster/sophomorix/{school}/[{school}.]school.conf` | Per-school sophomorix settings, `.config` dict |
| `SophomorixIni` | `/usr/share/sophomorix/devel/sophomorix.ini` | Parsed sophomorix reference INI: roles, computer roles, sections |
| `SophomorixConf` | `/etc/linuxmuster/sophomorix/sophomorix.conf` | Global sophomorix settings, `.data` dict |
| `MultiOrderedDict` | — | `OrderedDict` variant used by `SophomorixIni`: re-assigning a list key extends it instead of overwriting it |

`SchoolConfig` and `SophomorixConf` fall back to an empty dict (`.config`/`.data` == `{}`) and log a warning if their file is missing. `SophomorixIni` logs a warning too, then raises `KeyError: 'ROLE_USER'`.

`SophomorixIni.computer_roles` is a frozen `ComputerRoles` dataclass: the `[computerrole.*]` sections, prefix stripped, split on their `COMPUTER_ACCOUNT` flag, in the order of the file.

| Attribute | Type | Content |
|---|---|---|
| `accounts` | `tuple[str]` | Roles getting a real machine account in the AD |
| `dns_only` | `tuple[str]` | Roles getting a DNS node only; a role declaring no `COMPUTER_ACCOUNT` lands here, with a warning |
| `default` | `str` | The role sophomorix substitutes for an empty role field (`COMPUTERROLE_DEFAULT` of `[GLOBAL]`); `classroom-studentcomputer` with a warning if the key is missing |
| `roles` | `tuple[str]` | Property: `accounts + dns_only` |

The split is what decides whether the NetBIOS limits apply to the hostname of a device — an account name is a `sAMAccountName`, [capped at 15 characters plus the trailing `$`](https://learn.microsoft.com/en-us/troubleshoot/windows-server/active-directory/naming-conventions-for-computer-domain-site-ou).

```python
>>> roles = SophomorixIni().computer_roles
>>> 'printer' in roles                # known role, in either tuple
True
>>> 'thinclient' in roles.accounts    # gets a machine account?
False
```

`ComputerRoles` can also be built by hand, to pin what a caller reads: `ComputerRoles(accounts=('staffcomputer',), dns_only=('printer',), default='staffcomputer')`.

`SophomorixIni.computerrole` is deprecated in favour of `computer_roles.roles`, and raises a `DeprecationWarning`. `SophomorixIni.computer_account` was removed.

The file is read with its tabs expanded to eight columns. `sophomorix.ini` indents its keys with a tabulation in most sections and with eight spaces in others, sometimes within the same section, and `configparser` reads a line indented deeper than the previous key as a continuation of its value — 53 keys of the shipped file were lost that way, the `COMPUTER_ACCOUNT` of all 15 computer roles among them. Genuine continuation lines, indented further than eight columns, are unaffected. The path is the module-level `SOPHOMORIX_INI_PATH`.

### `webui.py` — `CustomFieldsConfig`

Reads `/etc/linuxmuster/sophomorix/{school}/custom_fields.yml` and splits it per role.

```python
from linuxmusterTools.lmnconfig import CustomFieldsConfig

fields = CustomFieldsConfig(school='default-school')
fields.students['custom']              # {'field1': 'value1', ...}
fields.teachers['passwordTemplates']
```

Each of `globaladministrators`, `schooladministrators`, `students`, `teachers` is set as an attribute holding a dict with the keys `custom`, `customDisplay`, `customMulti`, `passwordTemplates`, `proxyAddresses` — missing entries default to `{}`.

> When `linuxmusterTools.common.WEBUI_IMPORT` is `True` (module imported from inside the webui process), `__init__` returns immediately with `config = {}` and none of the per-role attributes are set.

The parsed file is cached per school and read again only when its mtime changes, so an edit from the webui is seen by a running lmnapi at its next request. The ldapconnector instantiates this class on every request: parsing the yaml file each time cost 12-19 ms per request (13 s to list all users with `/users`). `config` is shared between instances and must not be modified.

---

## Import-time side effects

`samba.py` and `server.py` perform their reads at **import time**, not on instantiation — importing `linuxmusterTools.lmnconfig` (or any of its constants) triggers a `smb.conf` parse, a `net conf list` subprocess call, and a hostname/IP lookup. `setup.py`, `sophomorix.py` and `webui.py` only read their files when their classes are instantiated.
