"""
Tests for linuxmusterTools.lmnconfig.sophomorix:
SchoolConfig, MultiOrderedDict, SophomorixIni, SophomorixConf.
"""

import pytest

import linuxmusterTools.lmnconfig.sophomorix as sophomorix_module
from linuxmusterTools.lmnconfig.sophomorix import (
    FALLBACK_DEFAULT_ROLE,
    ComputerRoles,
    SchoolConfig,
    MultiOrderedDict,
    SophomorixIni,
    SophomorixConf,
)

from .conftest import isfile_only_for


# ---------------------------------------------------------------------------
# SchoolConfig
# ---------------------------------------------------------------------------

def test_school_config_default_school_path_has_no_prefix(monkeypatch, fake_lmnfile):
    path = '/etc/linuxmuster/sophomorix/default-school/school.conf'
    canned = {'global': {'SCHOOLNAME': 'Default School'}}

    monkeypatch.setattr(sophomorix_module.os.path, 'isfile', isfile_only_for(path))
    lmnfile = fake_lmnfile(canned)
    monkeypatch.setattr(sophomorix_module, 'LMNFile', lmnfile)

    config = SchoolConfig(school='default-school')

    assert config.config == canned
    assert lmnfile.path == path


def test_school_config_other_school_path_has_school_prefix(monkeypatch, fake_lmnfile):
    path = '/etc/linuxmuster/sophomorix/myschool/myschool.school.conf'
    canned = {'global': {'SCHOOLNAME': 'My School'}}

    monkeypatch.setattr(sophomorix_module.os.path, 'isfile', isfile_only_for(path))
    lmnfile = fake_lmnfile(canned)
    monkeypatch.setattr(sophomorix_module, 'LMNFile', lmnfile)

    config = SchoolConfig(school='myschool')

    assert config.config == canned
    assert lmnfile.path == path


def test_school_config_file_not_found_gives_empty_config(monkeypatch):
    monkeypatch.setattr(sophomorix_module.os.path, 'isfile', lambda path: False)

    config = SchoolConfig(school='pytest-nonexistent-school')

    assert config.config == {}


# ---------------------------------------------------------------------------
# MultiOrderedDict
# ---------------------------------------------------------------------------

def test_multi_ordered_dict_first_assignment_of_list_is_plain_set():
    d = MultiOrderedDict()
    d['a'] = ['x']
    assert d['a'] == ['x']


def test_multi_ordered_dict_second_list_assignment_extends():
    d = MultiOrderedDict()
    d['a'] = ['x']
    d['a'] = ['y']
    assert d['a'] == ['x', 'y']


def test_multi_ordered_dict_non_list_value_overwrites_normally():
    d = MultiOrderedDict()
    d['a'] = 'x'
    d['a'] = 'y'
    assert d['a'] == 'y'


def test_multi_ordered_dict_list_then_non_list_overwrites():
    d = MultiOrderedDict()
    d['a'] = ['x']
    d['a'] = 'y'
    assert d['a'] == 'y'


# ---------------------------------------------------------------------------
# SophomorixIni.sanitize (pure static method, no file access needed)
# ---------------------------------------------------------------------------

def test_sanitize_scalar_without_comment():
    assert SophomorixIni.sanitize('value') == 'value'


def test_sanitize_scalar_strips_inline_comment():
    assert SophomorixIni.sanitize('value # a comment') == 'value'


def test_sanitize_scalar_strips_surrounding_whitespace():
    assert SophomorixIni.sanitize('  value  # comment') == 'value'


def test_sanitize_multiline_value_splits_and_strips_each_line():
    value = 'line1 # c1\nline2 # c2\nline3'
    assert SophomorixIni.sanitize(value) == ['line1', 'line2', 'line3']


def test_sanitize_multiline_value_without_any_comments():
    value = 'line1\nline2'
    assert SophomorixIni.sanitize(value) == ['line1', 'line2']


# ---------------------------------------------------------------------------
# SophomorixIni.get() and __init__ (ConfigParser().read() is monkeypatched
# so the test is hermetic and does not depend on the real
# /usr/share/sophomorix/devel/sophomorix.ini file on this machine).
# ---------------------------------------------------------------------------

# The classroom-studentcomputer section reproduces the indentation of the
# shipped sophomorix.ini: a tabulation on some keys, eight spaces on others.
SYNTHETIC_INI = """
[GLOBAL]
COMPUTERROLE_DEFAULT = faculty-teachercomputer

[ROLE_USER]
teacher = Teacher
student = Student

[computerrole.classroom-studentcomputer]
\tDEVICE_SHORT = csc
        COMPUTER_ACCOUNT = TRUE
\tHOST_GROUP = FALSE

[computerrole.faculty-teachercomputer]
otherkey = othervalue

[SOME_SECTION]
single = value # trailing comment
multi = line1 # c1
    line2 # c2
"""


@pytest.fixture
def synthetic_ini(tmp_path):
    ini_file = tmp_path / 'sophomorix.ini'
    ini_file.write_text(SYNTHETIC_INI)
    return ini_file


@pytest.fixture
def sophomorix_ini(monkeypatch, synthetic_ini):
    """
    A real SophomorixIni instance reading the synthetic temp file instead of
    the hardcoded production path, so the test is independent of what's
    actually installed on this machine.
    """
    monkeypatch.setattr(sophomorix_module, 'SOPHOMORIX_INI_PATH', str(synthetic_ini))
    return SophomorixIni()


def test_sophomorix_ini_sections_are_parsed(sophomorix_ini):
    assert 'ROLE_USER' in sophomorix_ini.sections
    assert 'SOME_SECTION' in sophomorix_ini.sections


def test_sophomorix_ini_computer_roles_strip_prefix(sophomorix_ini):
    assert set(sophomorix_ini.computer_roles.roles) == {
        'classroom-studentcomputer',
        'faculty-teachercomputer',
    }


def test_sophomorix_ini_computerrole_is_deprecated(sophomorix_ini):
    with pytest.deprecated_call():
        roles = sophomorix_ini.computerrole

    assert roles == list(sophomorix_ini.computer_roles.roles)


def test_sophomorix_ini_userrole_comes_from_role_user_section(sophomorix_ini):
    assert set(sophomorix_ini.userrole) == {'teacher', 'student'}


def test_sophomorix_ini_dict_values_are_sanitized(sophomorix_ini):
    assert sophomorix_ini.dict['SOME_SECTION']['single'] == 'value'
    assert sophomorix_ini.dict['SOME_SECTION']['multi'] == ['line1', 'line2']


def test_sophomorix_ini_get_returns_sanitized_value(sophomorix_ini):
    assert sophomorix_ini.get('SOME_SECTION', 'single') == 'value'
    assert sophomorix_ini.get('SOME_SECTION', 'multi') == ['line1', 'line2']


def test_sophomorix_ini_get_missing_section_raises_key_error(sophomorix_ini):
    with pytest.raises(KeyError):
        sophomorix_ini.get('NO_SUCH_SECTION', 'single')


def test_sophomorix_ini_get_missing_key_raises_key_error(sophomorix_ini):
    with pytest.raises(KeyError):
        sophomorix_ini.get('SOME_SECTION', 'no_such_key')


def test_sophomorix_ini_space_indented_key_after_tab_is_not_swallowed(sophomorix_ini):
    # configparser reads a line indented deeper than the previous key as a
    # continuation of its value. Tabs are expanded so that both indentation
    # styles of sophomorix.ini land on the same level.
    section = sophomorix_ini.dict['computerrole.classroom-studentcomputer']

    assert section['device_short'] == 'csc'
    assert section['computer_account'] == 'TRUE'
    assert section['host_group'] == 'FALSE'


def test_sophomorix_ini_genuine_continuation_line_is_preserved(sophomorix_ini):
    # A line indented further than eight columns is still a continuation.
    assert sophomorix_ini.dict['SOME_SECTION']['multi'] == ['line1', 'line2']


def test_sophomorix_ini_computer_roles_split_on_computer_account(sophomorix_ini):
    # faculty-teachercomputer declares no COMPUTER_ACCOUNT in the synthetic
    # file, which counts as FALSE.
    assert sophomorix_ini.computer_roles == ComputerRoles(
        accounts=('classroom-studentcomputer',),
        dns_only=('faculty-teachercomputer',),
        default='faculty-teachercomputer',
    )


def test_sophomorix_ini_default_computer_role_falls_back_when_absent(monkeypatch, tmp_path):
    ini_file = tmp_path / 'sophomorix.ini'
    ini_file.write_text(SYNTHETIC_INI.replace('COMPUTERROLE_DEFAULT', 'OTHER_KEY'))
    monkeypatch.setattr(sophomorix_module, 'SOPHOMORIX_INI_PATH', str(ini_file))

    assert SophomorixIni().computer_roles.default == FALLBACK_DEFAULT_ROLE


def test_sophomorix_ini_clientrole_is_hardcoded_list(sophomorix_ini):
    assert sophomorix_ini.clientrole == [
        'classroom-teachercomputer',
        'classroom-studentcomputer',
        'faculty-teachercomputer',
        'staffcomputer',
        'thinclient',
        'iponly',
    ]


# ---------------------------------------------------------------------------
# ComputerRoles
# ---------------------------------------------------------------------------

ROLES = ComputerRoles(accounts=('staffcomputer',), dns_only=('printer',), default='staffcomputer')


@pytest.mark.parametrize('role, expected', [
    ('staffcomputer', True),
    ('printer', True),
    ('not-a-role', False),
])
def test_computer_roles_membership_is_the_union(role, expected):
    assert (role in ROLES) is expected


def test_computer_roles_roles_are_accounts_then_dns_only():
    assert ROLES.roles == ('staffcomputer', 'printer')


# ---------------------------------------------------------------------------
# SophomorixConf
# ---------------------------------------------------------------------------

SOPHOMORIX_CONF_PATH = '/etc/linuxmuster/sophomorix/sophomorix.conf'


def test_sophomorix_conf_file_not_found_gives_empty_data(monkeypatch):
    monkeypatch.setattr(sophomorix_module.os.path, 'isfile', lambda path: False)

    config = SophomorixConf()

    assert config.data == {}


def test_sophomorix_conf_file_found_reads_data_attribute(monkeypatch, fake_lmnfile):
    canned = {'global': {'LANG': 'DE'}}
    monkeypatch.setattr(sophomorix_module.os.path, 'isfile', isfile_only_for(SOPHOMORIX_CONF_PATH))
    monkeypatch.setattr(sophomorix_module, 'LMNFile', fake_lmnfile(canned))

    config = SophomorixConf()

    # Note: SophomorixConf reads config.data (not config.read()), unlike the
    # other classes in this module.
    assert config.data == canned
