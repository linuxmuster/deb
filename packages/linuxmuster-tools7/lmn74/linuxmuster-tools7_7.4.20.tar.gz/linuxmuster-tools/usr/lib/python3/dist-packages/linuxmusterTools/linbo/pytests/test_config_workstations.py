"""
Tests for list_workstations(), group_os(), last_sync_all(), get_host_image_status() and last_start() in
linuxmusterTools.linbo.config.
"""

import gzip
import logging
import time
from datetime import datetime, timezone

import pytest

import linuxmusterTools.linbo.config as config_module
from linuxmusterTools.common.timestamps import linbo_timestamp_to_epoch
from linuxmusterTools.linbo.config import group_os, last_sync, last_sync_all, get_host_image_status, last_start, list_workstations


@pytest.fixture
def berlin_tz(monkeypatch):
    """Pin the timezone: lastSync is a conversion from server-local time."""

    monkeypatch.setenv('TZ', 'Europe/Berlin')
    time.tzset()
    yield
    time.tzset()  # monkeypatch restored TZ, reload it


START_CONF = """\
[OS]
BaseImage=ubuntu.qcow2
Root=/dev/sda1
SyncEnabled=yes
NewEnabled=no
StartEnabled=yes
"""


def write_start_conf(tmp_path, group='grp1'):
    (tmp_path / f'start.conf.{group}').write_text(START_CONF)


# ── list_workstations ───────────────────────────────────────────────────


def test_list_workstations_sorts_groups_and_hosts_naturally(tmp_path, monkeypatch):
    for group in ['grp10', 'grp2']:
        write_start_conf(tmp_path, group=group)
    devices = [
        {'hostname': hostname, 'group': group, 'pxeFlag': '1'}
        for hostname, group in [
            ('r1-pc10', 'grp2'), ('r10-pc1', 'grp10'), ('r1-pc5', 'grp2'), ('r2-pc1', 'grp10'),
        ]
    ]

    class FakeDevices:
        def __init__(self, school):
            pass

        def filter(self, groups):
            return devices

    monkeypatch.setattr(config_module, 'Devices', FakeDevices)

    workstations = list_workstations()

    assert list(workstations) == ['grp2', 'grp10']
    assert [h['hostname'] for h in workstations['grp2']['hosts']] == ['r1-pc5', 'r1-pc10']
    assert [h['hostname'] for h in workstations['grp10']['hosts']] == ['r2-pc1', 'r10-pc1']


# ── group_os ─────────────────────────────────────────────────────────────


def test_group_os_default_auto_includes_broadcast(tmp_path):
    write_start_conf(tmp_path)
    workstations = {'grp1': {'hosts': []}}

    group_os(workstations)

    assert workstations['grp1']['auto']['broadcast'] == 0


def test_group_os_extracts_baseimage(tmp_path):
    write_start_conf(tmp_path)
    workstations = {'grp1': {'hosts': []}}

    group_os(workstations)

    assert workstations['grp1']['os'][0]['baseimage'] == 'ubuntu.qcow2'


def test_group_os_reads_missing_enabled_keys_as_yes(tmp_path):
    # LINBO itself treats a missing SyncEnabled/NewEnabled/StartEnabled as yes.
    (tmp_path / 'start.conf.grp1').write_text(
        '[OS]\nBaseImage=ubuntu.qcow2\nRoot=/dev/sda1\n'
    )
    workstations = {'grp1': {'hosts': []}}

    group_os(workstations)

    os_entry = workstations['grp1']['os'][0]
    assert os_entry['new_enabled'] is True
    assert os_entry['start_enabled'] is True


def test_group_os_no_startconf_leaves_empty_os(tmp_path):
    workstations = {'grp1': {'hosts': []}}

    group_os(workstations)

    assert workstations['grp1']['os'] == []
    assert 'auto' not in workstations['grp1']


def test_group_os_partition_is_none_without_partition_sections(tmp_path):
    write_start_conf(tmp_path)  # no [Partition] section at all
    workstations = {'grp1': {'hosts': []}}

    group_os(workstations)

    assert workstations['grp1']['os'][0]['partition'] is None


START_CONF_WITH_PARTITIONS = """\
[Partition]
Dev=/dev/sda1
Size=200M
Id=ef
Label=efi
Bootable=yes
FSType=vfat

[Partition]
Dev=/dev/sda3
Size=30G
Id=83
Label=data
Bootable=no
FSType=ext4

[OS]
Name=Ubuntu
BaseImage=ubuntu.qcow2
Root=/dev/sda3
Kernel=vmlinuz
Initrd=initrd
Append=
DefaultAction=sync
Description=Ubuntu
IconName=ubuntu
SyncEnabled=yes
NewEnabled=no
StartEnabled=yes
"""


def test_group_os_partition_is_position_not_device_digit(tmp_path):
    (tmp_path / 'start.conf.grp1').write_text(START_CONF_WITH_PARTITIONS)
    workstations = {'grp1': {'hosts': []}}

    group_os(workstations)

    # Root=/dev/sda3 is the 2nd [Partition] section, not partition "3".
    assert workstations['grp1']['os'][0]['partition'] == 2


# ── last_sync_all ────────────────────────────────────────────────────────


def test_last_sync_all_sets_image_list(tmp_path):
    write_start_conf(tmp_path)
    workstations = {'grp1': {'hosts': [{'hostname': 'pc001'}]}}
    group_os(workstations)

    last_sync_all(workstations)

    host = workstations['grp1']['hosts'][0]
    assert host['image'] == [{
        'date': 'Never',
        'image': 'ubuntu.qcow2',
        'imageVersion': None,
        'status': 'danger',
    }]


def test_last_sync_all_does_not_use_legacy_shape(tmp_path):
    write_start_conf(tmp_path)
    workstations = {'grp1': {'hosts': [{'hostname': 'pc001'}]}}
    group_os(workstations)

    last_sync_all(workstations)

    host = workstations['grp1']['hosts'][0]
    assert 'images' not in host
    assert 'sync' not in host


def test_last_sync_all_reads_status_file(tmp_path):
    write_start_conf(tmp_path)
    workstations = {'grp1': {'hosts': [{'hostname': 'pc001'}]}}
    group_os(workstations)

    now = datetime.now().strftime('%Y%m%d%H%M')
    (tmp_path / 'var_log_linbo' / 'pc001_image.status').write_text(
        f'{now} applied: ubuntu.qcow2 202601271107\n'
    )

    last_sync_all(workstations)

    host = workstations['grp1']['hosts'][0]
    assert host['image'][0]['status'] == 'success'


def test_last_sync_all_reports_the_applied_image_version(tmp_path):
    write_start_conf(tmp_path)
    workstations = {'grp1': {'hosts': [{'hostname': 'pc001'}]}}
    group_os(workstations)

    now = datetime.now().strftime('%Y%m%d%H%M')
    (tmp_path / 'var_log_linbo' / 'pc001_image.status').write_text(
        f'{now} applied: ubuntu.qcow2 "202601271107"\n'
    )

    last_sync_all(workstations)

    host = workstations['grp1']['hosts'][0]
    # Creation timestamp of the image the host actually runs, not the date
    # of the sync itself.
    assert host['image'][0]['imageVersion'] == '202601271107'


# ── last_sync ────────────────────────────────────────────────────────────
# last_sync() and get_host_image_status() share the same line parser
# (_get_image_status_entries); these tests pin last_sync()'s own contract:
# matching by exact image field (not by substring of the whole line) and
# accepting the .qdiff variant of the requested base image.


def test_last_sync_no_status_file_returns_false(tmp_path):
    assert last_sync('pc404', 'ubuntu.qcow2') is False


def test_last_sync_matches_requested_image(tmp_path):
    (tmp_path / 'var_log_linbo' / 'pc001_image.status').write_text(
        '202601271107 applied: ubuntu.qcow2 202601271107\n'
    )

    assert last_sync('pc001', 'ubuntu.qcow2') is not False


def test_last_sync_matches_qdiff_variant_of_requested_image(tmp_path):
    (tmp_path / 'var_log_linbo' / 'pc001_image.status').write_text(
        '202603241142 applied: ubuntu.qdiff 202601271107\n'
    )

    assert last_sync('pc001', 'ubuntu.qcow2') is not False


def test_last_sync_does_not_match_image_name_as_substring(tmp_path):
    # "ubuntu.qcow2" is a substring of "old_ubuntu.qcow2" — a naive
    # substring check on the raw line would wrongly match here.
    (tmp_path / 'var_log_linbo' / 'pc001_image.status').write_text(
        '202601271107 applied: old_ubuntu.qcow2 202601271107\n'
    )

    assert last_sync('pc001', 'ubuntu.qcow2') is False


def test_last_sync_ignores_the_case_of_the_status_file(tmp_path):
    # The file is named after the reverse DNS resolution made by rsyncd, which
    # is not the case of devices.csv (ask #12356)
    (tmp_path / 'var_log_linbo' / 'PC-001_image.status').write_text(
        '202601271107 applied: ubuntu.qcow2 202601271107\n'
    )

    assert last_sync('pc-001', 'ubuntu.qcow2') is not False
    assert last_sync('PC-001', 'ubuntu.qcow2') is not False


def test_last_sync_keeps_the_most_recent_of_two_case_variants(tmp_path):
    # Exactly the reported situation: the old file keeps the case of
    # devices.csv and is frozen, the new one is lowercase and up to date
    (tmp_path / 'var_log_linbo' / 'PC-001_image.status').write_text(
        '202601271107 applied: ubuntu.qcow2 202601271107\n'
    )
    (tmp_path / 'var_log_linbo' / 'pc-001_image.status').write_text(
        '202603241142 applied: ubuntu.qcow2 202601271107\n'
    )

    assert last_sync('PC-001', 'ubuntu.qcow2') == linbo_timestamp_to_epoch('202603241142')


def test_last_sync_without_log_directory_returns_false(tmp_path, monkeypatch):
    monkeypatch.setattr(config_module, 'LINBO_LOG_PATH', str(tmp_path / 'nonexistent'))

    assert last_sync('pc001', 'ubuntu.qcow2') is False


# ── get_host_image_status ───────────────────────────────────────────────
# linuxmuster-linbo7's shell_functions log_image_status() quotes the trailing
# timestamp on "applied" lines but not on "created" ones, e.g.:
#   202603241142 applied: win11_pro_edu.qcow2 "202601271107"
#   202601271107 created: win11_pro_edu.qcow2 202601271107
# linbo_sync reads the timestamp back with getinfo(), which keeps the quotes
# of timestamp="..." in the image .info file; linbo_mkinfo passes date(1)
# output directly.


def test_get_host_image_status_reads_applied_line(tmp_path, berlin_tz):
    (tmp_path / 'var_log_linbo' / 'pc001_image.status').write_text(
        '202603241142 applied: win11_pro_edu.qcow2 "202601271107"\n'
    )

    status = get_host_image_status()

    # 11:42 CET is 10:42 UTC: the timestamp is the client's local time, and
    # relabelling those digits as UTC was the bug.
    assert status['pc001'] == {
        'lastSync': '2026-03-24T10:42:00+00:00',
        'action': 'applied',
        'image': 'win11_pro_edu.qcow2',
        'imageVersion': '202601271107',
    }


def test_get_host_image_status_and_last_sync_agree_on_the_same_instant(tmp_path, berlin_tz):
    (tmp_path / 'var_log_linbo' / 'pc001_image.status').write_text(
        '202603241142 applied: win11_pro_edu.qcow2 "202601271107"\n'
    )

    epoch = last_sync('pc001', 'win11_pro_edu.qcow2')
    from_status = get_host_image_status()['pc001']['lastSync']

    assert datetime.fromtimestamp(epoch, tz=timezone.utc).isoformat() == from_status


def test_get_host_image_status_reads_unquoted_applied_line(tmp_path):
    # Hand-written or pre-getinfo status files carry a bare timestamp.
    (tmp_path / 'var_log_linbo' / 'pc004_image.status').write_text(
        '202603241142 applied: win11_pro_edu.qcow2 202601271107\n'
    )

    status = get_host_image_status()

    assert status['pc004']['imageVersion'] == '202601271107'


def test_get_host_image_status_reads_created_line(tmp_path):
    (tmp_path / 'var_log_linbo' / 'pc002_image.status').write_text(
        '202601271107 created: win11_pro_edu.qcow2 202601271107\n'
    )

    status = get_host_image_status()

    assert status['pc002']['action'] == 'created'


def test_get_host_image_status_skips_malformed_line(tmp_path):
    (tmp_path / 'var_log_linbo' / 'pc003_image.status').write_text('not a status line\n')

    status = get_host_image_status()

    assert 'pc003' not in status


def test_get_host_image_status_no_files_returns_empty_dict(tmp_path):
    assert get_host_image_status() == {}


def test_get_host_image_status_reports_an_unreadable_file_and_keeps_the_others(tmp_path, caplog, monkeypatch):
    log_dir = tmp_path / 'var_log_linbo'
    (log_dir / 'pc005_image.status').write_text(
        '202603241142 applied: win11_pro_edu.qcow2 "202601271107"\n'
    )
    (log_dir / 'pc006_image.status').write_text(
        '202603241142 applied: win11_pro_edu.qcow2 "202601271107"\n'
    )

    real_open = open

    def refuse_pc006(file, *args, **kwargs):
        if 'pc006' in str(file):
            raise PermissionError(13, 'Permission denied')
        return real_open(file, *args, **kwargs)

    monkeypatch.setattr('builtins.open', refuse_pc006)
    # The linuxmusterTools logger does not propagate (see __init__.py), so
    # caplog would see nothing without this.
    monkeypatch.setattr(logging.getLogger('linuxmusterTools'), 'propagate', True)

    with caplog.at_level('WARNING'):
        status = get_host_image_status()

    # The readable host is still reported ...
    assert 'pc005' in status
    # ... the unreadable one is not silently dropped: a host missing from the
    # result is indistinguishable from a host which never synced.
    assert 'pc006' not in status
    assert 'pc006' in caplog.text


# ── last_start ───────────────────────────────────────────────────────
# Both formats of linbo_start, as found in real logs: the OS number from
# linbo_wrapper (linbo-remote) and the partitions from the GUI.

LINBO_LOG = """\
Starting time sync ...
### 20261020-095445 linbo_wrapper start:1 ###
Command   : start
OS number  : 1
Starting Ubuntu KDE ...
### 20261020-095445 linbo_start 1 ###
[Info] Linbo state changed to: 3
[+++ Chapter +++] Starting Ubuntu Mate
[Info] Linbo state changed to: 4
[Info] Executing: linbo_cmd start /dev/sda3 /dev/sda3 /boot/vmlinuz /boot/initrd.img ro splash /dev/sda4
### 20261020-101411 linbo_start /dev/sda3 /dev/sda3 /boot/vmlinuz /boot/initrd.img ro splash /dev/sda4 ###
"""


def test_get_last_start_no_log_returns_false(tmp_path):
    assert last_start('pc404') is False


def test_get_last_start_without_start_returns_false(tmp_path):
    (tmp_path / 'var_log_linbo' / 'pc001_linbo.log').write_text('Starting time sync ...\n')

    assert last_start('pc001') is False


def test_get_last_start_reads_gui_format(tmp_path):
    (tmp_path / 'var_log_linbo' / 'pc001_linbo.log').write_text(LINBO_LOG)

    assert last_start('pc001') == {
        'timestamp': linbo_timestamp_to_epoch('202610201014'),
        'os': 'Ubuntu Mate',
    }


def test_get_last_start_reads_wrapper_format(tmp_path):
    (tmp_path / 'var_log_linbo' / 'pc001_linbo.log').write_text(LINBO_LOG.split('[Info] Linbo state')[0])

    assert last_start('pc001') == {
        'timestamp': linbo_timestamp_to_epoch('202610200954'),
        'os': 'Ubuntu KDE',
    }


def test_get_last_start_does_not_reuse_the_name_of_a_previous_start(tmp_path):
    (tmp_path / 'var_log_linbo' / 'pc001_linbo.log').write_text(
        'Starting Ubuntu KDE ...\n'
        '### 20261020-095445 linbo_start 1 ###\n'
        '### 20261020-101411 linbo_start 2 ###\n'
    )

    assert last_start('pc001')['os'] is None


def test_get_last_start_matches_log_file_case_insensitively(tmp_path):
    (tmp_path / 'var_log_linbo' / 'PC001_linbo.log').write_text(LINBO_LOG)

    assert last_start('pc001')['os'] == 'Ubuntu Mate'


def test_last_start_falls_back_to_the_last_rotated_log(tmp_path):
    # Just rotated: the current log holds no start yet.
    (tmp_path / 'var_log_linbo' / 'pc001_linbo.log').write_text('Starting time sync ...\n')
    with gzip.open(tmp_path / 'var_log_linbo' / 'pc001_linbo.log.1.gz', 'wt') as f:
        f.write(LINBO_LOG)

    assert last_start('pc001')['os'] == 'Ubuntu Mate'


def test_last_start_prefers_the_current_log(tmp_path):
    (tmp_path / 'var_log_linbo' / 'pc001_linbo.log').write_text(
        'Starting Windows 10 ...\n'
        '### 20261021-080000 linbo_start 2 ###\n'
    )
    with gzip.open(tmp_path / 'var_log_linbo' / 'pc001_linbo.log.1.gz', 'wt') as f:
        f.write(LINBO_LOG)

    assert last_start('pc001')['os'] == 'Windows 10'


def test_last_start_does_not_read_older_rotated_logs(tmp_path):
    with gzip.open(tmp_path / 'var_log_linbo' / 'pc001_linbo.log.2.gz', 'wt') as f:
        f.write(LINBO_LOG)

    assert last_start('pc001') is False


def test_last_sync_all_without_last_start_option(tmp_path):
    write_start_conf(tmp_path)
    workstations = {'grp1': {'hosts': [{'hostname': 'pc001'}]}}
    group_os(workstations)
    (tmp_path / 'var_log_linbo' / 'pc001_linbo.log').write_text(LINBO_LOG)

    last_sync_all(workstations)

    assert 'lastStart' not in workstations['grp1']['hosts'][0]


def test_last_sync_all_adds_last_start(tmp_path):
    write_start_conf(tmp_path)
    workstations = {'grp1': {'hosts': [{'hostname': 'pc001'}, {'hostname': 'pc002'}]}}
    group_os(workstations)
    (tmp_path / 'var_log_linbo' / 'pc001_linbo.log').write_text(LINBO_LOG)

    last_sync_all(workstations, laststart=True)

    pc001, pc002 = workstations['grp1']['hosts']
    assert pc001['lastStart'] == {'date': linbo_timestamp_to_epoch('202610201014'), 'os': 'Ubuntu Mate'}
    assert pc002['lastStart'] == 'Never'
