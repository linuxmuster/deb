from fastapi import Depends
from functools import wraps

from .header import *
from linuxmusterTools.ldapconnector import LMNLdapReader as lr


# PoC: decorator for use with new permissions
# How to use: simply decorate the endpoint with @authorize('lmn:linbo:sync')
# This decorator should compare the given permission with the one stored in
# /etc/linuxmuster/api/permissions.yml
# See samples/permissions.yml for this.
# If authorize is used for an endpoint, this will have precedence to the other
# Checkers, and will check if the given role / user has non-default permission
# to override the Checker.

def authorize(perm):
    def middleware(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            who = kwargs['who']
            permlist = [perm] # should be loaded when lmnapi starts and be cached
            if who.user == "global-admin" and perm not in permlist:
                raise HTTPException(status_code=403, detail=f"Permission {perm} is missing.")
            return func(*args, **kwargs)
        return wrapper
    return middleware

class BasicChecker:
    """
    Root class which defines all common functions and variables for the other checker.
    This class can not be used directly, its only purpose is code factoring.
    """


    ROLES_MAPPING = {
        'G': 'globaladministrator',
        'S': 'schooladministrator',
        'T': 'teacher',
        's': 'student',
        'P': 'parent',
        'F': 'staff',
    }

    def __init__(self, roles) -> None:
        if isinstance(roles, list):
            self.roles = roles
        elif isinstance(roles, str):
            if roles == "ALL":
                self.roles = list(self.ROLES_MAPPING.values())
            else:
                self.roles = [
                    self.ROLES_MAPPING[alias]
                    for alias in roles if alias in self.ROLES_MAPPING
                ]

    def _check_role_permissions(self, who, requested_user):

            if not requested_user:
                return False

            role_rank = {
                'globaladministrator': 4,
                'schooladministrator': 3,
                'teacher': 2,
                'student': 1,
                'examuser': 1,
                'parent': 2,
                'staff': 2
            }

            identity = who.user
            identity_role = who.role

            # Global admins have all rights
            if identity_role == 'globaladministrator':
                return True

            # Ensure the requested user exists in LDAP
            try:
                if requested_user.endswith('-exam'):
                    user_data = lr.getvalues(f'/users/exam/{requested_user}', ['sophomorixRole', 'sophomorixSchoolname'])
                else:
                    user_data = lr.getvalues(f'/users/{requested_user}', ['sophomorixRole', 'sophomorixSchoolname'])
            except Exception:
                raise HTTPException(status_code=404, detail=f"Requested user {requested_user} not found")

            user_role = user_data['sophomorixRole']

            # Is it really a valid user ?
            if user_role is None:
                return False

            # Users from another school are out of reach
            if user_data['sophomorixSchoolname'] != who.school:
                return False

            ## Some additional security checks
            # Access forbidden for students
            if identity_role not in ['teacher', 'schooladministrator']:
                return False

            # Same rank but other user -> access forbidden
            if role_rank[identity_role] == role_rank.get(user_role, 5):
                # User can only change its own password, not from someone else with the same rank
                if identity != requested_user:
                    return False
            else:
                # Check if the role rank of the user is greater than the user logged in
                # If the role of the user can not be found, access forbidden
                if role_rank.get(user_role, 5) > role_rank[identity_role]:
                    return False

            return True

class RoleChecker(BasicChecker):
    """
    Check role for permission access. Missing the possibility to check the user:
    globaladmin can access all user informations, but an user should be able to
    access its own informations.
    """


    def __init__(self, roles) -> None:
        BasicChecker.__init__(self, roles)

    def __call__(self, who: AuthenticatedUser = Depends(check_authentication_header)) -> AuthenticatedUser:

        if who.role == 'globaladministrator':
            return who

        if who.role in self.roles:
            return who

        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail='Permission denied')


class UserChecker(BasicChecker):
    """
    Check role and user for permission access.
    globaladmin can access all user informations, and an user is able to access its own informations.
    """


    def __init__(self, roles) -> None:
        BasicChecker.__init__(self, roles)

    def __call__(self, who: AuthenticatedUser = Depends(check_authentication_header), user=None) -> AuthenticatedUser:

        if who.role == 'globaladministrator':
            return who

        if who.user == user:
            return who

        if who.role in self.roles and self._check_role_permissions(who, user):
            return who

        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail='Permission denied')


class UserListChecker(BasicChecker):
    """
    Check role and user for permission access for command that need to be run over several users.
    globaladmin can access all user informations, and an user is able to access its own informations, and to access
    informations of users from a bellow roles.
    """


    def __init__(self, roles) -> None:
        BasicChecker.__init__(self, roles)

    async def __call__(self, request: Request, who: AuthenticatedUser = Depends(check_authentication_header)) -> bool:

        body = await request.json()
        users = body.get('users', [])

        if who.role == 'globaladministrator':
            return who

        if who.role in self.roles:
            # If one user has higher level, refuse to answer
            for user in users:
                if not self._check_role_permissions(who, user):
                    raise HTTPException(
                        status_code=status.HTTP_401_UNAUTHORIZED,
                        detail=f'Permission denied to request user {user}'
                    )
            return who

        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail='Permission denied')

def check_print_permissions(who, users):
    """
    Basic checks to print passwords:
     - Teachers can only see student's passwords
     - schooladministrators and globaladministrators must be removed from the
    list (sophomorix does not accept to print admin password for security
    reasons)

    :param who: the user requesting to print the passwords
    :type who: AuthenticatedUser
    :param users: set of the users to print passwords
    :type users: set
    :return: set of accepted users to print passwords
    :rtype: set
    """


    to_remove = set()

    for user in users:

        # Ignore own password
        if user == who.user:
            to_remove.add(user)
            continue

        # Ensure the requested user exists in LDAP
        if user.endswith('-exam'):
            user_data = lr.getvalues(f'/users/exam/{user}', ['sophomorixRole', 'sophomorixSchoolname'])
        else:
            user_data = lr.getvalues(f'/users/{user}', ['sophomorixRole', 'sophomorixSchoolname'])

        user_role = user_data['sophomorixRole']

        # Ignoring unknow users
        if user_role is None:
            to_remove.add(user)

        # Ignoring users from another school
        elif who.role != 'globaladministrator' and user_data['sophomorixSchoolname'] != who.school:
            to_remove.add(user)

        # Do not print admins password
        elif user_role in ['globaladministrator', 'schooladministrator']:
            to_remove.add(user)

        # As a teacher, only print the passwords of students
        elif who.role == 'teacher' and user_role not in ['student', 'examuser']:
            to_remove.add(user)

    users.difference_update(to_remove)

    return users
