from fastapi import HTTPException, Request
from fastapi.security import APIKeyHeader
from starlette import status
import jwt
import hmac
from pydantic import BaseModel

from linuxmusterTools.common import LdapNotProvisionedError
from linuxmusterTools.ldapconnector import LMNLdapReader as lr

from vars import API_V1_PREFIX
from security.scope import allows


class AuthenticatedUser(BaseModel):
    dn: str
    user: str
    role: str | None = None
    school: str | None = None


X_API_KEY = APIKeyHeader(name='X-API-Key')
X_HOST_KEY = APIKeyHeader(name='X-HOST-Key')

def check_authentication_header(request: Request) -> AuthenticatedUser:
    """
    Return role associated with the api key.
    """


    apikey = request.headers.get('x-api-key', None)
    hostkey = request.headers.get('x-host-key', None)

    if apikey and hostkey:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only one header Key is accepted",
        )

    if apikey:
        return check_user_header(apikey.strip('"').strip("'"), request.app.state.secret)

    if hostkey:
        client_ip = request.client.host
        # Scopes are written without the version prefix: an admin restricts a
        # key to an endpoint, not to a release of the API.
        path = request.url.path
        if path.startswith(API_V1_PREFIX):
            path = path[len(API_V1_PREFIX):] or '/'

        return check_host_header(hostkey.strip('"').strip("'"), client_ip,
                                 request.app.state.host_keys,
                                 request.app.state.host_key_auth_enable,
                                 request.method, path)

    raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API Key",
        )

def check_user_header(apikey, secret) -> AuthenticatedUser:

    try:
        payload = jwt.decode(apikey, secret, algorithms=["HS512"])
        user = payload['user']
    except (jwt.exceptions.InvalidSignatureError, jwt.exceptions.DecodeError):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API Key",
        )
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Expired API Key",
        )

    # role may be eventually None
    try:
        user_details = lr.getvalues(f'/users/{user}', ['sophomorixRole', 'sophomorixSchoolname', 'distinguishedName'])
    except LdapNotProvisionedError:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="linuxmuster is not provisioned yet",
        )

    if user_details.get('sophomorixRole', None) is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API Key",
        )

    return AuthenticatedUser(
        dn=user_details['distinguishedName'],
        user=user,
        role=user_details['sophomorixRole'],
        school=user_details.get('sophomorixSchoolname', "")
    )


def check_host_header(hostkey, client_ip, keys, host_key_auth_enable, method, path) -> AuthenticatedUser:
    """
    Resolve a x-host-key into the LDAP user it maps to.

    :param method: HTTP method of the request, matched against the key's scope
    :type method: str
    :param path: Request path without the version prefix, matched against the
                 key's scope
    :type path: str
    """

    user = None

    if not host_key_auth_enable:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid Auth method",
        )

    for name, key in keys.items():
        secret = key.get('secret', None)

        if secret is None:
            continue

        if hmac.compare_digest(hostkey, secret):
            user = key.get('user', None)
            valid_ips = key.get('ips', [])

            if valid_ips and client_ip not in valid_ips:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid API Key IP",
                )

            # A scope only ever narrows: the role of `user` is still checked
            # by RoleChecker further down the dependency chain.
            if not allows(key.get('scope', None), method, path):
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="API Key not allowed on this endpoint",
                )

            break

    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API Key",
        )

    # role may be eventually None
    try:
        user_details = lr.getvalues(f'/users/{user}', ['sophomorixRole', 'sophomorixSchoolname', 'distinguishedName'])
    except LdapNotProvisionedError:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="linuxmuster is not provisioned yet",
        )

    if user_details.get('sophomorixRole', None) is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API Key",
        )

    return AuthenticatedUser(
        dn=user_details['distinguishedName'],
        user=user,
        role=user_details['sophomorixRole'],
        school=user_details.get('sophomorixSchoolname', "")
    )