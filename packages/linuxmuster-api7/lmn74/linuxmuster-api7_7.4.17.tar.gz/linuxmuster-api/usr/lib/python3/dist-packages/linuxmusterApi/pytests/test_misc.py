import json
import sys
import pytest
from fastapi.testclient import TestClient

from .credentials import *
import linuxmusterTools.samba_util.smbstatus as smbstatus_module

sys.path.append(LOCAL_API_PATH)
from main import app

client = TestClient(app)
client_no_raise = TestClient(app, raise_server_exceptions=False)
USERS = [GLOBALADMIN, SCHOOLADMIN, TEACHER, STUDENT, STAFF, PARENT]


class TestQuery:
    def test_query_ga(self):
        r = client.get(f"{BASE_URL}/query/{SCHOOL}/{TEACHER.cn}", headers={"X-API-KEY": GLOBALADMIN.jwt})
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)

    def test_query_sa(self):
        r = client.get(f"{BASE_URL}/query/{SCHOOL}/{TEACHER.cn}", headers={"X-API-KEY": SCHOOLADMIN.jwt})
        assert r.status_code == 200

    def test_query_teacher(self):
        r = client.get(f"{BASE_URL}/query/{SCHOOL}/{TEACHER.cn}", headers={"X-API-KEY": TEACHER.jwt})
        assert r.status_code == 200

    @pytest.mark.parametrize("user", USERS[3:])
    def test_query_denied(self, user):
        r = client.get(f"{BASE_URL}/query/{SCHOOL}/{TEACHER.cn}", headers={"X-API-KEY": user.jwt})
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    def test_query_ga_global(self):
        r = client.get(f"{BASE_URL}/query/global/{TEACHER.cn}", headers={"X-API-KEY": GLOBALADMIN.jwt})
        assert r.status_code == 200
        assert len(r.json()) > 0

    @pytest.mark.parametrize("user", [SCHOOLADMIN, TEACHER])
    @pytest.mark.parametrize("school", ["global", "other-school"])
    def test_query_other_school_forbidden(self, user, school):
        r = client.get(f"{BASE_URL}/query/{school}/{TEACHER.cn}", headers={"X-API-KEY": user.jwt})
        assert r.status_code == 403

    @pytest.mark.parametrize("user, school", [(GLOBALADMIN, "global"), (GLOBALADMIN, SCHOOL), (SCHOOLADMIN, SCHOOL), (TEACHER, SCHOOL)])
    def test_query_never_returns_first_passwords(self, user, school):
        r = client.get(f"{BASE_URL}/query/{school}/{TEACHER.cn}", headers={"X-API-KEY": user.jwt})
        assert r.status_code == 200
        assert len(r.json()) > 0
        assert all('sophomorixFirstPassword' not in result for result in r.json())


class TestSamba:
    def test_smbstatus_ga(self):
        r = client_no_raise.get(f"{BASE_URL}/samba/smbstatus", headers={"X-API-KEY": GLOBALADMIN.jwt})
        assert r.status_code != 401

    def test_smbstatus_sa(self):
        r = client_no_raise.get(f"{BASE_URL}/samba/smbstatus", headers={"X-API-KEY": SCHOOLADMIN.jwt})
        assert r.status_code != 401

    def test_smbstatus_teacher(self):
        r = client.get(f"{BASE_URL}/samba/smbstatus", headers={"X-API-KEY": TEACHER.jwt})
        assert r.status_code == 200

    @pytest.mark.parametrize("user", USERS[3:])
    def test_smbstatus_denied(self, user):
        r = client.get(f"{BASE_URL}/samba/smbstatus", headers={"X-API-KEY": user.jwt})
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    @pytest.fixture
    def fake_connections(self, monkeypatch):
        # Teacher on pc01 in r101, a student on pc02 in r101, another one in
        # r201, and the connection opened by the Webui worker of the teacher.
        sessions = [
            (101, TEACHER.cn, '10.0.0.102', 50682),
            (102, STUDENT.cn, '10.0.0.103', 50710),
            (103, 'other', '10.0.0.120', 50720),
            (104, TEACHER.cn, '10.0.0.1', 51538),
        ]
        # Same format as `smbstatus -b -j`, only with the fields read by lmntools
        output = json.dumps({'sessions': {
            str(pid): {
                'server_id': {'pid': str(pid)},
                'username': f'DOMAIN\\{user}',
                'groupname': 'users',
                'auth_time': '2026-10-26T19:00:00.000000+01:00',
                'remote_machine': ip,
                'hostname': f'ipv4:{ip}:{port}',
                'session_dialect': 'SMB3_11',
                'encryption': {'cipher': '-'},
                'signing': {'cipher': 'AES-128-GMAC'},
            }
            for pid, user, ip, port in sessions
        }})
        hostnames = {
            '10.0.0.102': {'hostname': 'pc01', 'room': 'r101'},
            '10.0.0.103': {'hostname': 'pc02', 'room': 'r101'},
            '10.0.0.120': {'hostname': 'pc03', 'room': 'r201'},
        }
        monkeypatch.setattr(smbstatus_module.subprocess, 'getoutput', lambda cmd: output)
        monkeypatch.setattr(smbstatus_module.SMBConnections, 'load_hostnames', lambda self: hostnames)
        monkeypatch.setattr(smbstatus_module, 'SERVER_IP', '10.0.0.1')

    def test_smbstatus_sa_with_connections(self, fake_connections):
        r = client.get(f"{BASE_URL}/samba/smbstatus", headers={"X-API-KEY": SCHOOLADMIN.jwt})
        assert r.status_code == 200
        assert set(r.json().keys()) == {TEACHER.cn, STUDENT.cn, 'other'}

    def test_smbstatus_teacher_with_connections(self, fake_connections):
        r = client.get(f"{BASE_URL}/samba/smbstatus", headers={"X-API-KEY": TEACHER.jwt})
        assert r.status_code == 200
        assert set(r.json().keys()) == {TEACHER.cn, STUDENT.cn}

    def test_user_in_room_with_connections(self, fake_connections):
        r = client.get(f"{BASE_URL}/samba/userInRoom/{TEACHER.cn}", headers={"X-API-KEY": TEACHER.jwt})
        assert r.status_code == 200
        assert r.json() == {
            'usersList': [STUDENT.cn],
            'name': 'r101',
            'objects': {
                STUDENT.cn: {
                    'COMPUTER': 'pc02', 'IP': '10.0.0.103', 'IPV4': '10.0.0.103', 'PORT': '50710', 'ROOM': 'r101',
                    'SMBSTATUS_LINE': '',
                },
            },
        }

    def test_user_in_room_teacher(self):
        r = client.get(f"{BASE_URL}/samba/userInRoom/{TEACHER.cn}", headers={"X-API-KEY": TEACHER.jwt})
        assert r.status_code == 200
        assert set(r.json().keys()) == {'usersList', 'name', 'objects'}

    def test_user_in_room_teacher_other_user(self):
        r = client.get(f"{BASE_URL}/samba/userInRoom/{STUDENT.cn}", headers={"X-API-KEY": TEACHER.jwt})
        assert r.status_code == 403

    def test_user_in_room_sa(self):
        r = client.get(f"{BASE_URL}/samba/userInRoom/{TEACHER.cn}", headers={"X-API-KEY": SCHOOLADMIN.jwt})
        assert r.status_code == 200

    def test_user_in_room_ga(self):
        r = client.get(f"{BASE_URL}/samba/userInRoom/{TEACHER.cn}", headers={"X-API-KEY": GLOBALADMIN.jwt})
        assert r.status_code == 200

    def test_user_in_room_ga_uses_the_school_of_the_user(self, fake_connections, monkeypatch):
        schools = []
        original_init = smbstatus_module.SMBConnections.__init__
        def init(self, school='default-school'):
            schools.append(school)
            original_init(self, school)
        monkeypatch.setattr(smbstatus_module.SMBConnections, '__init__', init)

        r = client.get(f"{BASE_URL}/samba/userInRoom/{TEACHER.cn}", headers={"X-API-KEY": GLOBALADMIN.jwt})
        assert r.status_code == 200
        assert r.json()['name'] == 'r101'
        assert schools == [TEACHER.school]

    @pytest.mark.parametrize("username", [GLOBALADMIN.cn, "nonexistentuser"])
    def test_user_in_room_ga_without_school(self, username):
        r = client.get(f"{BASE_URL}/samba/userInRoom/{username}", headers={"X-API-KEY": GLOBALADMIN.jwt})
        assert r.status_code == 200
        assert r.json() == {"usersList": [], "name": "", "objects": {}}

    @pytest.mark.parametrize("user", USERS[3:])
    def test_user_in_room_denied(self, user):
        r = client.get(f"{BASE_URL}/samba/userInRoom/{user.cn}", headers={"X-API-KEY": user.jwt})
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]


class TestExam:
    @pytest.mark.parametrize("user", USERS[3:])
    def test_post_exammode_start_denied(self, user):
        r = client.post(f"{BASE_URL}/exammode/start", headers={"X-API-KEY": user.jwt}, json={"users": []})
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    @pytest.mark.parametrize("user", USERS[3:])
    def test_post_exammode_stop_denied(self, user):
        r = client.post(f"{BASE_URL}/exammode/stop", headers={"X-API-KEY": user.jwt}, json={"users": []})
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    def test_get_exammode_users_ga(self):
        r = client.get(f"{BASE_URL}/exammode/users", headers={"X-API-KEY": GLOBALADMIN.jwt})
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data, list)

    def test_get_exammode_users_sa(self):
        r = client.get(f"{BASE_URL}/exammode/users", headers={"X-API-KEY": SCHOOLADMIN.jwt})
        assert r.status_code == 200

    def test_get_exammode_users_teacher(self):
        r = client.get(f"{BASE_URL}/exammode/users", headers={"X-API-KEY": TEACHER.jwt})
        assert r.status_code == 200

    @pytest.mark.parametrize("user", USERS[3:])
    def test_get_exammode_users_denied(self, user):
        r = client.get(f"{BASE_URL}/exammode/users", headers={"X-API-KEY": user.jwt})
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    def test_get_exammode_user_ga(self):
        r = client.get(f"{BASE_URL}/exammode/users/{TEACHER.cn}", headers={"X-API-KEY": GLOBALADMIN.jwt})
        assert r.status_code == 200

    def test_get_exammode_user_sa(self):
        r = client.get(f"{BASE_URL}/exammode/users/{TEACHER.cn}", headers={"X-API-KEY": SCHOOLADMIN.jwt})
        assert r.status_code == 200

    def test_get_exammode_user_teacher(self):
        r = client.get(f"{BASE_URL}/exammode/users/{TEACHER.cn}", headers={"X-API-KEY": TEACHER.jwt})
        assert r.status_code == 200

    @pytest.mark.parametrize("user", USERS[3:])
    def test_get_exammode_user_denied(self, user):
        r = client.get(f"{BASE_URL}/exammode/users/{TEACHER.cn}", headers={"X-API-KEY": user.jwt})
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]


class TestListManagement:
    def test_get_listmanagement_ga(self):
        r = client.get(f"{BASE_URL}/listmanagement/{SCHOOL}/students", headers={"X-API-KEY": GLOBALADMIN.jwt})
        assert r.status_code == 200

    def test_get_listmanagement_sa(self):
        r = client.get(f"{BASE_URL}/listmanagement/{SCHOOL}/students", headers={"X-API-KEY": SCHOOLADMIN.jwt})
        assert r.status_code == 200

    @pytest.mark.parametrize("user", USERS[2:])
    def test_get_listmanagement_denied(self, user):
        r = client.get(f"{BASE_URL}/listmanagement/{SCHOOL}/students", headers={"X-API-KEY": user.jwt})
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    @pytest.mark.parametrize("user", USERS[2:])
    def test_post_listmanagement_denied(self, user):
        r = client.post(
            f"{BASE_URL}/listmanagement/{SCHOOL}/students",
            headers={"X-API-KEY": user.jwt},
            json=[]
        )
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]


class TestLinbo:
    def test_get_linbo_health_ga(self):
        r = client.get(f"{BASE_URL}/linbo/health", headers={"X-API-KEY": GLOBALADMIN.jwt})
        assert r.status_code == 200

    def test_get_linbo_health_sa(self):
        r = client.get(f"{BASE_URL}/linbo/health", headers={"X-API-KEY": SCHOOLADMIN.jwt})
        assert r.status_code == 200

    @pytest.mark.parametrize("user", USERS[2:])
    def test_get_linbo_health_denied(self, user):
        r = client.get(f"{BASE_URL}/linbo/health", headers={"X-API-KEY": user.jwt})
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    def test_get_linbo_server_info_ga(self):
        r = client.get(f"{BASE_URL}/linbo/server-info", headers={"X-API-KEY": GLOBALADMIN.jwt})
        assert r.status_code == 200

    @pytest.mark.parametrize("user", USERS[1:])
    def test_get_linbo_server_info_denied(self, user):
        r = client.get(f"{BASE_URL}/linbo/server-info", headers={"X-API-KEY": user.jwt})
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    def test_get_linbo_groups_ga(self):
        r = client.get(f"{BASE_URL}/linbo/linbo-groups", headers={"X-API-KEY": GLOBALADMIN.jwt})
        assert r.status_code == 200
        assert "groups" in r.json()

    def test_get_linbo_groups_sa(self):
        r = client.get(f"{BASE_URL}/linbo/linbo-groups", headers={"X-API-KEY": SCHOOLADMIN.jwt})
        assert r.status_code == 200
        assert "groups" in r.json()

    @pytest.mark.parametrize("user", USERS[2:])
    def test_get_linbo_groups_denied(self, user):
        r = client.get(f"{BASE_URL}/linbo/linbo-groups", headers={"X-API-KEY": user.jwt})
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    @pytest.mark.parametrize("user", USERS[2:])
    def test_post_linbo_startconf_denied(self, user):
        r = client.post(
            f"{BASE_URL}/linbo/startconfs/pytest-startconf",
            headers={"X-API-KEY": user.jwt},
            json={"content": "[LINBO]\nServer = 10.0.0.1\n"},
        )
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    @pytest.mark.parametrize("user", USERS[2:])
    def test_delete_linbo_startconf_denied(self, user):
        r = client.delete(
            f"{BASE_URL}/linbo/startconfs/pytest-startconf",
            headers={"X-API-KEY": user.jwt},
        )
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    @pytest.mark.parametrize("user", USERS[2:])
    def test_post_linbo_hosts_scan_denied(self, user):
        r = client.post(
            f"{BASE_URL}/linbo/hosts/scan",
            headers={"X-API-KEY": user.jwt},
            json={"macs": []},
        )
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    def test_post_linbo_wol_sa_is_limited_to_its_own_devices(self):
        # Reaches the endpoint now, but a MAC that is in no devices.csv of the
        # school is not woken: nothing to send, hence 404 and not 200.
        r = client.post(
            f"{BASE_URL}/linbo/wol",
            headers={"X-API-KEY": SCHOOLADMIN.jwt},
            json={"macs": ["00:11:22:33:44:55"]},
        )
        assert r.status_code == 404

    @pytest.mark.parametrize("user", USERS[2:])
    def test_post_linbo_wol_denied(self, user):
        r = client.post(
            f"{BASE_URL}/linbo/wol",
            headers={"X-API-KEY": user.jwt},
            json={"macs": ["00:11:22:33:44:55"]},
        )
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    def test_get_linbo_hosts_image_status_ga(self):
        r = client.get(f"{BASE_URL}/linbo/hosts/image-status", headers={"X-API-KEY": GLOBALADMIN.jwt})
        assert r.status_code == 200

    def test_get_linbo_hosts_image_status_sa(self):
        r = client.get(f"{BASE_URL}/linbo/hosts/image-status", headers={"X-API-KEY": SCHOOLADMIN.jwt})
        assert r.status_code == 200

    @pytest.mark.parametrize("user", USERS[2:])
    def test_get_linbo_hosts_image_status_denied(self, user):
        r = client.get(f"{BASE_URL}/linbo/hosts/image-status", headers={"X-API-KEY": user.jwt})
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    def test_get_linbo_boot_logs_sa(self):
        r = client.get(f"{BASE_URL}/linbo/boot-logs", headers={"X-API-KEY": SCHOOLADMIN.jwt})
        assert r.status_code == 200
        assert "logs" in r.json()

    def test_get_linbo_boot_log_of_another_host_is_not_found_for_sa(self):
        # Not "permission denied": a log that belongs to no machine of the
        # school is answered like a log that does not exist.
        r = client.get(
            f"{BASE_URL}/linbo/boot-logs/pytest-nonexistent.log",
            headers={"X-API-KEY": SCHOOLADMIN.jwt},
        )
        assert r.status_code == 404

    @pytest.mark.parametrize("user", USERS[2:])
    def test_get_linbo_boot_logs_denied(self, user):
        r = client.get(f"{BASE_URL}/linbo/boot-logs", headers={"X-API-KEY": user.jwt})
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    @pytest.mark.parametrize("user", USERS[2:])
    def test_get_linbo_boot_log_denied(self, user):
        r = client.get(
            f"{BASE_URL}/linbo/boot-logs/pytest-nonexistent.log",
            headers={"X-API-KEY": user.jwt},
        )
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    @pytest.mark.parametrize("user", USERS[2:])
    def test_delete_linbo_boot_log_denied(self, user):
        r = client.delete(
            f"{BASE_URL}/linbo/boot-logs/pytest-nonexistent.log",
            headers={"X-API-KEY": user.jwt},
        )
        assert r.status_code == 401
        assert 'Permission denied' in r.json()["detail"]

    def test_get_linbo_boot_logs_ga(self):
        r = client.get(f"{BASE_URL}/linbo/boot-logs", headers={"X-API-KEY": GLOBALADMIN.jwt})
        assert r.status_code == 200
        assert "logs" in r.json()
