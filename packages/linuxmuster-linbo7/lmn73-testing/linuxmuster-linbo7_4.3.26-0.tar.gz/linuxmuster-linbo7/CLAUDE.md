# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

linuxmuster-linbo7 is a Linux-based network boot (LINBO) imaging solution for linuxmuster.net 7. It provides a complete system for managing client computers via PXE boot, handling Windows and Linux operating systems with features like differential imaging, qcow2 image format, and remote management capabilities.

**Key Components:**
- **linbofs**: The client-side boot filesystem (initramfs) that runs on PXE-booted clients
- **serverfs**: Server-side scripts and configuration files
- **build**: Build system for compiling kernels and creating the package
- **src**: Source code for third-party components (busybox, kexec, opentracker, etc.)

**Important Note:** The code in this repository is not yet for production use. The stable version is in the [4.0 branch](https://github.com/linuxmuster/linuxmuster-linbo7/tree/4.0).

## Build Commands

### Initial Setup
```bash
# Install all build dependencies (uses sudo)
./get-depends.sh

# Build the Debian package
./buildpackage.sh
```

The build output will be placed in the parent directory (`..`), and a build log is created at `../build.log`.

For better convenience, use the [linbo-build-docker](https://github.com/linuxmuster/linbo-build-docker) environment instead of building directly on your system.

### Build Artifacts
- The package is built using `dpkg-buildpackage`
- Build scripts are located in `build/run.d/` and are numbered to control execution order:
  - `0_busybox`: Builds busybox
  - `1_kernels`: Compiles kernel versions (6.1.*, 6.12.*, 6.17.*)
  - `2a_r8168`, `2b_r8812`, `2c_r8125`: Network driver modules
  - `3_serverfs`: Prepares server filesystem
  - `99_linbofs`: Creates the final linbofs initramfs

## Architecture

### Client-Server Communication Flow

1. **Boot Process**: Client PXE boots → downloads linbofs via TFTP → boots into LINBO environment
2. **Configuration**: Client reads `start.conf` from server (defines partitions, OS images, boot options)
3. **Remote Management**: Server uses `linbo-remote` to execute commands on clients via SSH
4. **Image Distribution**: Images can be distributed via rsync, multicast (udpcast), or BitTorrent

### Image Management System

LINBO uses **qcow2 format with differential imaging**:
- **Base Image**: `image.qcow2` - full system image
- **Differential Image**: `image.qdiff` - incremental changes based on base image
- Differential images use qcow2's backing store feature
- Images are mounted via `qemu-nbd` for file-level operations
- Both Linux (ext4) and Windows (ntfs3 driver) are supported

### Client Filesystem (linbofs)

The client environment is a minimal initramfs with:
- **Init System**: Custom init script (`linbofs/init.sh`) using busybox
- **Shell Environment**: Complete environment with variables like `$LINBOSERVER`, `$IP`, `$HOSTNAME`, etc.
- **Command Suite**: 50+ `linbo_*` commands in `/usr/bin/` for all operations
- **Configuration Parsing**: `start.conf` is split into parseable chunks in `/conf/` (e.g., `/conf/linbo`, `/conf/os.1`, `/conf/part.1.sda1`)

Key client commands:
- `linbo_cmd`: Legacy wrapper for GUI compatibility
- `linbo_create_image`: Create base or differential images
- `linbo_sync`: Synchronize OS from image
- `linbo_start`: Start an installed OS
- `linbo_partition_format`: Partition and format disks
- `linbo_initcache`: Initialize local cache with images

### Server Management Tools

Located in `serverfs/usr/sbin/`:
- **`linbo-remote`**: Execute commands on clients via SSH (uses tmux for background jobs)
- **`linbo-torrent`**: Manage BitTorrent distribution of images
- **`linbo-multicast`**: Manage multicast distribution sessions
- **`update-linbofs`**: Rebuild linbofs with customizations (firmware, kernel, scripts)

### Configuration System

**start.conf format**: INI-style configuration with sections:
- `[LINBO]`: Global settings (server, cache partition, download type, GUI options)
- `[Partition]`: Partition definitions (device, size, filesystem, bootable flag)
- `[OS]`: Operating system definitions (name, image file, kernel, autostart behavior)

Example configurations are in `serverfs/srv/linbo/examples/start.conf.*`

## Development Patterns

### Adding Custom Boot Scripts

1. Create your script in `/root/linbofs/mybootscript.sh`
2. Create a pre-hook in `/var/lib/linuxmuster/hooks/update-linbofs.pre.d/` to copy it:
   ```bash
   #!/bin/bash
   echo "### copy mybootscript.sh ###"
   cp /root/linbofs/mybootscript.sh usr/bin
   ```
3. Add to `/etc/linuxmuster/linbo/inittab`:
   ```
   ::wait:/usr/bin/mybootscript.sh
   ```
4. Run `update-linbofs` to apply changes

### Integrating Custom Kernels

Edit `/etc/linuxmuster/linbo/custom_kernel`:
```bash
# Use Linbo's alternative kernels
KERNELPATH="legacy"    # for 6.1.* kernel
KERNELPATH="longterm"  # for 6.12.* kernel
KERNELPATH="stable"    # for latest stable

# Or use custom kernel
KERNELPATH="/path/to/vmlinuz"
MODULESPATH="/path/to/lib/modules/x.x.x"
```

Then run `update-linbofs`.

### Adding Firmware

Edit `/etc/linuxmuster/linbo/firmware`:
```
# Whole directory
rtl_nic

# Single file
iwlwifi-cc-a0-77.ucode
```

Paths are relative to `/lib/firmware`. Run `update-linbofs` to apply.

### WiFi Support

Configure `/etc/linuxmuster/linbo/wpa_supplicant.conf`:
```
network={
  ssid="NETWORK_NAME"
  scan_ssid=1
  key_mgmt=WPA-PSK
  psk="passphrase"
}
```

Run `update-linbofs` and add WiFi MAC address to `devices.csv`.

## Important Technical Details

### Session Management
- Background jobs use **tmux** (not screen)
- Detach tmux sessions with `[CTRL+B]+[D]`
- The `linbo-remote` script can attach to client sessions with `-a <hostname>`

### Security
- Server's root SSH public key is embedded in linbofs for passwordless SSH
- LINBO password hash (from `/etc/rsyncd.secrets`) is integrated into linbofs
- Clients establish SSH connections back to server for remote operations

### GUI Modes
- **Full GUI**: Default graphical interface (linuxmuster-linbo-gui7)
- **nogui mode**: Text-based console menu (kernel parameter `nogui`)
- **nomenu mode**: Remote-only mode, no console menu (kernel parameters `nogui nomenu`)

### Kernel Parameters
Important parameters for troubleshooting:
- `debug`: Boot into debug shell
- `forcegrub`: Force GRUB boot for UEFI systems
- `restoremode=dd|ooo`: Control qemu-img writing performance
- `vncserver`: Start VNC server on port 9999 (accessible from server)
- `linbocmd=cmd1,cmd2,...`: Execute commands during boot

## File Locations

### On Server (when installed)
- Configuration: `/etc/linuxmuster/linbo/`
- Images: `/srv/linbo/`
- LINBO files: `/srv/linbo/` (linbofs, kernels, grub)
- Scripts: `/usr/share/linuxmuster/linbo/`
- Logs: `/var/log/linuxmuster/linbo/`
- Hooks: `/var/lib/linuxmuster/hooks/update-linbofs.{pre,post}.d/`

### In Repository
- Client filesystem: `linbofs/` (installed to initramfs)
- Server files: `serverfs/` (installed to root filesystem)
- Build configuration: `build/conf.d/`, `build/config/`
- Build scripts: `build/run.d/`

## Testing and Debugging

### Client Debug Mode
Boot with `debug` kernel parameter to get a shell before GUI starts. Environment variables are available in `/.env`.

### Checking Firmware Issues
On a LINBO client:
```bash
dmesg | grep firmware
```

### Monitoring Remote Operations
```bash
# List running sessions
linbo-remote -l

# Attach to a client session
linbo-remote -a <hostname>

# View torrent sessions
linbo-torrent status
linbo-torrent attach <image_name>

# Monitor multicast logs
tail -f /var/log/linuxmuster/linbo/<image>_mcast.log
```

## Version Information

Version format: `X.Y.Z-N` (e.g., 4.3.26-0)
- Version stored in `debian/changelog` and `linbofs/etc/linbo-version`
- Current development targets linuxmuster.net 7.2/7.3 (Ubuntu 22.04 server)
- Supports multiple kernel versions simultaneously: 6.1.* (longterm), 6.12.*, 6.17.*
