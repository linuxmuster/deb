#!/bin/sh
# init.sh - System setup and hardware detection
# This is a busybox 1.1.3 init script
# (C) Klaus Knopper 2007
# License: GPL V2
#
# thomas@linuxmuster.net
# 20250918
#

# If you don't have a "standalone shell" busybox, enable this:
# /bin/busybox --install

# Ignore signals
#trap "" 1 2 11 15

# set terminal
export TERM=xterm

# Reset fb color mode
RESET="]R"
# ANSI COLORS
# Erase to end of line
CRE="
[K"s
# Clear and reset Screen
CLEAR="c"
# Normal color
NORMAL="[0;39m"
# RED: Failure or error message
RED="[1;31m"
# GREEN: Success message
GREEN="[1;32m"
# YELLOW: Descriptions
YELLOW="[1;33m"
# BLUE: System mesages
BLUE="[1;34m"
# MAGENTA: Found devices or drivers
MAGENTA="[1;35m"
# CYAN: Questions
CYAN="[1;36m"
# BOLD WHITE: Hint
WHITE="[1;37m"


# Utilities

# test if string is alpha numeric
isalnum(){
  if [[ $1 =~ ^[[:alnum:]]+$ ]]; then
    return 0
  else
    return 1
  fi
}

# test if variable is an integer
isinteger () {
  [ $# -eq 1 ] || return 1
  case $1 in
    *[!0-9]*|"") return 1 ;;
    *) return 0 ;;
  esac
}

# print status message
print_status(){
  if [ -n "$SPLASH" ]; then
    plymouth --update="$1"
  else
    echo "$1"
  fi
}

# create device nodes
udev_extra_nodes() {
  grep '^[^#]' /etc/udev/links.conf | \
  while read type name arg1; do
    [ "$type" -a "$name" -a ! -e "/dev/$name" -a ! -L "/dev/$name" ] ||continue
    case "$type" in
      L) ln -s $arg1 /dev/$name ;;
      D) mkdir -p /dev/$name ;;
      M) mknod -m 600 /dev/$name $arg1 ;;
      *) echo "links.conf: unparseable line ($type $name $arg1)" ;;
    esac
  done
}

# clean bad lines from .env
clean_env(){
  local line
  grep -v "^#\|^$\|^export [A-Z0-9_-]*=[\"\'].*[\"\']" /.env | while read line; do
    [ -z "$line" ] && continue
    echo "Removing bad line ** $line ** from /.env ..."
    sed -i "/$line/d" /.env
  done
}

# provide environment variables from kernel cmdline and dhcp.log
do_env(){
  local item
  local varname
  local upvarname
  # parse kernel cmdline
  for item in $(cat /proc/cmdline) $(grep ^[a-zB] /tmp/dhcp.log | sort -u); do
    echo "$item" | grep -q "=" || item="${item}='yes'"
    varname="$(echo "$item" | awk -F\= '{print $1}')"
    # skip non alphanumeric strings
    isalnum "$varname" || continue
    upvarname="$(echo "$varname" | tr a-z A-Z)"
    case "$upvarname" in
      # set LINBOSERVER if server parameter is given
      SERVER) upvarname="LINBOSERVER" ;;
      # set HOSTGROUP from dhcp option nisdomain
      NISDOMAIN) upvarname="HOSTGROUP" ;;
      # set localmode if nonetwork parameter is given
      NONETWORK) upvarname="LOCALMODE" ;;
    esac
    # avoid duplicates
    sed -i "/$upvarname=/d" /.env
    # write entry to env file
    echo "export ${item/${varname}/${upvarname}}" >> /.env
  done
  clean_env
  source /.env
  # check if school network is present and set further environment accordingly
  if [ -n "$HOSTGROUP" -o "$HOSTNAME" = "pxeclient" ]; then
    echo "export LINBOSERVER='"${SERVERID}"'" >> /.env
    export LINBOSERVER="${SERVERID}"
  fi
  if [ -n "$SERVERID" ]; then
    # add fqdn to environment
    echo "export FQDN='"${HOSTNAME}.${DOMAIN}"'" >> /.env
    export FQDN="${HOSTNAME}.${DOMAIN}"
  else
    echo "export LOCALMODE='"yes"'" >> /.env
    export FQDN="$(linbo_hostname -f)"
    echo "export FQDN='"$FQDN"'" >> /.env
    export HOSTNAME="${FQDN%%.*}"
    echo "export HOSTNAME='"$HOSTNAME"'" >> /.env
    export DOMAIN="${FQDN/$HOSTNAME./}"
    echo "export DOMAIN='"$DOMAIN"'" >> /.env
  fi
  # provide linbocmd from cmdline
  [ -n "$LINBOCMD" ] && echo "$LINBOCMD" > /linbocmd
  # set hostname
  echo "$HOSTNAME" > /etc/hostname
  hostname "$HOSTNAME"
  # save mac address in enviroment
  export MACADDR="$(ifconfig | grep -B1 "$IP" | grep HWaddr | awk '{ print $5 }' | tr A-Z a-z)"
  echo "export MACADDR='"$MACADDR"'" >> /.env
  clean_env
}

# initial setup
init_setup(){
  mount -t proc /proc /proc
  echo 0 >/proc/sys/kernel/printk
  mount -t sysfs /sys /sys
  mount -t devtmpfs devtmpfs /dev
  ln -s /proc/self/fd /dev/fd
  if [ -e /etc/udev/links.conf ]; then
    udev_extra_nodes
  fi

  loadkmap < /etc/german.kbd
  ifconfig lo 127.0.0.1 up
  hostname linbo
  klogd >/dev/null 2>&1

  # Enable CPU frequency scaling
  for i in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do
    [ -f "$i" ] && echo "ondemand" > "$i" 2>/dev/null
  done

  # load modules from /etc/modules and cmdline
  for i in $(grep -v ^# /etc/modules) $loadmodules; do
    [ -z "$i" ] && continue
    echo "Loading module $i ..."
    modprobe "$i" || true
  done

  # set locale
  source /etc/locale.conf
  if [ -n "$LANG" ]; then
    export LANG="$LANG"
    export LC_TYPE="$LANG"
    export LC_MESSAGES="$LANG"
  fi
}

# copyfromcache files - copies files from cache to current dir
copyfromcache(){
  linbo_mountcache || return 1
  local item
  local RC="0"
  for item in $@; do
    if cp -af "/cache/$item" .; then
      echo "Copied $item successfully to $(pwd)."
      # read env again to get cache from copied start.conf
      [ "$item" = "start.conf" ] && source /.env
    else
      echo "Failed to copy $item to $(pwd)."
      RC="1"
    fi
  done
  return "$RC"
}

# copytocache - copies start.conf and hostname to local cache
copytocache(){
  linbo_mountcache || return 1
  local RC="0"
  if [ -s /start.conf ]; then
    if cp -a /start.conf /cache; then
      echo "Copied start.conf successfully to cache."
    else
      echo "Failed to copy start.conf to cache."
      RC="1"
    fi
  fi
  # save hostname for offline use
  if [ -n "$FQDN" ]; then
    if echo "$FQDN" > /cache/hostname; then
      echo "Successfully saved hostname $FQDN to cache."
    else
      echo "Failed to save hostname $FQDN to cache."
      RC="1"
    fi
  fi
  return "$RC"
}

# Utilities

# save windows activation tokens
save_winact(){
  # rename obsolete activation status file
  [ -e /mnt/linuxmuster-win/activation_status ] && mv /mnt/linuxmuster-win/activation_status /mnt/linuxmuster-win/win_activation_status
  # get windows activation status
  if [ -e /mnt/linuxmuster-win/win_activation_status ]; then
    grep -i ^li[cz]en /mnt/linuxmuster-win/win_activation_status | grep -i status | grep -i li[cz]en[sz][ei][de] | grep -vqi not && local win_activated="yes"
  fi
  if [ -n "$win_activated" ]; then
    echo "Windows is activated."
  else
    echo "Windows is not activated."
  fi
  # get msoffice activation status
  if [ -e /mnt/linuxmuster-win/office_activation_status ]; then
    grep -i ^li[cz]en /mnt/linuxmuster-win/office_activation_status | grep -i status | grep -i li[cz]en[sz][ei][de] | grep -vqi not && office_activated="yes"
  fi
  if [ -n "$office_activated" ]; then
    echo "MSOffice is activated."
  else
    echo "MSOffice is not activated or not installed."
  fi
  # remove activation status files
  rm -f /mnt/linuxmuster-win/*activation_status
  # get activation token files
  if [ -n "$win_activated" ]; then
    local windir="$(ls -d /mnt/[Ww][Ii][Nn][Dd][Oo][Ww][Ss])"
    # find all windows tokens and key files in windir (version independent)
    local win_tokens="$(find "$windir" -iname tokens.dat)"
    [ "$win_tokens" = "" ] || win_tokens="$win_tokens $(find "$windir" -iname pkeyconfig.xrm-ms)"
    #local win_tokensdat="$(ls /mnt/[Ww][Ii][Nn][Dd][Oo][Ww][Ss]/[Ss][Ee][Rr][Vv][Ii][Cc][Ee][Pp][Rr][Oo][Ff][Ii][Ll][Ee][Ss]/[Nn][Ee][Tt][Ww][Oo][Rr][Kk][Ss][Ee][Rr][Vv][Ii][Cc][Ee]/[Aa][Pp][Pp][Dd][Aa][Tt][Aa]/[Rr][Oo][Aa][Mm][Ii][Nn][Gg]/[Mm][Ii][Cc][Rr][Oo][Ss][Oo][Ff][Tt]/[Ss][Oo][Ff][Tt][Ww][Aa][Rr][Ee][Pp][Rr][Oo][Tt][Ee][Cc][Tt][Ii][Oo][Nn][Pp][Ll][Aa][Tt][Ff][Oo][Rr][Mm]/[Tt][Oo][Kk][Ee][Nn][Ss].[Dd][Aa][Tt] 2> /dev/null)"
    #local win_pkeyconfig="$(ls /mnt/[Ww][Ii][Nn][Dd][Oo][Ww][Ss]/[Ss][Yy][Ss][Ww][Oo][Ww]64/[Ss][Pp][Pp]/[Tt][Oo][Kk][Ee][Nn][Ss]/[Pp][Kk][Ee][Yy][Cc][Oo][Nn][Ff][Ii][Gg]/[Pp][Kk][Ee][Yy][Cc][Oo][Nn][Ff][Ii][Gg].[Xx][Rr][Mm]-[Mm][Ss] 2> /dev/null)"
  fi
  [ -n "$office_activated" ] && local office_tokens="$(ls /mnt/[Pp][Rr][Oo][Gg][Rr][Aa][Mm][Dd][Aa][Tt][Aa]/[Mm][Ii][Cc][Rr][Oo][Ss][Oo][Ff][Tt]/[Oo][Ff][Ff][Ii][Cc][Ee][Ss][Oo][Ff][Tt][Ww][Aa][Rr][Ee][Pp][Rr][Oo][Tt][Ee][Cc][Tt][Ii][Oo][Nn][Pp][Ll][Aa][Tt][Ff][Oo][Rr][Mm]/[Tt][Oo][Kk][Ee][Nn][Ss].[Dd][Aa][Tt] 2> /dev/null)"
  # test if files exist
  if [ -n "$win_activated" -a -z "$win_tokens" ]; then
    echo "No windows activation tokens found."
    win_activated=""
  fi
  if [ -n "$office_activated" -a -z "$office_tokens" ]; then
    echo "No office activation tokens found."
    office_activated=""
  fi
  # if no activation return
  [ -z "$win_activated" -a -z "$office_activated" ] && return
  # get local mac address
  local mac="$(linbo_mac | tr a-z A-Z)"
  # do not save if no mac address is available
  if [ -z "$mac" -o "$mac" = "OFFLINE" ]; then
    echo "Cannot determine mac address."
    return
  fi
  # get image name
  [ -s  /mnt/.linbo ] && local image="$(cat /mnt/.linbo)"
  # if an image is not yet created do nothing
  if [ -z "$image" ]; then
    echo "No image file found."
    return
  fi
  echo -e "Saving activation tokens ... "
  # archive name contains mac address and image name
  local archive="/cache/$mac.$image.winact.tar.gz"
  local tmparchive="/cache/tokens.tar.gz"
  # generate tar command
  local tarcmd="tar czf $tmparchive"
  [ -n "$win_tokens" ] && tarcmd="$tarcmd $win_tokens"
  [ -n "$office_tokens" ] && tarcmd="$tarcmd $office_tokens"
  # create temporary archive
  if ! $tarcmd; then
    echo "Sorry. Error on creating $tmparchive."
    return 1
  else
    echo "OK."
  fi
  # merge old and new if archive already exists
  local RC=0
  if [ -s "$archive" ]; then
    echo -e "Updating $archive ... "
    local tmpdir="/cache/tmp"
    local curdir="$(pwd)"
    [ -e "$tmpdir" ] && rm -rf "$tmpdir"
    mkdir -p "$tmpdir"
    tar xf "$archive" -C "$tmpdir" || RC="1"
    tar xf "$tmparchive" -C "$tmpdir" || RC="1"
    rm -f "$archive"
    rm -f "$tmparchive"
    cd "$tmpdir"
    tar czf "$archive" * || RC="1"
    cd "$curdir"
    rm -rf "$tmpdir"
  else # use temporary archive if it does not exist already
    echo -e "Creating $archive ... "
    rm -f "$archive"
    mv "$tmparchive" "$archive" || RC="1"
  fi
  # if error occured
  if [ "$RC" = "1" -o ! -s "$archive" ]; then
    echo "Failed. Sorry."
    return 1
  else
    echo "OK."
  fi
  # do not in offline mode
  [ -z "$LINBOSERVER" ] && return
  # trigger upload
  echo "Starting upload of windows activation tokens."
  rsync "$LINBOSERVER::linbo/winact/$(basename $archive).upload" /cache || true
}

# get and upload client's hardware info
do_hwinfo(){
  local hwinfo_gz="/cache/hwinfo.gz"
  local hwinfo_tmp="/tmp/hwinfo.gz"
  [ -s "$hwinfo_gz" ] && return 0
  echo "Collecting hardware info."
  hwinfo | gzip > "$hwinfo_gz" || rm -f "$hwinfo_gz"
  if [ -s "$hwinfo_gz" ]; then
    cp "$hwinfo_gz" /tmp
    rsync "$LINBOSERVER::linbo${hwinfo_tmp}" /tmp/dummy &> /dev/null || true
    rm -f "$hwinfo_tmp"
  fi
}

# save windows activation tokens
do_housekeeping(){
  local dev
  if linbo_mountcache; then
    do_hwinfo
  else
    echo "Housekeeping: Cannot mount cache partition."
    return 1
  fi
  [ -s /start.conf ] || return 1
  grep -iw ^root /start.conf | awk -F\= '{ print $2 }' | awk '{ print $1 }' | sort -u | while read device; do
    [ -b "$dev" ] || continue
    if linbo_mount "$dev" /mnt 2> /dev/null; then
      # save windows activation files
      ls /mnt/linuxmuster-win/*activation_status && save_winact
      umount /mnt
    fi
  done
}

# update linbo and install it locally
do_linbo_update(){
  local rebootflag="/tmp/.linbo.reboot"
  linbo_mountcache
  linbo_update
  # initiate warm start
  [ -e "$rebootflag" ] && linbo_warmstart
}

# disable auto functions from cmdline
disable_auto(){
  sed -e 's|^[Aa][Uu][Tt][Oo][Pp][Aa][Rr][Tt][Ii][Tt][Ii][Oo][Nn].*|AutoPartition = no|g
          s|^[Aa][Uu][Tt][Oo][Ff][Oo][Rr][Mm][Aa][Tt].*|AutoFormat = no|g
          s|^[Aa][Uu][Tt][Oo][Ii][Nn][Ii][Tt][Cc][Aa][Cc][Hh][Ee].*|AutoInitCache = no|g' -i /start.conf
}

# handle autostart from cmdline
set_autostart() {
  # return if autostart shall be suppressed generally
  if [ "$autostart" = "0" ]; then
    echo "Deactivating autostart generally."
    # set all autostart parameters to no
    sed -e 's|^[Aa][Uu][Tt][Oo][Ss][Tt][Aa][Rr][Tt].*|Autostart = no|g' -i /start.conf
    return
  fi
  # count [OS] entries in start.conf if there are any
  [ -s /start.conf ] || return
  grep -qi ^"\[OS\]" /start.conf || return
  local counts="$(grep -ci ^"\[OS\]" /start.conf)"
  # autostart OS at start.conf position given by autostart parameter
  local c=0
  local found=0
  local line=""
  while read -r line; do
    if echo "$line" | grep -qi ^"\[OS\]"; then
      let c++
      [ "$autostart" = "$c" ] && found=1
    fi
    # suppress autostart for other OS entries
    echo "$line" | grep -qi ^autostart || echo "$line" >> /start.conf.new
    # write autostart line for specific OS
    if [ "$found" = "1" ]; then
      echo "Activating autostart for os no. $c."
      echo "Autostart = yes" >> /start.conf.new
      found=0
    fi
  done </start.conf
  mv /start.conf.new /start.conf
}

network(){
  echo
  rm -f /tmp/linbo-network.done
  # iterate over ethernet interfaces
  local RC="0"
  local dev
  local ipaddr
  [ -z "$dhcpretry" ] && dhcpretry=3
  print_status "Requesting ip address per dhcp (retry=$dhcpretry) ..."
  for dev in $(grep ':' /proc/net/dev | awk -F\: '{ print $1 }' | awk '{ print $1}' | grep -v ^lo | sort); do
    ip link set dev "$dev" up
    # activate wol
    ethtool -s "$dev" wol g
    # check if using vlan
    if [ -n "$vlanid" ]; then
      print_status "Using vlan id $vlanid."
      vconfig add "$dev" "$vlanid"
      dev="$dev.$vlanid"
      ip link set dev "$dev" up
    fi
    # wifi support
    if [ "$dev" = "wlan0" -a -s /etc/wpa_supplicant.conf ]; then
      wpa_supplicant -B -c/etc/wpa_supplicant.conf -iwlan0
      [ -n "$dhcpretry_wifi" ] && dhcpretry="$dhcpretry_wifi"
    fi
    udhcpc -O nisdomain -n -i "$dev" -t $dhcpretry ; RC="$?"
    if [ "$RC" = "0" ]; then
      # set mtu
      [ -n "$mtu" ] && ifconfig "$dev" mtu $mtu
      ipaddr="$(grep ^ip= /tmp/dhcp.log | awk -F\' '{print $2}')"
      print_status "Interface $dev: got $ipaddr."
      break
    else
      print_status "Interface $dev: no ip."
    fi
  done
  # create environment
  do_env
  # Move away standard start.conf and try to download the current one
  mv /start.conf /start.conf.dist
  if [ -n "$LINBOSERVER" -a -n "$HOSTGROUP" ]; then
    print_status "Downloading start.conf from $LINBOSERVER ..."
    rsync -vL "$LINBOSERVER::linbo/start.conf.$HOSTGROUP" "/start.conf" 2>&1
  fi
  # set flag for working network connection and do additional stuff which needs
  # connection to linbo server
  if [ -s /start.conf ]; then
    print_status "Network connection to $LINBOSERVER established successfully."
    print_status "IP: $IP * Hostname: $HOSTNAME * MAC: $MACADDR * Server: $LINBOSERVER"
    # split downloaded start.conf
    linbo_split_startconf
    # first do linbo update
    do_linbo_update
    # time sync
    print_status "Starting time sync ..."
    # time sync with ntp server
    ntpd -q -p "$NTPSRV"
    # get onboot linbo-remote commands, if there are any
    local item
    for item in $HOSTNAME $IP; do
      rsync -L "$LINBOSERVER::linbo/linbocmd/$item.cmd" "/linbocmd" &> /dev/null
      if [ -s /linbocmd ]; then
        echo "$item.cmd successfully downloaded."
        break
      fi
    done
    # save linbo-remote noauto and disablegui cmds to variables
    if [ -s /linbocmd ]; then
      for item in noauto disablegui; do
        if grep -q $item /linbocmd; then
          eval $item=yes
          echo "$item=yes"
        fi
      done
    fi
    # save start.conf and hostname to cache
    copytocache
  fi
  # if start.conf could not be downloaded or does not contain [os] section
  if [ ! -s /start.conf ] || ([ -s /start.conf ] && ! grep -qi ^'\[os\]' /start.conf); then
    # No new version / no network available, look for cached copies of start.conf.
    echo "Trying to copy start.conf from cache."
    copyfromcache start.conf
    # Still nothing new, revert to old version.
    if [ -s /start.conf ]; then
      linbo_split_startconf
    else
      mv -f /start.conf.dist /start.conf
    fi
  fi
  # disable auto functions if noauto is given
  if [ -n "$noauto" ]; then
    echo "Disabling auto functions."
    autostart=0
    disable_auto
  fi
  # disable gui
  if [ -n "$disablegui" ]; then
    gui_ctl disable onboot
  fi
  # start.conf: set autostart if given on cmdline
  isinteger "$autostart" && set_autostart
  # get hostgroup from start.conf in offline mode
  if [ -z "$HOSTGROUP" ]; then
    [ -s /conf/linbo ] && source /conf/linbo
    [ -n "$group" ] && echo "export HOSTGROUP='"$group"'" >> /.env
  fi
  # start dropbear
  print_status "Starting ssh service."
  /sbin/dropbear -r /etc/dropbear/dropbear_dss_host_key -r /etc/dropbear/dropbear_rsa_host_key -s -g -p 2222
  # remove reboot flag, save windows activation
  do_housekeeping
  # done
  echo > /tmp/linbo-network.done
  print_status "Done."
}

# HW Detection
hwsetup(){
  rm -f /tmp/linbo-cache.done

  # start hw recognition
  echo > /sys/kernel/uevent_helper
  mkdir -p /run/udev
  udevd --daemon
  mkdir -p /dev/.udev/db/ /dev/.udev/queue/
  udevadm trigger --type=all --action=add --prioritized-subsystem=module,block,tpmrm,net,tty,input
  mkdir -p /dev/pts
  mount /dev/pts
  udevadm settle || true

  # mount efivar fs
  [ -d /sys/firmware/efi ] && mount -t efivarfs efivarfs /sys/firmware/efi/efivars

  export TERM_TYPE=pts

  # link blockdevices
  linbo_link_blkdev

  # start qemu guest
  dmidecode -s system-manufacturer | grep -q QEMU && qemu-ga -d

  #sleep 2
  touch /tmp/linbo-cache.done
}


# Main
clear

init_setup

timestamp="$(date +%Y%m%d-%H%M%S)"
exec > >(tee /tmp/init.log) 2>&1

echo
echo "### $timestamp init begin ###"

# print welcome message
source /.profile

# initial setup
echo
echo "Initializing hardware ..."
echo

hwsetup

# start plymouth boot splash daemon
if grep -qiw splash /proc/cmdline; then
  plymouthd --mode=boot --attach-to-session  # --pid-file=/run/plymouth/pid
  plymouth --show-splash
  SPLASH="yes"
fi

# do network setup
network

# execute linbo commands given on commandline
if [ -s /linbocmd ]; then
  OIFS="$IFS"
  IFS=","
  for cmd in $(cat /linbocmd); do
    [ "$cmd" = "noauto" -o "$cmd" = "disablegui" ] && continue
    # filter password
    if echo "$cmd" | grep -q ^linbo:; then
      msg="linbo_wrapper linbo:*****"
    else
      msg="linbo_wrapper $cmd"
    fi
    print_status "$msg"
    echo "$msg" 2>&1
    /usr/bin/linbo_wrapper "$cmd" | while read line; do
      line="${line/---/}"
      print_status "$line"
    done
  done
  IFS="$OIFS"
fi

# autoinitcache in case of nogui
linbo_autoinitcache | while read line; do
  line="${line/---/}"
  print_status "$line"
done

# seed cached torrents
linbo_seed

# collect firmware infos and send it
fwinfo="$(dmesg | grep firmware)"
[ -n "$fwinfo" ] && echo -e "### firmware info ###\n$fwinfo" >> /tmp/init.log

# merge logfiles
[ -s /tmp/linbo.log ] && cat /tmp/linbo.log >> /tmp/init.log
timestamp="$(date +%Y%m%d-%H%M%S)"
echo
echo "### $timestamp init end ###"
echo
mv /tmp/init.log /tmp/linbo.log

exit 0
