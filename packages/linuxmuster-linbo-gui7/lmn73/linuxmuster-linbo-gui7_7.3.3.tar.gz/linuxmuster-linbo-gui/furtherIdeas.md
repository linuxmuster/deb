# Further Ideas
These are some ideas that I have, that could be realized in the future:
- Show the name of the network administrator when an error occurs
