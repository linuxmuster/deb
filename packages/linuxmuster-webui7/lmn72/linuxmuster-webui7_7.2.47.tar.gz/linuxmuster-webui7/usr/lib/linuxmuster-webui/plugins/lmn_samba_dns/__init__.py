import logging
from .main import ItemProvider
from .views import Handler

logging.info('samba_dns.__init__.py: samba_dns loaded')
