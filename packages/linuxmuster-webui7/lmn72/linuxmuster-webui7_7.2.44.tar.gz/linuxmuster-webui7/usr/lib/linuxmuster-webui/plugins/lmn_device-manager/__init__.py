import logging
from .main import *
from .views import *

logging.info('lmn.device-manager.__init__.py: lmn.device-manager loaded')
