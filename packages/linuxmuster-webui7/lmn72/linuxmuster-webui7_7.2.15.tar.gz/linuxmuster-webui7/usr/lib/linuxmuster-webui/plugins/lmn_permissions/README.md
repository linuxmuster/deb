# Permissions extra plugin

Show all plugins and sidebar permissions as matrix for linuxmuster.net.
This also permit to have a global view of the api list.
