# Linuxmuster.net quotas plugin

Plugin to display, manage user and group quotas.
