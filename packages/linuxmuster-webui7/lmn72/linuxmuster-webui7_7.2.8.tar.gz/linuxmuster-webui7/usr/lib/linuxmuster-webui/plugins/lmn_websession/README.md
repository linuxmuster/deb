# LMN7 BBB Plugin

Create config file /etc/linuxmuster/webui/websession/websession_config.json

```
{
  "settings": {
    "bbbInstance": "https://bbb.example.com/bigbluebutton/api/",
    "bbbSecret": "herecomesthesecretkey"
  }
}
```

Create list file /etc/linuxmuster/webui/websession/websession_list.json

```
[]
```

