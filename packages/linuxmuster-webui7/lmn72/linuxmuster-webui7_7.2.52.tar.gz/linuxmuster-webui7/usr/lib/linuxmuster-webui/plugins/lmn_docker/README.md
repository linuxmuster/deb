# Docker extra plugin

This plugin manages some informations from container and images on a docker host, possibly per ssh.
