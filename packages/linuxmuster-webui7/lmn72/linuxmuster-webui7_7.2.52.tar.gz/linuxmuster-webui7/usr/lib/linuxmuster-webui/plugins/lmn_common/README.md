# Linuxmuster.net common plugin

Common tools to communicate with sophomorix and manipulate user and config files.
