# Linuxmuster.net printers plugin

DEPRECATED.
