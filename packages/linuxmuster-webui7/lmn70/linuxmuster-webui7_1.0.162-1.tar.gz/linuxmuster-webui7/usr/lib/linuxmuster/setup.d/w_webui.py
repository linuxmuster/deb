#!/usr/bin/python3
import subprocess

subprocess.run(['/usr/lib/linuxmuster-webui/etc/create_aj_cfg.sh'])
print("* WebUI Setup Success!")
