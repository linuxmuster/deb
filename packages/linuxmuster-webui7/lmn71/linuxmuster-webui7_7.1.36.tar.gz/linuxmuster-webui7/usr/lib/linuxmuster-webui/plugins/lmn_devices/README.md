# Linuxmuster.net devices plugin

Manage devices by reading/writing config file and importing it in the system.
