# Linuxmuster.net setup wizard plugin

Plugin to run the linuxmuster install process with frontend.
