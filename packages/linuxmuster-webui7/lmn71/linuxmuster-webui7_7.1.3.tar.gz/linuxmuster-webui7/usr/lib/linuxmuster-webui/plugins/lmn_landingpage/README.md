# Linuxmuster.net landingpage plugin

Welcome page containing user's informations.
