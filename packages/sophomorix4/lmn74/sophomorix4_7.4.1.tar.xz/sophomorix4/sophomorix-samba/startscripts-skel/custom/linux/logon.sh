#!/bin/sh
# custom logon
