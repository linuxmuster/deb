#!/bin/sh
# lmn7 sysstart
