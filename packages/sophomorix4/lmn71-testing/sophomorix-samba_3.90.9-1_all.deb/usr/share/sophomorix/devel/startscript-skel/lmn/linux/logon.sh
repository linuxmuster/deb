#!/bin/sh
# lmn7 logon
