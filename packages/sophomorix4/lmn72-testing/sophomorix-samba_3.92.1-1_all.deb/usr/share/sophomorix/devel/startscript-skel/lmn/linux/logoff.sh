#!/bin/sh
# lmn7 logoff
