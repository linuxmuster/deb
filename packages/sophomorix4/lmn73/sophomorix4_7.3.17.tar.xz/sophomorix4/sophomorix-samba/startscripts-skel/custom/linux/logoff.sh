#!/bin/sh
# custom logoff
