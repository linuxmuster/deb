# linuxmuster-base7
Management scripts for linuxmuster.net V7

Further information is available in the [Wiki](https://github.com/linuxmuster/linuxmuster-base7/wiki).

## Maintainance Details
    
Linuxmuster.net official | ![#c5f015](https://via.placeholder.com/15/c5f015/000000?text=+)  YES
:---: | :---: 
[Community support](https://ask.linuxmuster.net) | ![#c5f015](https://via.placeholder.com/15/c5f015/000000?text=+)  YES**
Actively developed | ![#c5f015](https://via.placeholder.com/15/c5f015/000000?text=+)  YES
Maintainer organisation |  Linuxmuster.net e.V.  
Primary maintainer | thomas@linuxmuster.net  
  
** The linuxmuster community consits of people who are nice and happy to help. They are not directly involved in the development though, and might not be able to help in any case.
