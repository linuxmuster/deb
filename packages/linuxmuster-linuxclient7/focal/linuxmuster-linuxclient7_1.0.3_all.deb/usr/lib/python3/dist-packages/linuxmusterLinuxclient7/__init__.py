#
# linuxmuster-linuxclient7 is a library for use with Linuxmuster.net
#