Module: ldapHelper
******************

This module is used to deal with all LDAP tasks, like performing searches and checking group memberships.

Members
=======
.. automodule:: linuxmusterLinuxclient7.ldapHelper
   :members: