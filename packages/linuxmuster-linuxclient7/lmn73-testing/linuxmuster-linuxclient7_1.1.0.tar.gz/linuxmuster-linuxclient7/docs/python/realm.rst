Module: realm
*************

This module is used to deal with all AD related things:

* Discovering domains
* Joining domains 
* Leaving domains
* Clearing the local user cache
* Pulling kerberos tickets using the computer account

Members
=======
.. automodule:: linuxmusterLinuxclient7.realm
   :members: