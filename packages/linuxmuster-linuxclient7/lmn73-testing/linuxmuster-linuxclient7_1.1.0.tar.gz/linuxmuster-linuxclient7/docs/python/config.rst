Module: config
**************

This module is used to deal with all config files:

* `/etc/linuxmuster-linuxclient7/network.conf`

Members
=======
.. automodule:: linuxmusterLinuxclient7.config
   :members: