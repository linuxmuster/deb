"""
LDAP Helper Module for linuxmuster-linuxclient7

This module provides LDAP connectivity to the Samba Active Directory server.
It handles authentication using Kerberos (GSSAPI) and provides search functionality
for querying user and group information from the AD directory.

Debian 13 Compatibility:
This module has been adapted to work with Debian 13 (Trixie), which has changes
in how Kerberos tickets are handled during PAM authentication.
"""

import ldap, ldap.sasl, sys, getpass, subprocess
from linuxmusterLinuxclient7 import logging, constants, config, user, computer

# Global variable to store the current LDAP connection
# This allows connection reuse across multiple queries
_currentLdapConnection = None

def serverUrl():
    """
    Returns the LDAP server URL
    
    Constructs the LDAP URL from the network configuration.
    Format: ldap://hostname
    
    :return: The server URL
    :rtype: str
    """
    rc, networkConfig = config.network()

    if not rc:
        return False, None

    serverHostname = networkConfig["serverHostname"]
    return 'ldap://{0}'.format(serverHostname)

def baseDn():
    """
    Returns the base Distinguished Name (DN) for LDAP searches
    
    Converts the domain name to LDAP DN format.
    Example: linuxmuster.lan -> dc=linuxmuster,dc=lan
    
    :return: The baseDN
    :rtype: str
    """
    rc, networkConfig = config.network()

    if not rc:
        return None

    domain = networkConfig["domain"]
    return "dc=" + domain.replace(".", ",dc=")

def conn():
    """
    Returns the LDAP connection object
    
    Establishes a connection if one doesn't exist yet.
    Returns None if connection cannot be established.
    
    :return: The LDAP connection object or None
    :rtype: ldap.ldapobject.LDAPObject or None
    """
    global _currentLdapConnection

    if _connect():
        return _currentLdapConnection
    
    return None

def searchOne(filter):
    """
    Searches the LDAP directory with a filter and returns the first matching object
    
    Performs a subtree search starting from the base DN and returns
    the first result as a Python dictionary.
    
    :param filter: A valid LDAP filter (e.g., "(sAMAccountName=username)")
    :type filter: str
    :return: Tuple (success, ldap object as dict). 
             Returns (False, None) if no object found or error occurred.
    :rtype: tuple
    
    Example:
        success, user_obj = searchOne("(sAMAccountName=jdoe)")
        if success:
            print(user_obj['cn'])  # Print the common name
    """
    if conn() == None:
        logging.error("Cannot talk to LDAP")
        return False, None

    try:
        # Execute LDAP search
        # - baseDn(): Starting point in the directory tree
        # - SCOPE_SUBTREE: Search this entry and all descendants
        # - filter: LDAP filter expression
        rawResult = conn().search_s(
                baseDn(),
                ldap.SCOPE_SUBTREE,
                filter
                )
    except Exception as e:
        logging.error("Error executing LDAP search!")
        logging.exception(e)
        return False, None

    try:
        result = {}

        # Check if we got any results
        # rawResult format: [(dn, {attributes}), ...]
        if len(rawResult) <= 0 or rawResult[0][0] == None:
            logging.debug(f"Search \"{filter}\" did not return any objects")
            return False, None

        # Parse the first result's attributes
        # rawResult[0][1] contains the attribute dictionary
        for k in rawResult[0][1]:
            if rawResult[0][1][k] != None:
                rawAttribute = rawResult[0][1][k]
                try:
                    # LDAP attributes are returned as byte arrays
                    # Decode them to strings
                    if len(rawAttribute) == 1:
                        # Single-valued attribute
                        result[k] = str(rawAttribute[0].decode())
                    elif len(rawAttribute) > 0:
                        # Multi-valued attribute (e.g., memberOf)
                        result[k] = []
                        for rawItem in rawAttribute:
                            result[k].append(str(rawItem.decode()))
                except UnicodeDecodeError:
                    # Skip attributes that can't be decoded (e.g., binary data)
                    continue
                
        return True, result

    except Exception as e:
        logging.error("Error while reading ldap search results!")
        logging.exception(e)
        return False, None

def isObjectInGroup(objectDn, groupName):
    """
    Check if a given object (user or computer) is a member of a specified group
    
    Uses the LDAP_MATCHING_RULE_IN_CHAIN (1.2.840.113556.1.4.1941) to check
    both direct and nested group memberships (transitive search).
    
    :param objectDn: The Distinguished Name of the object to check
    :type objectDn: str
    :param groupName: The sAMAccountName of the group
    :type groupName: str
    :return: True if the object is a member (directly or through nesting), False otherwise
    :rtype: bool
    
    Example:
        dn = "CN=John Doe,CN=Users,DC=linuxmuster,DC=lan"
        if isObjectInGroup(dn, "teachers"):
            print("User is a teacher")
    """
    logging.debug("= Testing if object {0} is a member of group {1} =".format(objectDn, groupName))
    
    # The filter uses the LDAP_MATCHING_RULE_IN_CHAIN rule which
    # automatically resolves nested group memberships
    rc, groupAdObject = searchOne("(&(member:1.2.840.113556.1.4.1941:={0})(sAMAccountName={1}))".format(objectDn, groupName))
    logging.debug("=> Result: {} =".format(rc))
    return rc

# --------------------
# - Helper functions -
# --------------------

def _connect():
    """
    Internal function to establish LDAP connection using Kerberos (GSSAPI)
    
    This function implements a Debian 13 compatible connection strategy:
    1. For root processes: Use machine account Kerberos ticket
    2. For user processes: Use user's Kerberos ticket
    3. Falls back gracefully if tickets are not available
    
    The function uses GSSAPI/Kerberos for authentication, which provides:
    - Secure authentication without transmitting passwords
    - Single sign-on capability
    - Integration with Active Directory
    
    :return: True if connection successful, False otherwise
    :rtype: bool
    """
    global _currentLdapConnection

    # Security check: Only allow LDAP connections for:
    # - Users who are members of the AD domain
    # - Root user (for system operations)
    # - Computer account operations
    if not user.isInAD() and not (user.isRoot() or not computer.isInAD()):
        logging.warning("Cannot perform LDAP search: User is not in AD!")
        _currentLdapConnection = None
        return False

    # Reuse existing connection if available
    if not _currentLdapConnection == None:
        return True

    # ============================================================================
    # DEBIAN 13 WORKAROUND: Machine Account Ticket Authentication
    # ============================================================================
    # In Debian 13 (Trixie), the PAM/SSSD Kerberos ticket creation behavior
    # changed. User tickets are not always available when LDAP queries are needed.
    # This workaround uses the machine account (computer account) credentials
    # as a fallback, which allows LDAP queries to succeed even without a user ticket.
    # ============================================================================
    
    try:
        import socket
        import os
        
        # Construct the machine principal name
        # Format: HOSTNAME$@REALM
        # The $ suffix is the AD convention for machine/computer accounts
        # Example: WORKSTATION1$@LINUXMUSTER.LAN
        hostname = socket.gethostname().upper().split('.')[0]
        machine_principal = f"{hostname}$@LINUXMUSTER.LAN"
        
        # ========================================================================
        # PATH 1: Root Process - Use Machine Account
        # ========================================================================
        # When running as root (e.g., during login hooks), we can use the
        # machine account keytab to obtain a Kerberos ticket
        if os.geteuid() == 0:
            # Use kinit with -k flag to authenticate using the system keytab
            # The keytab file (/etc/krb5.keytab) contains the machine account
            # password hash and is only readable by root
            kinit_result = subprocess.run(
                ['kinit', '-k', machine_principal],
                capture_output=True,
                text=True,
                timeout=10,
                env={'KRB5CCNAME': 'FILE:/tmp/krb5cc_0'}  # Store ticket in root's cache
            )
            
            if kinit_result.returncode == 0:
                logging.debug(f"Successfully obtained machine account ticket for {machine_principal}")
                
                # Set the Kerberos credential cache environment variable
                # This tells all Kerberos-aware libraries where to find the ticket
                os.environ['KRB5CCNAME'] = 'FILE:/tmp/krb5cc_0'
                
                # Initialize LDAP connection with GSSAPI (Kerberos) authentication
                # GSSAPI provides secure, ticket-based authentication
                sasl_auth = ldap.sasl.sasl({}, 'GSSAPI')
                _currentLdapConnection = ldap.initialize(serverUrl(), trace_level=0)
                
                # Disable LDAP referrals (not needed for single-domain setups)
                _currentLdapConnection.set_option(ldap.OPT_REFERRALS, 0)
                
                # Use LDAP protocol version 3 (required for SASL)
                _currentLdapConnection.protocol_version = ldap.VERSION3
                
                # Perform the actual SASL bind using the Kerberos ticket
                _currentLdapConnection.sasl_interactive_bind_s("", sasl_auth)
                
                logging.info("LDAP connected successfully with machine account")
                return True
            else:
                logging.error(f"kinit for machine account failed: {kinit_result.stderr}")
        
        # ========================================================================
        # PATH 2: Non-Root Process - Use User's Ticket
        # ========================================================================
        # When running as a regular user, try to use their Kerberos ticket
        # This ticket should have been created by PAM during login
        else:
            # Determine the path to the user's credential cache
            # Standard location: /tmp/krb5cc_<UID>
            uid = os.getuid()
            user_ccache = f"/tmp/krb5cc_{uid}"
            
            # Check if the user has a valid Kerberos ticket
            if os.path.exists(user_ccache):
                # Point LDAP library to the user's ticket cache
                os.environ['KRB5CCNAME'] = f'FILE:{user_ccache}'
                
                # Initialize LDAP connection with user's ticket
                sasl_auth = ldap.sasl.sasl({}, 'GSSAPI')
                _currentLdapConnection = ldap.initialize(serverUrl(), trace_level=0)
                _currentLdapConnection.set_option(ldap.OPT_REFERRALS, 0)
                _currentLdapConnection.protocol_version = ldap.VERSION3
                _currentLdapConnection.sasl_interactive_bind_s("", sasl_auth)
                
                logging.info("LDAP connected with user ticket")
                return True
            else:
                logging.warning(f"No Kerberos ticket found at {user_ccache}")
                
    except Exception as e:
        # If any error occurs during connection, clean up and log it
        _currentLdapConnection = None
        logging.error("LDAP bind failed!")
        logging.exception(e)
        return False

    # Connection failed through all available methods
    return False