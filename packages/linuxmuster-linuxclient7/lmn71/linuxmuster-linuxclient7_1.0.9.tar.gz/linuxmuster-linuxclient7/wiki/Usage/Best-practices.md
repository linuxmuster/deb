# Creating a new image
1. Reboot and sync
2. log in as linuxadmin
4. install new software
5. run `linuxmuster-linuxclient7 prepare-image` (This will do some cleanup and delete cached users)
6. reboot and create image