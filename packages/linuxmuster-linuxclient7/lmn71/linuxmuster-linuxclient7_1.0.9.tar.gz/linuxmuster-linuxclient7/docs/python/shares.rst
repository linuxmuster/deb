Module: shares
**************

This module is used to deal with mounting and unmounting samba shares.

Members
=======
.. automodule:: linuxmusterLinuxclient7.shares
   :members: