Module: user
************

This module is used to deal with users and their properties, like username and groups.

Members
=======
.. automodule:: linuxmusterLinuxclient7.user
   :members: