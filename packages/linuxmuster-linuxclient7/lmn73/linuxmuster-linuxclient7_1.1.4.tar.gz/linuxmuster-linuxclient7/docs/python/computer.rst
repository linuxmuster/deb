Module: computer
****************

This module is used to deal with all things related to the computer.

Members
=======
.. automodule:: linuxmusterLinuxclient7.computer
   :members: