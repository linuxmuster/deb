**Maintainer**: [your@email.com](mailto:your@email.com), [@your-github-name](https://github.com/your-github-name)
**Status**: 🧪 experimental | 🔧 testing | ✅ stable | 🚧 unmaintained

## About

Add a small description of your plugin

## Install

##### Dependencies
Run this to install the required dependencies

```bash
#!/bin/bash
echo "Add your dependencies here or remove this part in case there are no dependencies"
```

##### Files
Copy these files to the given locations and give them their respective rights.

`/etc/linuxmuster-linuxclient7/onSessionStarted.d/99-plugin-<your plugin>.sh`, `555`
```bash
#!/bin/bash
echo "Add your plugin code here"
```