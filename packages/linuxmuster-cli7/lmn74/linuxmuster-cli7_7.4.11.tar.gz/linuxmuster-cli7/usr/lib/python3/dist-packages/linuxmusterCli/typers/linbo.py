import os
import typer
from datetime import datetime
from typing_extensions import Annotated

from rich.console import Console
from rich.table import Table
from linuxmusterTools.lmnfile import LMNFile
from linuxmusterTools.linbo import LinboImageManager, list_workstations, last_sync_all
from .state import state
from .format import printf


LINBO_PATH = '/srv/linbo'
console = Console(emoji=False)
app = typer.Typer(help="Manage linbo images and groups.")

@app.command(help="Display all available linbo groups.")
def groups(school: Annotated[str, typer.Option("--school", "-s")] = 'default-school'):
    groups = Table()
    groups.add_column("Groups", style="green")
    groups.add_column("Devices", style="cyan")
    if school != 'default-school':
        prefix = f'{school}.'
    else:
        prefix = ''

    with LMNFile(f'/etc/linuxmuster/sophomorix/{school}/{prefix}devices.csv', 'r') as f:
        devices = f.read()

    data = [[c.header for c in groups.columns]]
    for file in os.listdir(LINBO_PATH):
        path = os.path.join(LINBO_PATH, file)
        if (
            file.startswith('start.conf.')
            and not file.endswith('.vdi')
            and not os.path.islink(path)
            and os.path.isfile(path)
        ):
            group = file.split(".")[-1]
            devices_count = 0
            for device in devices:
                if device['group'] == group:
                    devices_count += 1
            groups.add_row(group, str(devices_count))
            data.append([group, str(devices_count)])

    if state.format:
        printf.format(data)
    else:
        console.print(groups)

@app.command(help="Display all available linbo images.")
def images():
    images = Table(show_lines=True)
    images.add_column("Name", style="green")
    images.add_column("Size (MiB)", style="cyan")
    images.add_column("Backups", style="bright_magenta")
    images.add_column("Differential image", style="cyan")
    # images.add_column("Used in groups", style="cyan")

    data = [[c.header for c in images.columns]]
    lim = LinboImageManager()
    for name,group in lim.groups.items():
        size = str(round(group.base.size / 1024 / 1024))
        diff = "No"
        if group.diff_image:
            diff_size = round(group.diff_image.size / 1024 / 1024)
            diff = f"Yes ({diff_size} MiB)"
        images.add_row(name, size, '\n'.join(group.backups.keys()), diff)
        data.append([name, size, ','.join(group.backups.keys()), diff])

    if state.format:
        printf.format(data)
    else:
        console.print(images)

@app.command(help="Display last synchronisation date for all devices or the selected group.")
def lastsync(
    group: Annotated[str, typer.Argument()] = '',
    school: Annotated[str, typer.Option("--school", "-s")] = 'default-school',
    warning: Annotated[bool, typer.Option("--warning", "-w", help="Only show devices with a warning status (yellow, not synchronised for more than 7 days).")] = False,
    danger: Annotated[bool, typer.Option("--danger", "-d", help="Only show devices with a danger status (red, never synchronised or not for more than 30 days).")] = False,
):
    # Temporary UGLY solution. The code in linuxmusterTools must be rewritten

    status_filter = set()
    if warning:
        status_filter.add('warning')
    if danger:
        status_filter.add('danger')

    def keep(host):
        # A host is kept as soon as one of its images matches the requested
        # status, its other images are still displayed for the context.
        if not status_filter:
            return True
        return any(sync['status'] in status_filter for sync in host['image'])

    def image_version(sync_data):
        # ISO, not the locale-dependent format of the sync date: this also
        # goes to the csv/raw exports, which are meant to be grepped.
        version = sync_data.get('imageVersion')
        try:
            return datetime.strptime(version, '%Y%m%d%H%M').strftime('%Y-%m-%d %H:%M')
        except (TypeError, ValueError):
            return version or ''

    def format(sync_data):
        epoch = sync_data['date']
        status = sync_data['status']

        if epoch == 'Never':
            return '[red]No date found[/red]'
        color_map = {
            'danger': 'red',
            'warning': 'yellow',
            'success': 'green'
        }
        color = color_map[status]
        date = datetime.fromtimestamp(epoch).strftime('%c')
        rendered = f'[{color}]{date}[/{color}]'
        version = image_version(sync_data)
        if version:
            rendered += f' [dim](image {version})[/dim]'
        return rendered

    if group:
        devices = list_workstations(school=school, groups=[group])
    else:
        devices = list_workstations(school=school)

    last_sync_all(devices)

    for grp, hosts in devices.items():
        images = []
        if len(hosts['hosts']) > 0:
            images = [d['image'] for d in hosts['hosts'][0]['image']]
        if not images:
            continue

        filtered_hosts = [host for host in hosts['hosts'] if keep(host)]
        if not filtered_hosts:
            continue

        sync = Table(title=f"Group {grp} ({len(filtered_hosts)} device(s))")
        sync.add_column('Hostname', style="cyan")
        sync.add_column('IP', style="cyan")
        data = [[c.header for c in sync.columns]]
        for image in images:
            sync.add_column(f'Last synchronisation for {image}')
            # The console packs date, status (as a colour) and applied
            # version in one cell; exports keep one value per field.
            data[0].append(f'Last synchronisation for {image}')
            data[0].append(f'Status for {image}')
            data[0].append(f'Applied version of {image}')
        
        data[0].append('Group')

        for host in filtered_hosts:
            sync_by_image = {d['image']: d for d in host['image']}
            sync.add_row(
                host['hostname'],
                host['ip'],
                *[format(sync_by_image[image]) for image in images]
            )
            sync_fields = []
            for image in images:
                sync_data = sync_by_image[image]
                epoch = sync_data['date']
                sync_fields.append(
                    'Never' if epoch == 'Never'
                    else datetime.fromtimestamp(epoch).strftime('%Y-%m-%d %H:%M')
                )
                sync_fields.append(sync_data['status'])
                sync_fields.append(image_version(sync_data))
            data.append([
                host['hostname'],
                host['ip'],
                *sync_fields,
                grp
            ])

        if state.format:
            printf.format(data)
            print()
        else:
            console.print(sync)


