REM custom.cmd example
REM thomas@linuxmuster.net
REM 20210504
REM

REM Place your custom windows start commands here
