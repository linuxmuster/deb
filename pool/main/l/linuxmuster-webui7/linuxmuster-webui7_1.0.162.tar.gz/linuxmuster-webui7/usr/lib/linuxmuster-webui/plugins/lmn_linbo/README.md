# Linuxmuster.net linbo plugin

Plugin to manage linbo config files and images.
