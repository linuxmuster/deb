import logging
from .main import *  # load plugin modules
from .views import Handler

logging.info('lmn_landing.__init__.py: lmn_landing loaded')
