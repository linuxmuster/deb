# LMN7 Nextcloud Plugin

Create config file /etc/linuxmuster/webui/nextcloud/nextcloud_config.json

```
{
  "settings": {
    "nextcloudURL": "https://cloud.example.com",
    "toggleFullscreen": true,
    "askForUser": true,
  }
}
```

nextcloudURL = URL
toggleFullscreen = Make fullscreen after open
askForUser = prefill user