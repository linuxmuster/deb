"""
Module to configure sophomorix.
"""

# coding=utf-8
import os
import subprocess
from jadi import component
import re
from glob import glob
import base64
import json
import time
from secrets import token_bytes

from aj.api.http import get, post, delete, put, HttpPlugin
from aj.api.endpoint import endpoint, EndpointError, EndpointReturn
from aj.auth import authorize
from linuxmusterTools.lmnfile import LMNFile
from aj.plugins.lmn_common.api import allowed_roles, ALL_ROLES, config_path


@component(HttpPlugin)
class Handler(HttpPlugin):
    EMAIL_MAPPING = {
        'ä': 'ae',
        'ö': 'oe',
        'ü': 'ue',
        'ß': 'ss',
        '@': '\\@',
    }
    EMAIL_REVERSE_MAPPING = { v:k for (k, v) in EMAIL_MAPPING.items()}

    def __init__(self, context):
        self.context = context


    @post(r'/api/lmn/schoolsettings/determine-encoding')
    @authorize('lm:schoolsettings')
    @endpoint(api=True)
    def handle_api_session_sessions(self, http_context):
        """
        Determine encoding using sophomorix-check.

        :param http_context: HttpContext
        :type http_context: HttpContext
        :return: Encoding type of the file, e.g. utf-8
        :rtype: string
        """

        fileToCheck = http_context.json_body()['path']
        if os.path.isfile(fileToCheck) is False:
            os.mknod(fileToCheck)
        if os.path.isfile(fileToCheck):
            with LMNFile(fileToCheck, 'r') as f:
                return f.detect_encoding()
        return None


    @get(r'/api/lmn/schoolsettings')
    @authorize('lm:schoolsettings')
    @endpoint(api=True)
    def handle_api_get_schoolsettings(self, http_context):
        """
        Read the config file `school.conf`.

        :param http_context: HttpContext
        :type http_context: HttpContext
        :return: Settings in read mode
        :rtype: dict in read mode
        """

        path = f'{self.context.schoolmgr.configpath}school.conf'
        # Update each time the config_obj because it may have changed
        with LMNFile(path, 'r') as f:
            self.config_obj = f

        # Just export ConfigObj as dict for angularjs
        return dict(self.config_obj.data)

    @post(r'/api/lmn/schoolsettings')
    @authorize('lm:schoolsettings')
    @endpoint(api=True)
    def handle_api_write_schoolsettings(self, http_context):
        """
        Write the config file `school.conf`.

        :param http_context: HttpContext
        :type http_context: HttpContext
        :return: Settings in read mode
        :rtype: dict in read mode
        """

        path = f'{self.context.schoolmgr.configpath}school.conf'
        # Update each time the config_obj because it may have changed
        with LMNFile(path, 'r') as f:
            self.config_obj = f

        data = http_context.json_body()
        if 'admins_print' in data:
            for k, v in self.EMAIL_MAPPING.items():
                data['admins_print'] = data['admins_print'].replace(k, v)

        self.config_obj.write(data)

        # Update setup.ini with new schoolname
        with LMNFile('/var/lib/linuxmuster/setup.ini', 'r') as s:
            s.data['setup']['schoolname'] = data['school']['SCHOOL_LONGNAME']
            s.write(s.data)

    def _filter_templates(self, filename, school=''):
        """
        Test if the name respects the sophomorix scheme for school-defined latex templates, something like:
        <schoolname>.<yourname>-<LANG>-<num>-template.tex

        See https://github.com/linuxmuster/sophomorix4/blob/bionic/sophomorix-samba/lang/latex/README.latextemplates.

        :param school: school
        :type school: string
        :param file: name of the file
        :type file: string
        :return: result of the test
        :rtype: dict with groups values
        """

        pattern = re.compile(
            school + r'\.?([^-]*)-([A-Z]+)-(\d+)-template\.tex')
        m = re.match(pattern, filename)
        if m is None:
            return None
        data = m.groups()
        template = {
            'filename': filename,
            'name': data[0],
            'lang': data[1],
            'numberPerPage': int(data[2])
        }
        return template

    @get(r'/api/lmn/schoolsettings/latex-templates')
    @authorize('lm:schoolsettings')
    @endpoint(api=True)
    def handle_api_latex_template(self, http_context):
        """
        Get list of latex templates for printing with sophomorix.

        :param http_context: HttpContext
        :type http_context: HttpContext
        """

        templates_multiple = []
        templates_individual = []
        sophomorix_default_path = '/usr/share/sophomorix/lang/latex/templates/'

        # Search for school defined templates in the global dir. Should not happen, since it's not the attended dir.
        for path in glob(sophomorix_default_path + "*tex"):
            filename = path.split('/')[-1]
            template = self._filter_templates(filename)
            if template:
                template['path'] = path
                if template['numberPerPage'] > 1:
                    templates_multiple.append(template)
                else:
                    templates_individual.append(template)

        # School defined templates
        school = self.context.schoolmgr.school
        custom_templates_path = f'/etc/linuxmuster/sophomorix/{school}/latex-templates/'
        if os.path.isdir(custom_templates_path):
            for path in glob(custom_templates_path + "*tex"):
                filename = path.split('/')[-1]
                template = self._filter_templates(filename, school)
                if template:
                    template['path'] = os.path.join(custom_templates_path, filename)
                    if template['numberPerPage'] > 1:
                        templates_multiple.append(template)
                    else:
                        templates_individual.append(template)

        return templates_individual, templates_multiple

    @get(r'/api/lmn/subnets')
    @authorize('lm:globalsettings')
    @endpoint(api=True)
    def handle_api_get_subnet(self, http_context):
        """
        Get `subnets.csv` config file for subnets.

        :param http_context: HttpContext
        :type http_context: HttpContext
        :return: Settings in read mode
        :rtype: dict
        """

        path = '/etc/linuxmuster/subnets.csv'

        with LMNFile(path, 'r') as s:
            subnets = list(s.data)
        return subnets

    @post(r'/api/lmn/subnets')
    @authorize('lm:globalsettings')
    @endpoint(api=True)
    def handle_api_write_subnet(self, http_context):
        """
        Write `subnets.csv` config file for subnets.

        :param http_context: HttpContext
        :type http_context: HttpContext
        :return: Settings in read mode
        :rtype: dict
        """

        path = '/etc/linuxmuster/subnets.csv'

        data = http_context.json_body()
        with LMNFile(path, 'w') as f:
            f.write(data)

        try:
            subprocess.check_call('linuxmuster-import-subnets > /tmp/import_devices.log', shell=True)
        except Exception as e:
            raise EndpointError(None, message=str(e))

    @get(r'/api/lmn/config/customfields/(?P<role>.*)')
    @authorize('lm:schoolsettings')
    @endpoint(api=True)
    def handle_api_read_custom_config(self, http_context, role=''):
        """
        Read webui yaml config and return the settings for custom fields.

        :param http_context: HttpContext
        :type http_context: HttpContext
        :return: Settings in read mode
        :rtype: dict
        """

        base_display_dict = {
            'teachers': {1: '', 2: '', 3:''},
            'students': {1: '', 2: '', 3: ''},
        }

        def ensure_config_structure(config, number, role=None):
            base_custom_dict = {'show': False, 'editable': False, 'title': ''}
            if number:
                base_role_dict = {
                    str(i+1):base_custom_dict
                    for i in range(number)
                }
            else:
                base_role_dict = base_custom_dict

            base_config_dict = {
                'globaladministrators': {},
                'schooladministrators': {},
                'teachers': {},
                'students': {},
            }

            if role is None:
                for role in base_config_dict:
                    role_dict = config.get(role, {})

                    if role_dict:
                        for i in range(number):
                            idx = str(i+1)
                            role_dict[idx] = role_dict.get(idx, base_custom_dict)
                            for key, value in base_custom_dict.items():
                                role_dict[idx][key] = role_dict[idx].get(key, value)
                        base_config_dict[role] = role_dict
                    else:
                        base_config_dict[role] = base_role_dict
                return base_config_dict
            else:
                role_dict = config.get(role, {})

                if role_dict:
                    for i in range(number):
                        idx = str(i+1)
                        role_dict[idx] = role_dict.get(idx, base_custom_dict)
                        for key, value in base_custom_dict.items():
                            role_dict[idx][key] = role_dict[idx].get(key, value)

                    return role_dict
                return base_role_dict


        school = self.context.schoolmgr.school
        custom_config_path = f'/etc/linuxmuster/sophomorix/{school}/custom_fields.yml'
        custom_config = {}
        if os.path.isfile(custom_config_path):
            with LMNFile(custom_config_path, 'r') as config:
                custom_config = config.read()

        password_templates = custom_config.get('passwordTemplates', {})
        password_templates['multiple'] = password_templates.get('multiple', '')
        password_templates['individual'] = password_templates.get('individual', '')

        config_dict = {
            'custom': ensure_config_structure(custom_config.get('custom', {}), 5),
            'customMulti': ensure_config_structure(custom_config.get('customMulti', {}), 5),
            'customDisplay': custom_config.get('customDisplay', base_display_dict),
            'proxyAddresses': ensure_config_structure(custom_config.get('proxyAddresses', {}), 0),
            'passwordTemplates': password_templates,
        }

        if role:
            role_dict = {
                'custom': ensure_config_structure(config_dict['custom'], 5, role),
                'customMulti': ensure_config_structure(config_dict['customMulti'], 5, role),
                'customDisplay': config_dict['customDisplay'].get(role, {1: '', 2: '', 3:''}),
                'proxyAddresses': ensure_config_structure(config_dict['proxyAddresses'], 0, role),
            }
            return role_dict
        return config_dict


    @post(r'/api/lmn/config/customfields')
    @authorize('lm:schoolsettings')
    @endpoint(api=True)
    def handle_api_save_custom_config(self, http_context):
        """
        Save customs sophomorix fields settings in the webui yaml config.

        :param http_context: HttpContext
        :type http_context: HttpContext
        :return:
        :rtype:
        """

        custom_config = http_context.json_body()['config']
        school = self.context.schoolmgr.school
        custom_config_path = f'/etc/linuxmuster/sophomorix/{school}/custom_fields.yml'
        with LMNFile(custom_config_path, 'w') as config:
            config.write(custom_config)

    PASSWORD_CONSTRAINTS_PATH = '/etc/linuxmuster/tools/password_constraints.yml'
    PASSWORD_CONSTRAINTS_ROLES = [
        'student', 'teacher', 'parent', 'staff', 'schooladministrator', 'globaladministrator',
    ]

    @get(r'/api/lmn/config/passwordconstraints')
    @authorize('lm:schoolsettings')
    @endpoint(api=True)
    def handle_api_read_password_constraints(self, http_context):
        """
        Read the password constraints config
        (/etc/linuxmuster/tools/password_constraints.yml). Every known role
        is always present under 'default' (empty rule list if unconfigured),
        so the frontend never has to guard against missing keys.

        'schools' is scoped by the caller's actual sophomorixRole (like
        lmn_users/views/passwords.py's _checkPasswordPermissions), not by
        the session's active school: global-administrators get every
        school's override, everyone else only their current school's,
        never another school's.

        :param http_context: HttpContext
        :type http_context: HttpContext
        :return: Configuration, with keys 'default' and 'schools' (all schools for global-administrators, own school only otherwise)
        :rtype: dict
        """

        config = {}
        if os.path.isfile(self.PASSWORD_CONSTRAINTS_PATH):
            with LMNFile(self.PASSWORD_CONSTRAINTS_PATH, 'r') as f:
                config = f.read() or {}

        default = config.get('default', {})
        for role in self.PASSWORD_CONSTRAINTS_ROLES:
            default.setdefault(role, [])

        identity_role = self.context.ldapreader.getval(f'/users/{self.context.identity}', 'sophomorixRole')
        schools = config.get('schools', {})

        if identity_role == 'globaladministrator':
            scoped_schools = schools
        elif identity_role == 'schooladministrator':
            school = self.context.schoolmgr.school
            scoped_schools = {school: schools[school]} if school in schools else {}
        else:
            return {}

        return {
            'default': default,
            'schools': scoped_schools,
        }

    @post(r'/api/lmn/config/passwordconstraints')
    @authorize('lm:schoolsettings')
    @endpoint(api=True)
    def handle_api_save_password_constraints(self, http_context):
        """
        Validate and save the password constraints config.

        'schools' is scoped by the caller's actual sophomorixRole, like
        handle_api_read_password_constraints: global-administrators may
        write any school present in the posted 'schools' payload (every
        other school's existing override is preserved untouched);
        everyone else may only write their own current school, any other
        school in the payload is ignored.

        The global 'default' rules are only changed by global-administrators:
        'lm:schoolsettings' (required to reach this endpoint at all) is also
        granted to school-administrators, so a posted 'default' that actually
        differs from what's on disk is rejected unless the caller also holds
        'lm:globalsettings'. Omitting 'default' (or resending it unchanged)
        never triggers this check, so school-administrators can still save
        their own school's override normally.

        Every rule is validated with linuxmusterTools' own rule builder
        before writing (pure validation, no Samba/LDAP access), so a
        malformed rule (unknown type, invalid classes, bad count) is
        rejected here instead of silently breaking lmnapi/webui/cli later.

        :param http_context: HttpContext
        :type http_context: HttpContext
        :return:
        :rtype:
        """

        from linuxmusterTools.passwords import PasswordRules

        posted_config = http_context.json_body()['config']
        identity_role = self.context.ldapreader.getval(f'/users/{self.context.identity}', 'sophomorixRole')

        config = {}
        if os.path.isfile(self.PASSWORD_CONSTRAINTS_PATH):
            with LMNFile(self.PASSWORD_CONSTRAINTS_PATH, 'r') as f:
                config = f.read() or {}

        config.setdefault('default', {})
        if 'default' in posted_config and posted_config['default'] != config['default']:
            with authorize('lm:globalsettings'):
                config['default'] = posted_config['default']

        posted_schools = posted_config.get('schools', {})
        if identity_role == 'globaladministrator':
            config.setdefault('schools', {}).update(posted_schools)
        else:
            school = self.context.schoolmgr.school
            config.setdefault('schools', {})[school] = posted_schools.get(school, {})

        role_rule_lists = list(config.get('default', {}).values())
        for school_rules in config.get('schools', {}).values():
            role_rule_lists.extend(school_rules.values())

        for rules in role_rule_lists:
            for entry in rules:
                try:
                    PasswordRules.build(entry)
                except (ValueError, KeyError, TypeError, AttributeError) as e:
                    raise EndpointError(None, message=str(e))

        with LMNFile(self.PASSWORD_CONSTRAINTS_PATH, 'w') as f:
            f.write(config)

    @get(r'/api/lmn/holidays')
    @authorize('lm:schoolsettings')
    @endpoint(api=True)
    def handle_api_get_holidays(self, http_context):
        """
        Get `holidays.yml` config file for holidays.

        :param http_context: HttpContext
        :type http_context: HttpContext
        :return: Settings in read mode
        :rtype: dict
        """

        school = self.context.schoolmgr.school
        path = f'/etc/linuxmuster/sophomorix/{school}/holidays.yml'

        try:
            with LMNFile(path, 'r') as s:
                return [{
                    'name': name,
                    'start': dates['start'],
                    'end': dates['end'],
                } for name, dates in s.data.items()]
        except AttributeError:
            return []

    @post(r'/api/lmn/holidays')
    @authorize('lm:schoolsettings')
    @endpoint(api=True)
    def handle_api_write_holidays(self, http_context):
        """
        Write `holidays.yml` config file for holidays.

        :param http_context: HttpContext
        :type http_context: HttpContext
        :return: Settings in read mode
        :rtype: dict
        """

        school = self.context.schoolmgr.school
        path = f'/etc/linuxmuster/sophomorix/{school}/holidays.yml'

        data = http_context.json_body()
        holidays = {holiday['name']: {
            'start': holiday['start'],
            'end': holiday['end']}
            for holiday in data
        }
        with LMNFile(path, 'w') as f:
            f.write(holidays)

    @get(r'/api/lmn/edulution/api-status')
    @endpoint(api=True)
    def handle_api_get_edulution_status(self, http_context):
        """
        Check the status of edulution requirements

        :param http_context: HttpContext
        :type http_context: HttpContext
        :return: Status of api
        :rtype: dict
        """

        status = {
            "api_installed": False,
            "api_running": False
        }

        if os.path.exists("/etc/linuxmuster/api/config.yml"):
            status['api_installed'] = True

        try:
            if os.system('systemctl is-active --quiet linuxmuster-api') == 0:
                status['api_running'] = True
        except:
            pass

        return status
    
    @post(r'/api/lmn/edulution/generate')
    @endpoint(api=True)
    def handle_api_get_edulution_generate(self, http_context):
        """
        Generate the edulution setup hash

        :param http_context: HttpContext
        :type http_context: HttpContext
        :return: Edulution Setup Hash
        :rtype: str
        """
        
        if os.getuid() != 0:
            return EndpointReturn(403)
        
        external_domain = http_context.json_body()['external_domain']
        binduser_name = http_context.json_body()['binduser_name']
        binduser_dn = http_context.json_body()['binduser_dn']

        secret_path = os.path.join('/etc/linuxmuster/.secret/', binduser_name)

        if not os.path.isfile(secret_path):
            return EndpointReturn(403)
        else:
            with open(secret_path, 'r') as f:
                binduser_password = f.read()

        data = json.dumps({
            "external_domain": external_domain,
            "binduser_name": binduser_name,
            "binduser_dn": binduser_dn,
            "binduser_password": binduser_password,
            "timestamp": time.time()
        })

        return base64.b64encode(data.encode('utf-8'))

    @get(r'/api/lmn/webuisettings/allowed_roles')
    @endpoint(api=True)
    def handle_api_get_webuisettings(self, http_context):
        """
        Get the allowed roles from /etc/linuxmuster/webui/config.yml

        :param http_context: HttpContext
        :type http_context: HttpContext
        """


        if os.getuid() != 0:
            return EndpointReturn(403)

        with LMNFile(config_path, 'r') as f:
            lmconfig = f.read()

        return lmconfig['linuxmuster'].get('auth', {}).get('allowed_roles', ALL_ROLES)

    @post(r'/api/lmn/webuisettings/allowed_roles')
    @endpoint(api=True)
    def handle_api_post_webuisettings(self, http_context):
        """
        Save the allowed roles to /etc/linuxmuster/webui/config.yml

        :param http_context: HttpContext
        :type http_context: HttpContext
        """


        if os.getuid() != 0:
            return EndpointReturn(403)

        posted_roles = http_context.json_body()['allowed_roles']
        valid_roles = [role for role in posted_roles if role in ALL_ROLES]

        with LMNFile(config_path, 'r') as f:
            lmconfig = f.read()

        if not lmconfig['linuxmuster'].get('auth', False):
            lmconfig['linuxmuster']['auth'] = {}

        lmconfig['linuxmuster']['auth']['allowed_roles'] = valid_roles

        with LMNFile(config_path, 'w') as f:
            f.write(lmconfig)

    def _restart_api_service(self):
        """
        Restart linuxmuster-api so it picks up the config.yml just written
        (host_keys/host_key_auth are only read once at process startup).
        """

        try:
            subprocess.check_call(['systemctl', 'restart', 'linuxmuster-api'])
        except (subprocess.CalledProcessError, FileNotFoundError):
            pass

    @get(r'/api/lmn/apisettings')
    @endpoint(api=True)
    def handle_api_get_apisettings(self, http_context):
        """
        Get the api keys from /etc/linuxmuster/api/config.yml

        :param http_context: HttpContext
        :type http_context: HttpContext
        """


        if os.getuid() != 0:
            return EndpointReturn(403)

        apiconfig_path = "/etc/linuxmuster/api/config.yml"

        if os.path.isfile(apiconfig_path):
            with LMNFile(apiconfig_path, 'r') as f:
                apiconfig = f.read()

            config = {
                'keys': apiconfig.get('host_keys', []),
                'enable_host_auth': apiconfig.get('host_key_auth', False)
            }

            apiconfig = {}

            return config

        return None

    @delete(r'/api/lmn/apikeys/(?P<keyname>[^/]*)')
    @endpoint(api=True)
    def handle_api_delete_apikey(self, http_context, keyname=''):
        """
        Delete a specific api key secret from /etc/linuxmuster/api/config.yml

        :param http_context: HttpContext
        :type http_context: HttpContext
        """


        if os.getuid() != 0:
            return EndpointReturn(403)

        apiconfig_path = "/etc/linuxmuster/api/config.yml"

        if os.path.isfile(apiconfig_path):
            with LMNFile(apiconfig_path, 'r') as f:
                apiconfig = f.read()

            if keyname in apiconfig.get('host_keys', []):
                del apiconfig['host_keys'][keyname]

            with LMNFile(apiconfig_path, 'w') as f:
                f.write(apiconfig)

        self._restart_api_service()

    @post(r'/api/lmn/apikeys')
    @endpoint(api=True)
    def handle_api_post_apisettings(self, http_context):
        """
        Save the api keys to /etc/linuxmuster/api/config.yml

        :param http_context: HttpContext
        :type http_context: HttpContext
        """


        if os.getuid() != 0:
            return EndpointReturn(403)

        apiconfig_path = "/etc/linuxmuster/api/config.yml"
        config = http_context.json_body()['config']

        with LMNFile(apiconfig_path, 'r') as f:
            apiconfig = f.read()

        for key, details in config['api_keys'].items():
            if details.get('ips', None) == []:
                del details['ips']

        apiconfig['host_key_auth'] = config['enable_host_auth']
        apiconfig['host_keys'] = config['api_keys']

        with LMNFile(apiconfig_path, 'w') as f:
            f.write(apiconfig)

        self._restart_api_service()

    @put(r'/api/lmn/apikeys')
    @endpoint(api=True)
    def handle_api_put_apikey(self, http_context):
        """
        Generate a secret for a new key and save it in the config.yml

        :param http_context: HttpContext
        :type http_context: HttpContext
        """


        if os.getuid() != 0:
            return EndpointReturn(403)

        apiconfig_path = "/etc/linuxmuster/api/config.yml"
        key = http_context.json_body()['key']

        key['secret'] = base64.b64encode(token_bytes(64)).decode()

        with LMNFile(apiconfig_path, 'r') as f:
            apiconfig = f.read()

        if not apiconfig.get('host_keys', []):
            apiconfig['host_keys'] = {}

        apiconfig['host_keys'][key['name']] = {
            'secret': key['secret'],
            'user': key['user'],
        }

        if key['ips']:
            apiconfig['host_keys'][key['name']]['ips'] = key['ips']

        with LMNFile(apiconfig_path, 'w') as f:
            f.write(apiconfig)

        self._restart_api_service()

        return key['secret']
