angular.module('lmn.settings').controller('LMglobalSettingsController', ($scope, $http, $sce, $location, notify, pageTitle, identity, messagebox, validation, config, core, locale, gettext) => {
    pageTitle.set(gettext('Global Settings'));

    config.load();
    $scope.config = config;
    $scope.all_roles = ['globaladministrator', 'schooladministrator', 'teacher', 'student', 'parent', 'staff']

    $scope.newClientCertificate = {
        c: 'NA',
        st: 'NA',
        o: '',
        cn: ''
    };

    $scope.showNewApiKey = false;
    $scope.showUpdateApiKey = false;
    $scope.showAddApiKeyIp = false;
    $scope.showApiKeySecret = false;
    $scope.apiKeySecret = '';
    $scope._ = {'newIp' : '', 'newApiUser': {'label':''}};
    $scope.searchText = gettext('Search user by login, firstname or lastname (min. 3 chars)');

    // Bad trick because validation is wrong defined
    validation.set([], 'devices')

    $scope.activetab = 0;

    $scope.help_trusted_domains = gettext(
        "If Ajenti is installed behind a proxy, oder reachable by a fqdn other than provided by the host,\n" +
        "you can then specify the other domains here, and by this way avoiding some resources loading problems."
    )

    $scope.help_trusted_proxies = gettext(
        "If Ajenti is installed behind one or more proxies, specify the ip of these proxies here, in order to\n" +
        "get the real client ip address."
    )

    $scope.help_certificate = gettext(
        "This certificate is the default certificate used to create client certificate and to provide https connection.\n" +
        "Using a Let's Encrypt certificate here will break the client certificate generator.\n" +
        "Using a self-generated certificate is fine here."
    );

    $scope.help_fqdn_certificate = gettext(
        "If you have a special certificate for your domain, like a Let's Encrypt certificate, put it there.\n" +
        "If you are not sure, just use the same certificate as the one above."
    );

    $http.get('/api/lmn/subnets').then((resp) => $scope.subnets = resp.data);

    $scope.removeSubnet = (subnet) => {
        messagebox.show({
            text: gettext('Are you sure you want to delete permanently this subnet ?'),
            positive: gettext('Delete'),
            negative: gettext('Cancel')
        }).then(() => $scope.subnets.remove(subnet))
    }

    $scope.addSubnet = () => {
        $scope.subnets.push({'routerIp':'', 'network':'', 'beginRange':'', 'endRange':'', 'setupFlag':''});
    }

    $scope.saveApplySubnets = () => {
        $http.post('/api/lmn/subnets', $scope.subnets).then(() => {
            notify.success(gettext('Saved'));
        });
    }

    $scope.getSmtpConfig = () => {
        config.getSmtpConfig().then((smtpConfig) => $scope.smtp_config = smtpConfig);
    };

    $scope.add_trusted_proxy = () => {
        config.data.trusted_proxies.push("");
    };

    $scope.add_trusted_domain = () => {
        config.data.trusted_domains.push("");
    };

    $scope.delete_trusted_proxy = (proxy) => {
        messagebox.show({
            title: gettext(`Remove ${proxy}`),
            text: gettext(`Do you really want to remove the proxy ${proxy} from the list ?`),
            positive: gettext('Delete'),
            negative: gettext('Cancel')
        }).then(() => {
            var pos = $scope.config.data.trusted_proxies.indexOf(proxy);
            $scope.config.data.trusted_proxies.splice(pos, 1);
            notify.success(gettext(`${proxy} removed`));
        });
    };

    $scope.delete_trusted_domain = (domain) => {
        messagebox.show({
            title: gettext(`Remove ${domain}`),
            text: gettext(`Do you really want to remove the domain ${domain} from the list ?`),
            positive: gettext('Delete'),
            negative: gettext('Cancel')
        }).then(() => {
            var pos = $scope.config.data.trusted_domains.indexOf(domain);
            $scope.config.data.trusted_domains.splice(pos, 1);
            notify.success(gettext(`${domain} removed`));
        });
    };

    identity.promise.then(() => {
       // $scope.newClientCertificate.o = identity.machine.name;
       // passwd.list().then((data) => {
       //    $scope.availableUsers = data;
       //    $scope.$watch('newClientCertificate.user', () => $scope.newClientCertificate.cn = `${identity.user}@${identity.machine.hostname}`);
       //    $scope.newClientCertificate.user = 'root';
       // });
       $http.get('/api/core/languages').then(rq => $scope.languages = rq.data);
    });


    $scope.$watch('config.data.language', () => {
       if (config.data) {
          locale.setLanguage(config.data.language);
       }
    });

    $scope.save = () => {
        config.save().then(data =>
            notify.success(gettext('Global config saved'))
        ).catch(() =>
            notify.error(gettext('Could not save global config')));

        if ($scope.smtp_config) {
            config.setSmtpConfig($scope.smtp_config).then(data =>
                notify.success(gettext('Smtp config saved'))
            ).catch(() =>
                notify.error(gettext('Could not save smtp config')));
        }
    }

    $scope.createNewServerCertificate = () => {
       messagebox.show({
          title: gettext('Self-signed certificate'),
          text: gettext('Generating a new certificate will void all existing client authentication certificates!'),
          positive: gettext('Generate'),
          negative: gettext('Cancel')
       }).then(() => {
          config.data.ssl.client_auth.force = false;
          notify.info(gettext('Generating certificate'), gettext('Please wait'));
          return $http.get('/api/settings/generate-server-certificate').then(function(resp) {
             notify.success(gettext('Certificate successfully generated'));
             config.data.ssl.enable = true;
             config.data.ssl.certificate = resp.data.path;
             config.data.ssl.client_auth.certificates = [];
             $scope.save();
          }, (err) => notify.error(gettext('Certificate generation failed'), err.message));
       });
    }

    $scope.showSMTPPassword = false;
    $scope.toggleShowSMTPPassword = () => $scope.showSMTPPassword = !$scope.showSMTPPassword;

    $scope.restart = () => core.restart();

    $scope.getTfaConfig = () => {
        config.getTfaConfig().then((tfaConfig) => {
            $scope.tfa_config = tfaConfig;
            $scope.tfaList = [];
            Object.entries($scope.tfa_config).forEach(([user_prov, totp]) => {
                user = user_prov.split("@")[0];
                authprov = user_prov.split("@")[1];
                for (tfa of totp.totp) {
                    $scope.tfaList.push({"user": user, "provider": authprov, "created": tfa.created, "desc": tfa.description});
                }
            });
        });
    };

    $scope.deleteTfa = (tfa) => {
        data = {'type':'delete', 'userid': `${tfa.user}@${tfa.provider}`, 'timestamp': `${tfa.created}`};
        config.deleteTfa(data).then(() => {
            notify.success("Deleted !");
            index = $scope.tfaList.indexOf(tfa);
            $scope.tfaList.splice(index, 1);
        });
    };

    $scope.checkEdulution = () => {

        $scope.edulutionStatus = {
            api_installed: null,
            api_running: null,
            binduser_created: null,
            binduser: null,
            external_domain: window.location.hostname
        }

        $http.get('/api/lmn/edulution/api-status').then((res) => {
            $scope.edulutionStatus["api_installed"] = res.data["api_installed"]
            $scope.edulutionStatus["api_running"] = res.data["api_running"]
        });
        $http.get('/api/lmn/sophomorixUsers/bindusers/global').then((res) => {
            angular.forEach(res.data, function(value, key) {
                if (value.sAMAccountName == "edulutionui-binduser") {
                    $scope.edulutionStatus["binduser_created"] = true;
                    $scope.edulutionStatus["binduser"] = value;
                    console.log(value)
                }
            });
            if ($scope.edulutionStatus["binduser_created"] == null) {
                $scope.edulutionStatus["binduser_created"] = false;
            }
        });
    }

    $scope.createEdulutionBinduser = () => {
        $http.post('/api/lmn/sophomorixUsers/bindusers/global', {binduser: "edulutionui-binduser"}).then((res) => {
            console.log(res.data);
            $scope.checkEdulution();
        });
    }

    $scope.generateEdulutionSetupToken = () => {
        if($scope.edulutionStatus["binduser"] != null) {
            $http.post('/api/lmn/edulution/generate', {
                external_domain: $scope.edulutionStatus["external_domain"],
                binduser_name: $scope.edulutionStatus["binduser"].sAMAccountName, 
                binduser_dn: $scope.edulutionStatus["binduser"].DN, 
            }).then((res) => {
                console.log(res.data);
                $scope.edulutionToken = res.data;
            });
        }        
    }

    $scope.copyEdulutionSetupToken = () => {
        navigator.clipboard.writeText($scope.edulutionToken).then(() => {
            notify.success("Copied to clipboard!");
        }).catch(() => {
            notify.error("Failed to copy!")
        });
    }

    $scope.getAllowedRoles = () => {
        $http.get("/api/lmn/webuisettings/allowed_roles").then((resp) => {
            $scope.allowed_roles = {};
            for (role of $scope.all_roles) {
                $scope.allowed_roles[role] = resp.data.indexOf(role) > -1;
            }
        });
    }

    $scope.saveWebui = () => {
        role_to_post = [];
        for (role of $scope.all_roles) {
            if ($scope.allowed_roles[role]) {
                role_to_post.push(role);
            }
        };
        $http.post("/api/lmn/webuisettings/allowed_roles", {'allowed_roles': role_to_post}).then((resp) => {
            notify.success('Roles successfully saved!');
            $scope.restart();
        });
    }

    $scope.getApiConfig = () => {
        $http.get("/api/lmn/apisettings").then((resp) => {
            if (!resp.data) {
                $scope.api_keys = {};
                $scope.missing_lmnapi = true;
            } else {
                $scope.missing_lmnapi = false;
                $scope.api_keys = {
                    'keys': resp.data.keys,
                    'enable_host_auth' : resp.data.enable_host_auth,
                };
            }
        });
    }

    // linuxmuster-api only reads host_keys at startup, so every change here
    // needs a restart to take effect. The backend does it, but it can fail
    // (service masked, not installed as a unit, ...) and the admin has to know.
    $scope.notifyApiRestart = (resp) => {
        if (resp.data && resp.data.api_restarted === false) {
            notify.error(gettext('Could not restart linuxmuster-api: the change will only take effect once it is restarted.'));
        }
    }

    $scope.deleteApiKey = (keyname) => {
        messagebox.show({
            title: gettext('Delete Api key'),
            text: gettext("Do you really want to delete the key "+ ( keyname ) + '?'),
            positive: 'Delete', negative: 'Cancel'}).then(() => {
                $http.delete(`/api/lmn/apikeys/${keyname}`).then((resp) => {
                    delete $scope.api_keys.keys[keyname];
                    notify.success(gettext('Key deleted'));
                    $scope.notifyApiRestart(resp);
                });
            });
    }

    $scope.showApiKey = (key) => {
        messagebox.show({
            title: gettext('Show Api key'),
            text: gettext("Do you really want to see this secret key ? It could be a security issue!"),
            positive: 'Show',
            negative: 'Cancel'}).then(() => {
                $scope.apiKeySecret = key.secret;
                $scope.showApiKeySecret = true;
            });
    }

    $scope.closeApiKeySecret = () => {
        $scope.showApiKeySecret = false;
        $scope.apiKeySecret = '';
    }

    $scope.copyApiKeySecret = () => {
        navigator.clipboard.writeText($scope.apiKeySecret).then(() => {
            notify.success(gettext('Copied to clipboard!'));
        });
    }

    $scope.addApiKey = () => {
        $scope.showNewApiKey = true;
        $scope.apiKey = {'name':'', 'ips':[], 'user':'', 'scope':[]};
    }

    $scope.editApiKey = (key, name) => {
        $scope.old_api_key_name = name;
        $scope.showUpdateApiKey = true;
        $scope.apiKey = {'name': name, 'ips': key.ips, 'user': key.user, 'secret': key.secret, 'scope': key.scope || []};
        $scope._.newApiUser = {'label': key.user, 'login': key.user};
    }

    $scope.saveApiKey = () => {
        $scope.showNewApiKey = false;
        $scope.apiKey.user = $scope._.newApiUser['login'];
        $http.put('/api/lmn/apikeys', {key: $scope.apiKey}).then((resp) => {
            notify.success(gettext('Api key added !'));
            $scope.notifyApiRestart(resp);
            $scope.apiKey['secret'] = resp.data.secret;
            $scope.api_keys.keys[$scope.apiKey['name']] = {
                'ips':$scope.apiKey['ips'],
                'scope':$scope.apiKey['scope'],
                'secret':$scope.apiKey['secret'],
                'user':$scope._.newApiUser['login'],
            };
            $scope._.newApiUser = {'label': ''};
        });
    }

    $scope.saveApiKeys = () => {
        $http.post(`/api/lmn/apikeys`, {
            'config': {
                'api_keys': $scope.api_keys.keys,
                'enable_host_auth': $scope.api_keys.enable_host_auth,
            }
        }).then((resp) => {
                    notify.success(gettext('Configuration saved'));
                    $scope.notifyApiRestart(resp);
        });
    }

    $scope.closeAddApiKey = () => $scope.showNewApiKey = false;
    $scope.closeUpdateApiKey = () => $scope.showUpdateApiKey = false;
    $scope.toggleAddIp = () => $scope.showAddApiKeyIp = !$scope.showAddApiKeyIp;
    $scope.removeApiKeyIp = (ip) => {
        pos = $scope.apiKey.ips.indexOf(ip);
        $scope.apiKey.ips.splice(pos, 1);
    }

    $scope.saveApiKeyIp = () => {
        $scope.toggleAddIp();
        $scope.apiKey.ips.push(angular.copy($scope._.newIp));
        $scope._.newIp = '';
    }

    $scope.validateIp = () => {return validation["isValidIP"]($scope._.newIp) == true;}

    // An empty scope means no restriction: the key reaches the whole API with
    // the LDAP role of its user. Entries read "<METHOD> <path>", the path
    // written without the /v1 prefix, with "*" for one segment and "**" for
    // the rest of the path.
    $scope.toggleAddScope = () => $scope.showAddApiKeyScope = !$scope.showAddApiKeyScope;

    $scope.removeApiKeyScope = (entry) => {
        let pos = $scope.apiKey.scope.indexOf(entry);
        $scope.apiKey.scope.splice(pos, 1);
    }

    $scope.saveApiKeyScope = () => {
        $scope.toggleAddScope();
        $scope.apiKey.scope.push(angular.copy($scope._.newScope));
        $scope._.newScope = '';
    }

    $scope.validateScope = () => {
        return /^(\*|[A-Za-z]+) \/\S*$/.test(($scope._.newScope || '').trim());
    }

    $scope.updateApiKey = () => {
        $scope.showUpdateApiKey = false;
        delete $scope.api_keys.keys[$scope.old_api_key_name];
        $scope.api_keys.keys[$scope.apiKey['name']] = {
                'ips':$scope.apiKey['ips'],
                'scope':$scope.apiKey['scope'],
                'secret':$scope.apiKey['secret'],
                'user':$scope._.newApiUser['login'],
        };
        $scope.saveApiKeys();
        $scope._.newApiUser = {'label': ''};
    }

    $scope.findUsers = (q) => {
        return $http.post("/api/lmn/ldap-search", {role: '', login:q}).then((resp) => {
            return resp.data;});
    }

    $scope.getLMNVersion = () => {
        $http.get('/api/lmn/version').then((res) => {
            $scope.LMNVersion = res.data;
        })
    }

});
 
