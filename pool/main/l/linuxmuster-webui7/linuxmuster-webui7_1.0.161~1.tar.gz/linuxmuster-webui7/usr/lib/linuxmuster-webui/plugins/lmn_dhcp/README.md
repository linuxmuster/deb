# DHCP extra plugin

This plugin allows to see all dhcp leases and eventually add a new devices to LMN devices.
