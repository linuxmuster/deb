#!/bin/bash

# DO NOT MODIFY THIS SCRIPT! Changes will be overwritten by updates!
# For custom scripts create your own script in this directory, this is just and example.

echo "onBoot.d Hook called with env:"
echo "Domain: $Network_domain"
echo "Server hostname: $Network_serverHostname"