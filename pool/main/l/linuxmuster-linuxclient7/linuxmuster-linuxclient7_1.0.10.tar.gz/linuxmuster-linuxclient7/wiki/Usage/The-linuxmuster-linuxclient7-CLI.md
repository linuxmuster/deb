For usage of the `linuxmuster-linuxclient7` CLI see `linuxmuster-linuxclient7 -h`.  
Any task has a separate help page, which you can view using `linuxmuster-linuxclient7 <task> -h`.