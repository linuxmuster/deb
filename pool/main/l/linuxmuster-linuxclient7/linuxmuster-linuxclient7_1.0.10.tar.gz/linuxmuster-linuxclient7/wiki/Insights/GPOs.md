This client comes with a minimal implementation of Windows GPOs. Keep in mind that it is actually MINIMAL!  
Currently, only the `sophomorix:school:$SCHOOL` policy is parsed! All others are ignored!
### Currently supported policies:
- Mount network shares
- Add Printers
### Currently supported filters:
- Group filter