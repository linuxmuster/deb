scriptDir=$(/usr/sbin/linuxmuster-linuxclient7 get-constant scriptDir)
source $scriptDir/executeHookWithEnvFix.sh onLogin