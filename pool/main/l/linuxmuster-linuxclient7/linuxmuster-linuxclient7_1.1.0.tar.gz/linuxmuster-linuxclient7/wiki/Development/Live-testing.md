For development purposes, you may use the `syncToTestClient.sh` script.
It syncs all changes to a client, so you can test them live.