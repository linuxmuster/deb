# linuxmuster-common
Common files for linuxmuster.net (since v7.3)

See issue [#156](https://github.com/linuxmuster/linuxmuster-base7/issues/156).

Compared to version 7.2, the following files have been renamed and moved to the package linuxmuster-common:

* from linuxmuster-base7
  * `/usr/lib/linuxmuster/constants.py` -> `/usr/lib/linuxmuster/environment.py`
  * `/usr/share/linuxmuster/defaults.sh` -> `/usr/share/linuxmuster/environment.sh`
* from linuxmuster-linbo7
  * `/usr/share/linuxmuster/linbo/helperfunctions.sh` -> `/usr/share/linuxmuster/helperfunctions.sh`
