"""REST endpoints for linbo-remote: run commands, list running sessions,
probe a host's boot state.

The router only translates HTTP requests and errors. Building/running the
command, listing tmux sessions and probing ports stay in
linuxmusterTools.linbo (LinboRemote, list_running_sessions, classify_host).
"""

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import PlainTextResponse

from linuxmusterTools.devices import Devices
from linuxmusterTools.linbo import (
    LinboBootLogs,
    LinboRemote,
    LinboRemoteParameterError,
    delete_onboot_command,
    get_onboot_command,
    list_onboot_commands,
    list_running_sessions,
)
from linuxmusterTools.linbo.host_status import classify_host
from security import AuthenticatedUser, RoleChecker
from utils.checks import require_school
from .body_schemas import LinboRemoteRunBody


router = APIRouter(
    prefix="/linbo/sync",
    tags=["LINBO Sync"],
    responses={404: {"description": "Not found"}},
)

# Mirrors the cap already used for /linbo/wol and /linbo/hosts/scan.
MAX_CLIENTS_PER_RUN = 500


@router.post("/run", name="Build and run a linbo-remote command")
@require_school
def run_linbo_remote(
    body: LinboRemoteRunBody,
    school: str = "",
    who: AuthenticatedUser = Depends(RoleChecker("GS")),
):
    """
    ## Build and run a linbo-remote command against a group, room or hosts.

    A school-administrator can only target their own school; a
    global-administrator must specify one explicitly.

    ### Access
    - global-administrators
    - school-administrators

    \f
    :param body: Target (group/room/clients), command and options
    :param school: School to target (required for global-administrators)
    """


    active_school = school if school else who.school

    if len(body.clients) > MAX_CLIENTS_PER_RUN:
        raise HTTPException(status_code=400, detail=f"Maximum {MAX_CLIENTS_PER_RUN} clients per request")

    remote = LinboRemote(
        cmd=body.cmd,
        group=body.group,
        room=body.room,
        clients=body.clients,
        wait=body.wait,
        wol=body.wol,
        disable_gui=body.disable_gui,
        broadcast=body.broadcast,
        bypass=body.bypass,
        onboot=body.onboot,
        school=None if active_school == "default-school" else active_school,
    )

    try:
        return remote.run()
    except LinboRemoteParameterError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error


@router.get("/sessions", name="List running linbo-remote sessions")
def get_running_sessions(
    who: AuthenticatedUser = Depends(RoleChecker("GS")),
):
    """
    ## List the linbo-remote tmux sessions currently running on the server.

    A global-administrator sees every session. A school-administrator only
    sees sessions for hosts belonging to their own school.

    ### Access
    - global-administrators
    - school-administrators

    \f
    """


    sessions = list_running_sessions()

    if who.school == 'global':
        return {"sessions": sessions}

    known_hostnames = {
        f'{who.school}-{device["hostname"]}' if who.school != 'default-school' else device['hostname']
        for device in Devices(school=who.school).devices
    }
    return {"sessions": [s for s in sessions if s['hostname'] in known_hostnames]}


@router.get(
    "/sessions/{hostname}/log",
    name="Read a host's linbo-remote session log",
    response_class=PlainTextResponse,
)
def get_session_log(
    hostname: str,
    who: AuthenticatedUser = Depends(RoleChecker("GS")),
):
    """
    ## Read a host's linbo-remote session log.

    The log of the host's last run: tmux's pipe-pane duplicates the session's
    output to it as it runs, and it stays readable after the session ends. A
    school-administrator can only read hosts belonging to their own school.

    ### Access
    - global-administrators
    - school-administrators

    \f
    :param hostname: Hostname whose session log to read
    """


    if who.school != 'global':
        known_hostnames = {
            f'{who.school}-{device["hostname"]}' if who.school != 'default-school' else device['hostname']
            for device in Devices(school=who.school).devices
        }
        if hostname not in known_hostnames:
            raise HTTPException(status_code=404, detail=f"Host {hostname} not found")

    boot_logs = LinboBootLogs()
    try:
        filename = boot_logs.latest_remote_log(hostname)
        content = boot_logs.read_log(filename) if filename else None
    except ValueError as error:
        status_code = 413 if "too large" in str(error).lower() else 400
        raise HTTPException(status_code=status_code, detail=str(error)) from error

    if content is None:
        raise HTTPException(status_code=404, detail=f"No session log for {hostname}")

    return content


@router.get("/hosts/{hostname}/status", name="Probe a host's boot state")
def get_host_status(
    hostname: str,
    who: AuthenticatedUser = Depends(RoleChecker("GS")),
):
    """
    ## Probe a host on ports 2222/22/135 and report its boot state.

    One of 'Off', 'Linbo', 'OS Linux', 'OS Windows', 'OS Unknown'. A
    school-administrator can only probe hosts belonging to their own school.

    ### Access
    - global-administrators
    - school-administrators

    \f
    :param hostname: Hostname or IP to probe
    """


    if who.school != 'global':
        known_hostnames = {
            f'{who.school}-{device["hostname"]}' if who.school != 'default-school' else device['hostname']
            for device in Devices(school=who.school).devices
        }
        if hostname not in known_hostnames:
            raise HTTPException(status_code=404, detail=f"Host {hostname} not found")

    return {"hostname": hostname, "status": classify_host(hostname)}


@router.get("/onboot", name="List the pending onboot commands")
def get_onboot_commands(
    who: AuthenticatedUser = Depends(RoleChecker("GS")),
):
    """
    ## List the onboot commands waiting for a host's next boot.

    A run with `onboot` leaves the commands on the server until the host
    boots and downloads them. A global-administrator sees every host, a
    school-administrator only the hosts belonging to their own school.

    ### Access
    - global-administrators
    - school-administrators

    \f
    """


    pending = list_onboot_commands()

    if who.school == 'global':
        return {"onboot": pending}

    known_hostnames = {
        f'{who.school}-{device["hostname"]}' if who.school != 'default-school' else device['hostname']
        for device in Devices(school=who.school).devices
    }
    return {"onboot": [p for p in pending if p['hostname'] in known_hostnames]}


@router.get("/onboot/{hostname}", name="Read a host's pending onboot commands")
def get_host_onboot_command(
    hostname: str,
    who: AuthenticatedUser = Depends(RoleChecker("GS")),
):
    """
    ## Read the onboot commands waiting for a host's next boot.

    A school-administrator can only read hosts belonging to their own school.

    ### Access
    - global-administrators
    - school-administrators

    \f
    :param hostname: Hostname whose pending commands to read
    """


    if who.school != 'global':
        known_hostnames = {
            f'{who.school}-{device["hostname"]}' if who.school != 'default-school' else device['hostname']
            for device in Devices(school=who.school).devices
        }
        if hostname not in known_hostnames:
            raise HTTPException(status_code=404, detail=f"Host {hostname} not found")

    try:
        return get_onboot_command(hostname)
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail=f"No onboot command pending for {hostname}")


@router.delete("/onboot/{hostname}", name="Withdraw a host's pending onboot commands")
def withdraw_onboot_command(
    hostname: str,
    who: AuthenticatedUser = Depends(RoleChecker("GS")),
):
    """
    ## Withdraw a host's onboot commands before its next boot.

    A school-administrator can only withdraw commands of hosts belonging to
    their own school.

    ### Access
    - global-administrators
    - school-administrators

    \f
    :param hostname: Hostname whose pending commands to withdraw
    """


    if who.school != 'global':
        known_hostnames = {
            f'{who.school}-{device["hostname"]}' if who.school != 'default-school' else device['hostname']
            for device in Devices(school=who.school).devices
        }
        if hostname not in known_hostnames:
            raise HTTPException(status_code=404, detail=f"Host {hostname} not found")

    try:
        delete_onboot_command(hostname)
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail=f"No onboot command pending for {hostname}")
