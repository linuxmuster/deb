# linbo

Manages [LINBO](https://www.linuxmuster.net) images, backups, hardware inventories, Windows driver profiles, and remote commands/sessions on a linuxmuster.net server.

---

## Requirements

- Python 3.8+
- [`configobj`](https://pypi.org/project/configobj/) (via `linuxmusterTools.lmnfile`, used to read/write `match.conf`/`image.conf`)
- A LINBO server layout: `/srv/linbo/images`, `/srv/linbo/drivers`, `/var/log/linuxmuster/linbo`

---

## Group configs

`LinboConfigManager` owns the per-group files in `/srv/linbo`: the
`start.conf.<group>` itself and its optional VDI companion
`start.conf.<group>.vdi`. Every method validates the group id before it
builds a path, so an id coming from a request cannot escape `/srv/linbo`.

| Method | Description |
|---|---|
| `load_raw_startconfs(group_ids)` | Raw text, sha256 and mtime of each requested `start.conf`, skipping the ids that are invalid or have no file |
| `write_raw_startconf(group_id, content)` | Writes the text verbatim, comments and formatting preserved, creating the file if needed |
| `delete_startconf(group_id)` | Deletes the `start.conf` and the group's GRUB config |
| `read_vdi_config(group_id)` | Parsed VDI config, `{}` if the file is empty |
| `write_vdi_config(group_id, config)` | Creates or replaces the VDI config as a whole |
| `delete_vdi_config(group_id)` | Deletes the VDI config, which disables VDI for that group |
| `list_examples()` | The ready-made configs in `/srv/linbo/examples`, with kind, size and mtime |
| `read_example(name)` | Content of one of them, by a name the listing reports |
| `list_startconf_backups(group_id)` | The group's `start.conf` backups, newest first, with epoch, size and date |
| `restore_startconf_backup(group_id, timestamp)` | Puts one back in place, saving the current file first |
| `delete_startconf_backup(group_id, timestamp)` | Deletes one backup, irreversibly |

Every write path leaves a backup behind, named
`.start.conf.<group>.bak.<epoch>` by `LMNFile.backup()`, and that is the
history `list_startconf_backups()` reports. It is a short one: `backup()`
keeps the ten previous versions and drops the oldest when it writes an
eleventh, so it is a way back from a bad edit, not an archive. Matching is
exact - group names prefix each other on a real server (`101`, `101-test`,
`101b`), and a group's VDI config keeps backups of its own under
`.start.conf.<group>.vdi.bak.<epoch>`.

`restore_startconf_backup()` reads the backup before saving the current
`start.conf`, because saving it rotates the oldest backup out and the oldest
may be the very one being restored. The file is then copied byte for byte
rather than parsed and rewritten: the comments are what makes a backup worth
restoring.

`list_examples()` and `read_example(name)` complete the set with the
ready-made configs LINBO ships in `/srv/linbo/examples`: the `start.conf.*`
templates and the `.reg`/`.postsync`/`.prestart` sidecars, each reported with
its kind (`config`, `reg`, `postsync`, `prestart`), size and mtime. Anything
else in that directory - the README, for one - is left out, and the listing
doubles as the whitelist: `read_example()` only accepts a name the listing
reports, so a name coming from a request cannot walk out of the directory. A
server without the directory lists nothing rather than raising.

The `.vdi` file is YAML, not a `start.conf`: `LMNFile` excludes the extension
from its start.conf handler and routes it to the YAML loader, so booleans,
integers and lists survive a round trip. It holds what the group editor's
VDI tab shows - `activated`, `name`, `bios`, `ostype`, `boot`, `hostname`,
`ip`, `mac`, `bridge`, `tag`, `cores`, `memory`, `size`, `storage` and the
reserved `vmids` - and is consumed by `edulution-linbo-vdi`, which owns that
schema: the manager reads and writes the mapping without interpreting it.

```python
>>> from linuxmusterTools.linbo import LinboConfigManager
>>> manager = LinboConfigManager()
>>> manager.write_vdi_config('win11', {'activated': True, 'cores': 4, 'vmids': [101, 102]})
>>> manager.read_vdi_config('win11')
{'activated': True, 'cores': 4, 'vmids': [101, 102]}
>>> manager.delete_vdi_config('win11')
```

Do not confuse this file with an image's `.vdi` sidecar
(`<image>.qcow2.vdi`, free text, managed by `LinboImageManager` along with
`.desc`/`.reg`/`.postsync`): same extension, unrelated object.

`write_raw_startconf()` keeps the `start.conf` at mode 755, like the other
files LINBO itself reads, while `write_vdi_config()` leaves the VDI config at
600 - what these files have on a server, and what the YAML loader sets before
its own final rename would drop it back to the umask default. Both back the
previous version up. `read_vdi_config()` and
`delete_vdi_config()` raise `FileNotFoundError` when the group has no VDI
config - a group without one simply has VDI disabled.

---

## Image manager

`LinboImageManager` provides an object to manage all linbo images, backups and extra files (rename, delete, ... ).
The manager contains a dict of all groups in the attributes `groups`. Each group is a `LinboImageGroup` which lists all files, backups contained in the directory. You can get a dict of this description with the method `to_dict()` like bellow:

```Console
>>> from linuxmusterTools.linbo import LinboImageManager
>>> lim = LinboImageManager()
>>> lim.groups
{'ubuntu': <linuxmusterTools.linbo.images.LinboImageGroup object at 0x7f579b6443a0>, 'focal': <linuxmusterTools.linbo.images.LinboImageGroup object at 0x7f579b645f00>, 'test-linbo42': <linuxmusterTools.linbo.images.LinboImageGroup object at 0x7f579b25f7f0>, 'data': <linuxmusterTools.linbo.images.LinboImageGroup object at 0x7f579b25f7c0>}
>>> lim.rename('test-linbo42', 'test-linbo101')
>>> lim.groups
{'ubuntu': <linuxmusterTools.linbo.images.LinboImageGroup object at 0x7f579b6443a0>, 'focal': <linuxmusterTools.linbo.images.LinboImageGroup object at 0x7f579b645f00>, 'data': <linuxmusterTools.linbo.images.LinboImageGroup object at 0x7f579b25f7c0>, 'test-linbo101': <linuxmusterTools.linbo.images.LinboImageGroup object at 0x7f579b61a500>}
>>> lim.groups['ubuntu'].to_dict()
{'name': 'ubuntu', 'size': 2609718272, 'desc': 'Install LaTeX and update', 'info': '["ubuntu.qcow2" Info File]\ntimestamp="202108291639"\nimage="ubuntu.qcow2"\nimagesize="2609718272"\npartition="/dev/sda1"\npartitionsize="31457280"\n', 'reg': None, 'postsync': None, 'vdi': None, 'prestart': '#! /bin/bash\n\necho "ok"\n', 'backup': False, 'diff': False, 'torrent': True, 'timestamp': '202108291639', 'date': '29/08/2021 16:39', 'diff_image': {}, 'backups': {'03/03/2022 19:03': {'name': 'ubuntu', 'size': 0, 'desc': '', 'info': 'timestamp=202203031903\ndate=voila', 'reg': None, 'postsync': None, 'vdi': None, 'prestart': None, 'backup': True, 'diff': False, 'torrent': False, 'timestamp': '202203031903', 'date': '03/03/2022 19:03'}, '29/08/2021 16:22': {'name': 'ubuntu', 'size': 3233778176, 'desc': 'Install ZSH', 'info': '[ubuntu.qcow2 Info File]\ntimestamp=202108291622\nimage=ubuntu.qcow2\nbaseimage=/dev/sda1\npartitionsize=31457159\nimagesize=3233778176\n', 'reg': None, 'postsync': None, 'vdi': None, 'prestart': '#! /bin/bash\n\necho "ok"\n', 'backup': True, 'diff': False, 'torrent': False, 'timestamp': '202108291622', 'date': '29/08/2021 16:22'}, '29/08/2021 16:17': {'name': 'ubuntu', 'size': 3233778176, 'desc': 'Install ZSH', 'info': '[ubuntu.qcow2 Info File]\ntimestamp=202108291617\nimage=ubuntu.qcow2\nbaseimage=/dev/sda1\npartitionsize=31457159\nimagesize=3233778176\n', 'reg': None, 'postsync': None, 'vdi': None, 'prestart': '#! /bin/bash\n\necho "ok"\n', 'backup': True, 'diff': False, 'torrent': False, 'timestamp': '202108291617', 'date': '29/08/2021 16:17'}}, 'selected': False}
```

`delete()`, `duplicate()` and `restore()` raise rather than fail silently:
a directory that cannot be removed propagates the underlying `OSError`, and
`duplicate()`/`restore()` raise `ImageExistsError` (a `FileExistsError`
subclass, importable from `linuxmusterTools.linbo`) if the target image or
backup directory already exists.

`.torrent` and its `.hash` are the one pair that is **not** renamed along
with the other extras. A torrent embeds the file name it describes, and the
hash describes that torrent, so `rename()` deletes both and `duplicate()`
leaves them out of the copy. They are rebuilt afterwards by
`linbo-torrent create`, launched in the background: `buildtorrent` hashes the
whole image, which would otherwise hold the caller — and the HTTP request
behind it — for the length of the build.

The rebuild runs only once the image directory has its final name, and never
for backups: `linbo-torrent` only looks two levels below `/srv/linbo/images`
and never sees them. Its output goes to
`/var/log/linuxmuster/linbo/torrent-create-<image>.log`. There is nothing else
to follow: `<image>.torrent` and `<image>.hash` appear when the build is done,
`to_dict()` reports the torrent's presence, and `linbo-torrent status` lists
the seeding session.

A missing or incomplete `.info` file (an existing image whose required
fields aren't all present) raises `IncompleteImageInfoError` (a
`ValueError` subclass) when the manager loads it. Rather than taking the
whole listing down with it, `LinboImageManager` catches this per group: a
broken group still appears in `to_dict()`'s output, as
`{'name': <group>, 'error': <message>, 'selected': False}`, instead of a
full image description.

---

## Remote commands

`LinboRemote` builds and runs a `linbo-remote` command against a group, a
room, or a list of clients (an ip or a hostname). It validates its
parameters (mutually exclusive target, `wait`/`wol` pairing, valid school)
and the position/partition number (`nr`) against the target's
`start.conf` before running anything, raising `LinboRemoteParameterError`
(a `ValueError` subclass) instead of silently building - or running - a
wrong command.

```python
>>> from linuxmusterTools.linbo import LinboRemote
>>> remote = LinboRemote(group='win10', cmd='sync:1')
>>> remote.run()
{'status': 0, 'msg': 'Started with PID 1234. Log see /var/log/linuxmuster/linbo/pc001_linbo-remote.\n'}
```

`list_running_sessions()` lists the tmux sessions `linbo-remote` currently
has running (one per targeted host), and `attach_command()` builds the
`tmux attach` command for a given hostname - not meant to be run through a
web request (`tmux attach` needs an interactive terminal), only to give a
future terminal-in-browser feature the exact session name to use.

```python
>>> from linuxmusterTools.linbo import list_running_sessions, attach_command
>>> list_running_sessions()
[{'hostname': 'pc001', 'session': 'pc001_linbo-remote', 'created': '2026-08-07T11:49:15+00:00'}]
>>> attach_command('pc001')
'tmux attach -t pc001_linbo-remote'
```

---

## Host status

`classify_host(hostname_or_ip)` probes ports 2222/22/135 with plain
blocking sockets (no `nmap`, no asyncio - safe to call from gevent-based
code) and reports one of `'Off'`, `'Linbo'`, `'OS Linux'`, `'OS Windows'`,
`'OS Unknown'`.

```python
>>> from linuxmusterTools.linbo.host_status import classify_host
>>> classify_host('pc001')
'Linbo'
```

`probe_host()`/`scan_hosts()`/`scan_hosts_sync()` (same module) answer a
narrower question - is a host reachable on LINBO's port 2222 - concurrently
across many hosts via asyncio; used where a full boot-state classification
isn't needed.

---

## Image status

Every sync or image creation makes the LINBO client overwrite a single line
in `/var/log/linuxmuster/linbo/<hostname>_image.status` (written by
`log_image_status()` in linuxmuster-linbo7's `shell_functions`):

```text
202608071440 applied: data-jammy.qcow2 "202507051609"
202601271107 created: win11.qcow2 202601271107
```

| Function | Description |
|---|---|
| `last_sync(workstation, image, timestamp=True)` | Epoch of the most recent entry for that image, or `False` if the host never synced it. With `timestamp=False`, the whole `{timestamp, action, image, image_timestamp}` entry is returned instead, to also get the version of the image which was applied. The image name is matched exactly, along with its `.qdiff` variant: `last_sync('client1', 'jammy.qcow2')` does *not* report a sync of `data-jammy.qcow2`. The file name is matched **case insensitively**, see below. |
| `get_host_image_status(log_dir=None)` | Last logged status of **every** host found in the log directory, without knowing beforehand which image a host is supposed to run. Returns `{}` if the directory is missing. |
| `last_sync_all(workstations)` | Enriches a `list_workstations()` dict: each host gets an `image` list of `{date, image, imageVersion, status}`. `imageVersion` is the creation timestamp of the image the host actually runs (`None` if it never synced it), not the date of the sync. `status` is the bootstrap class `success`/`warning`/`danger` (fresher than 7 days, older than 7 days, older than 30 days or never). |

```python
>>> from linuxmusterTools.linbo import last_sync, get_host_image_status
>>> last_sync('client1', 'data-jammy.qcow2')
1786106400.0
>>> last_sync('client1', 'win11.qcow2')
False
>>> get_host_image_status()
{'client1': {'lastSync': '2026-08-07T12:40:00+00:00', 'action': 'applied', 'image': 'data-jammy.qcow2', 'imageVersion': '202507051609'},
 'client3': {'lastSync': '2026-03-26T11:26:00+00:00', 'action': 'applied', 'image': 'win11.qcow2', 'imageVersion': '202603251539'}}
```

The file is named by `rsync-pre-download.sh` after the reverse DNS resolution
made by rsyncd, not after `devices.csv`, and DNS is case insensitive: the same
host can end up with `PC-001_image.status` and `pc-001_image.status` side by
side, only one of them still being written to. `last_sync()` therefore reads
every case variant of the name and keeps the most recent entry.
`get_host_image_status()` still reports each host under the exact case of its
file name.

Both functions read their timestamps through
`linuxmusterTools.common.timestamps.linbo_timestamp_to_epoch()`: LINBO
clients write their own local wall clock, which matches the server's local
time, so `last_sync()` returns a server-local epoch and
`get_host_image_status()` serializes real UTC - `2026-08-07T12:40:00+00:00`
for a client that logged `202608071440` in CEST.

An unreadable status file is handled differently by the two entry points, on
purpose: `last_sync()` propagates the `OSError`, because answering "Never"
for a file it could not read would be indistinguishable from a host that
really never synced, while `get_host_image_status()` logs a warning and skips
that host rather than losing the whole report.

---

## Hardware inventories

`LinboHardwareInventoryManager` reads the `*_hwinfo.gz` files uploaded by
LINBO clients from `/var/log/linuxmuster/linbo`. Its `list()` and `get()`
methods combine DMI vendor and product information with the school-scoped
client records provided by `Devices`.

The manager is read-only. It does not create driver profiles or modify LINBO
images and can therefore be used independently by API and CLI consumers.

---

## Windows driver profiles

`LinboDriverManager` manages the metadata for hardware-specific Windows
driver profiles below `/srv/linbo/drivers`. This first, deliberately small
interface owns only profile directories and their `match.conf`; inventory,
image assignments, postsync generation and driver imports are separate
features.

Each profile contains exactly one DMI vendor and one product substring:

```ini
[match]
vendor = LENOVO
product = 21L4
```

The values use the same case-sensitive semantics as LINBO: the vendor must
match exactly and `product` must occur in the client's DMI product name. An
explicit `*` can be used as a wildcard. A short product such as `21L4` can
therefore cover multiple variants of the same hardware class.

```python
from linuxmusterTools.linbo import LinboDriverManager

drivers = LinboDriverManager()
drivers.create_profile("lenovo-21l4", "LENOVO", "21L4")
drivers.update_match("lenovo-21l4", "LENOVO", "21L4S")
```

This creates `/srv/linbo/drivers/lenovo-21l4/match.conf`. Administrators may
place an already prepared INF driver payload next to that file. Profile
updates change only `match.conf` and leave those payload files untouched. This
manager does not upload, extract, inspect or publish the payload yet.

### Image assignments

Each `LinboImageGroup` delegates its optional `image.conf` assignments and
`.driverpostsync` dispatcher to a bound `WindowsDrivers` object.
`LinboDriverManager` continues to own the image-independent profile
directories and `match.conf`. Both metadata files remain physically stored
with the profile; only their logical ownership differs:

```text
/srv/linbo/drivers/<profile>/match.conf
/srv/linbo/drivers/<profile>/image.conf
/srv/linbo/images/<image>/<image>.driverpostsync
```

```ini
[image]
name = win11
```

```python
from linuxmusterTools.linbo import LinboDriverManager, LinboImageManager

drivers = LinboDriverManager()
images = LinboImageManager(driver_manager=drivers)
images.assign_driver_profile("lenovo-21l4", "win11")
images.get_driver_profile_image("lenovo-21l4")
images.get_image_driver_profiles("win11")
dispatcher = images.render_driverpostsync("win11")
images.unassign_driver_profile("lenovo-21l4")
```

These public manager methods resolve the named `LinboImageGroup` and delegate
the image-specific work to its bound `WindowsDrivers` object.

The former standalone package's flat `image = win11` form remains readable for
upgrades and is rewritten in the canonical form by the next assignment.
Assigned profile names can be resolved in deterministic order. The
renderer returns the small `.driverpostsync` dispatcher expected by LINBO's
static `linbo_driverpostsync` runtime. The publisher atomically writes that
dispatcher into the image directory with LINBO's standard postsync mode. It
refuses to replace symlinks, non-regular files or hooks without its exact
managed header. The exact standalone v1.1.1 generator markers remain accepted
for an in-place migration. Assigning, moving or removing a profile publishes
all affected dispatchers under the same mutation lock. If publication fails,
the previous assignment is restored and the affected dispatchers are
regenerated to match it.
`publish_driverpostsync()` remains available as an explicit repair operation.
Assigned profiles must be unassigned before their profile directory can be
deleted, preventing a dispatcher from retaining a stale profile name.
