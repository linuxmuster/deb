from linuxmusterTools.ldapconnector.urls import router as reader_router
from linuxmusterTools.ldapconnector.ldap_writer import ldap_writer
from linuxmusterTools.ldapconnector.writers import *

LMNLdapReader = reader_router
LMNLdapWriter = ldap_writer
