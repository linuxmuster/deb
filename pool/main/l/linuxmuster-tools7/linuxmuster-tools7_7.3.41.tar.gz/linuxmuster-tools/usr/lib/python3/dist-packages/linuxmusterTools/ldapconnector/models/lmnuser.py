from dataclasses import dataclass, field, InitVar
import re
import ldap
from ..urls import router as lr
from .lmnsession import LMNSessionModel
from .common import LMNModel

from linuxmusterTools.common import WEBUI_IMPORT


@dataclass
class LMNUserModel(LMNModel):
    cn: str
    custom_fields_config: InitVar[dict]
    displayName: str
    distinguishedName: str
    givenName: str
    homeDirectory: str
    homeDrive: str
    mail: list
    memberOf: list
    name: str
    objectClass: list
    preferredLanguage: str
    proxyAddresses: list
    sAMAccountName: str
    sAMAccountType: str
    sn: str
    sophomorixAdminClass: str
    sophomorixAdminFile: str
    sophomorixBirthdate: str
    sophomorixCloudQuotaCalculated: list
    sophomorixComment: str
    sophomorixCreationDate: str # datetime
    sophomorixCustom1: str
    sophomorixCustom2: str
    sophomorixCustom3: str
    sophomorixCustom4: str
    sophomorixCustom5: str
    sophomorixCustomMulti1: list
    sophomorixCustomMulti2: list
    sophomorixCustomMulti3: list
    sophomorixCustomMulti4: list
    sophomorixCustomMulti5: list
    sophomorixDeactivationDate: str # datetime
    sophomorixExamMode: list
    sophomorixExitAdminClass: str
    sophomorixFirstnameASCII: str
    sophomorixFirstnameInitial: str
    sophomorixFirstPassword: str
    sophomorixIntrinsic1: str
    sophomorixIntrinsic2: str
    sophomorixIntrinsic3: str
    sophomorixIntrinsic4: str
    sophomorixIntrinsic5: str
    sophomorixIntrinsicMulti1: list
    sophomorixIntrinsicMulti2: list
    sophomorixIntrinsicMulti3: list
    sophomorixIntrinsicMulti4: list
    sophomorixIntrinsicMulti5: list
    sophomorixMailQuotaCalculated: list
    sophomorixMailQuota: list
    sophomorixQuota: list
    sophomorixRole: str
    sophomorixSchoolname: str
    sophomorixSchoolPrefix: str
    sophomorixSessions: list
    sophomorixStatus: str
    sophomorixSurnameASCII: str
    sophomorixSurnameInitial: str
    sophomorixTolerationDate: str # datetime
    sophomorixUnid: str
    sophomorixUserToken: str
    sophomorixWebuiDashboard: list
    sophomorixWebuiPermissionsCalculated: list
    thumbnailPhoto: str
    unixHomeDirectory: str
    userAccountControl: int
    whenChanged: str
    dn:             str  = field(init=False)
    children:       dict = field(init=False)
    customFields:   dict = field(init=False)
    examMode:       bool = field(init=False)
    examTeacher:    str  = field(init=False)
    examBaseCn:     str  = field(init=False)
    internet:       bool = field(init=False)
    intranet:       bool = field(init=False)
    isAdmin:        bool = field(init=False)
    lmnsessions:    list = field(init=False)
    parents:        list = field(init=False)
    permissions:    list = field(init=False)
    printers:       list = field(init=False)
    printing:       bool = field(init=False)
    projects:       list = field(init=False)
    schoolclasses:  list = field(init=False)
    school:         str  = field(init=False)
    webfilter:      bool = field(init=False)
    wifi:           bool = field(init=False)

    @staticmethod
    def _check_schoolclass_number(s):
        n = re.findall(r'\d+', s)
        if n:
            return int(n[0])
        else:
            return 10000000 # just a big number to come after all schoolclasses

    def extract_schoolclasses(self, membership):
        schoolclasses = []
        for dn in membership:
            if 'OU=Students' in dn \
                and '-teachers,' not in dn \
                and '-parents,' not in dn \
                and '-students,' not in dn:
                schoolclass = self.common_name(dn)
                if schoolclass:
                    schoolclasses.append(schoolclass)
        schoolclasses = sorted(schoolclasses, key=lambda s: (self._check_schoolclass_number(s), s))
        return schoolclasses

    def extract_projects(self, membership):
        projects = []
        for dn in membership:
            if 'OU=Projects' in dn:
                project = self.common_name(dn)
                if project:
                    projects.append(project)
        projects.sort()
        return projects

    def extract_printers(self, membership):
        printers = []
        for dn in membership:
            if 'OU=printer-groups' in dn:
                printer = self.common_name(dn)
                if printer:
                    printers.append(printer)
        printers.sort()
        return printers

    def extract_management(self):
        school_prefix = ""
        if self.sophomorixSchoolname != 'default-school':
            school_prefix = f"{self.sophomorixSchoolname}-"

        for group in ['internet', 'intranet', 'printing', 'webfilter', 'wifi']:
            setattr(self, group, False)
            for dn in self.memberOf:
                if dn.startswith(f"CN={school_prefix}{group},OU=Management"):
                    setattr(self, group, True)

    def parse_permissions(self):
        self.permissions = {}

        for perm in self.sophomorixWebuiPermissionsCalculated:
            module, value = perm.split(': ')
            self.permissions[module] = value == 'true'

    def parse_sessions(self):
        self.lmnsessions = []
        for v in self.sophomorixSessions:
            data = v.split(';')
            members = data[2].split(',') if data[2] else []
            membersCount = len(members)
            self.lmnsessions.append(LMNSessionModel(data[0], data[1], members, membersCount))

    def parse_exam(self):
        if not self.sophomorixExamMode:
            self.examMode = False
            self.examTeacher = ''
            self.examBaseCn = ''
        elif self.sophomorixExamMode[0] == '---':
            self.examMode = False
            self.examTeacher = ''
            self.examBaseCn = ''
        else:
            self.examMode = True
            self.examTeacher = self.sophomorixExamMode[0]
            self.examBaseCn = self.cn.replace('-exam', '')

    def create_custom_fields_objects(self, custom_config={}):
        self.customFields = {}

        proxy_add = custom_config.get('proxyAddresses', {}).get(self.sophomorixRole, {'editable': False, 'show': False, 'title':''})
        self.customFields['proxyAddresses'] = {
            'title': proxy_add['title'],
            'canRead': proxy_add['show'],
            'canWrite': proxy_add['editable'],
            'value': self.proxyAddresses
        }

        for i in range(1, 5):
            config = custom_config.get('custom', {}).get(self.sophomorixRole, {}).get(str(i), {'editable': False, 'show': False, 'title':''})
            self.customFields[f"sophomorixCustom{i}"] = {
                'title': config['title'],
                'canRead': config['show'],
                'canWrite': config['editable'],
                'value': getattr(self, f"sophomorixCustom{i}")
            }

        for i in range(1, 5):
            config = custom_config.get('customMulti', {}).get(self.sophomorixRole, {}).get(str(i), {'editable': False, 'show': False, 'title': ''})
            self.customFields[f"sophomorixCustomMulti{i}"] = {
                'title': config['title'],
                'canRead': config['show'],
                'canWrite': config['editable'],
                'value': getattr(self, f"sophomorixCustomMulti{i}")
            }

    def get_parents(self):
        self.parents = []
        if self.sophomorixRole == 'student':
            parents_group = lr.getval(f'/units/{self.cn}-parents', 'member', school=self.school) or []
            self.parents = [dn.split(',')[0].split('=')[1]
                for dn in parents_group
            ]

    def get_children(self):
        self.children = []
        if self.sophomorixRole != 'student':
            memberships = [m for m in self.memberOf if 'Student-Parents' in m]
            self.children = [
                m.split(',')[0].split('=')[1].replace('-parents', '')
                for m in memberships
            ]

    def __post_init__(self, custom_fields_config={}):
        self.schoolclasses = self.extract_schoolclasses(self.memberOf)
        self.projects = self.extract_projects(self.memberOf)
        self.printers = self.extract_printers(self.memberOf)
        self.dn = self.distinguishedName
        self.school = self.sophomorixSchoolname
        self.extract_management()
        self.parse_permissions()
        self.parse_sessions()
        self.parse_exam()
        self.get_children()
        self.get_parents()

        if not WEBUI_IMPORT:
            self.create_custom_fields_objects(custom_fields_config)
        else:
            self.customFields = {}


        self.isAdmin = "administrator" in self.sophomorixRole

    def test_password(self, password=''):
        if not self.dn:
            return False

        l = ldap.initialize("ldaps://localhost:636/")
        l.set_option(ldap.OPT_REFERRALS, 0)
        l.set_option(ldap.OPT_RESTART, ldap.OPT_ON)
        l.set_option(ldap.OPT_X_TLS_REQUIRE_CERT, ldap.OPT_X_TLS_ALLOW)
        l.protocol_version = ldap.VERSION3

        try:
            l.bind_s(self.dn, password)
            return True
        except ldap.INVALID_CREDENTIALS:
            return False

    def test_first_password(self):
        if self.sophomorixFirstPassword:
            return self.test_password(self.sophomorixFirstPassword)
        return 'Insufficient permissions to read first password from LDAP.'

