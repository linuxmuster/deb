#! /usr/bin/env python3

# This script is part of the sophomorix project and intended to update
# CN of parents groups in students OU for students which attributes changed.
# DO NOT EDIT OR REMOVE IT !


import sys
from linuxmusterTools.common import lprint, parse_update_log
from linuxmusterTools.ldapconnector import LMNUser, LMNSchoolclass, LMNStudent


epoch = sys.argv[1]
school = sys.argv[2]

if epoch is None:
    updates = parse_update_log(today=True)
    timestamps = list(updates.keys())
    timestamps.sort()
    epoch = timestamps[-1]
    entries = updates[epoch]
else:
    entries = parse_update_log(epoch=epoch)

schoolclass_groups_to_update = {
    'default-school': {
        'students': set(),
        'teachers': set(),
        'parents': set()
    }
}

for entry in entries:
    user = entry["user"]
    changes = entry["changes"]
    school = entry["school"]

    if school not in schoolclass_groups_to_update:
        schoolclass_groups_to_update[school] = {
            'students': set(),
            'teachers': set(),
            'parents': set()
        }

    if 'group' in changes:
        old_group, new_group = changes['group'].split('->')
        old_role, new_role = changes['role'].split('->')

        if old_role == new_role == 'student':

            # Student moving from a schoolclass to another, eventually attic

            if old_group != 'attic':
                # Removing student / student's parents from old students / parents group
                schoolclass_groups_to_update[school]['students'].add(old_group)
                schoolclass_groups_to_update[school]['parents'].add(old_group)

            if new_group == 'attic':
                # Delete CN in Student-Parents
                student = LMNStudent(user)
                student.parents_group.delete()

            else:
                # Adding student / student's parents to new students / parents group
                schoolclass_groups_to_update[school]['students'].add(new_group)
                schoolclass_groups_to_update[school]['parents'].add(new_group)

        elif old_group == 'teachers' and new_group == 'attic':

            # Teacher moves to attic to be deleted. It's necessary to remove this
            # teacher from all teachers groups

            teacher = LMNUser(user)
            for c in teacher.data['schoolclasses']:
                schoolclass_groups_to_update[school]['teachers'].add(c)

        elif old_group == 'parents' and new_group == 'attic':

            # Parent moves to attic to be deleted.

            parent = LMNUser(user)
            parent.get_children()

            # Remove parent from all parents groups in students
            for schoolclass in parent.children_schoolclasses:
                schoolclass_groups_to_update[school]['parents'].add(schoolclass)

            # Remove parent from Student-Parents' entries
            for student_cn in parent.children_cn:
                student = LMNStudent(student_cn)
                student.remove_parent(user)

for school, groups in schoolclass_groups_to_update.items():
    for schoolclass in groups['students']:
        lprint.lmn(f"Updating students group of schoolclass {schoolclass} in {school}")
        schoolclass_group = LMNSchoolclass(schoolclass, school=school)
        schoolclass_group.students_group.fill_members()

    for schoolclass in groups['parents']:
        lprint.lmn(f"Updating parents group of schoolclass {schoolclass} in {school}")
        schoolclass_group = LMNSchoolclass(schoolclass, school=school)
        schoolclass_group.parents_group.fill_members()

    for schoolclass in groups['teachers']:
        lprint.lmn(f"Updating teachers group of schoolclass {schoolclass} in {school}")
        schoolclass_group = LMNSchoolclass(schoolclass, school=school)
        schoolclass_group.teachers_group.fill_members()
