import os
import locale
import time
from glob import glob
from datetime import datetime

from .models import *
from ..devices import Devices
from ..lmnfile import LMNFile


LINBO_PATH = '/srv/linbo'

class LinboConfigManager:

    def __init__(self, school='default-school'):
        self.school = school
        self.linbo_configs = {}

        self.load_linbo_config()

    def load_linbo_config(self):
        for config in glob('/srv/linbo/start.conf.*'):
            if not os.path.islink(config):
                group = config.replace('/srv/linbo/start.conf.', '')
                try:
                    self.linbo_configs[group] = self.read_linbo_config(config)
                except TypeError as e:
                    logging.error(f"Failed to load {config}: {e}")

    def read_linbo_config(self, config):
        if not os.path.isfile(config):
            raise FileNotFoundError(f'Linbo config file not found: {config}.')

        with open(config, 'r') as f:
            kwargs = {'config': config}
            current_model = ''

            lc = LinboConfig(path=config, LINBO=None, Partitions=[], OS=[])

            for line in f:
                line = line.split('#')[0].strip()

                if line.startswith('['):
                    if current_model == 'LINBO':
                        lc.LINBO = Linbo.from_dict(kwargs)
                    elif current_model == 'Partition':
                        lc.Partitions.append(Partition.from_dict(kwargs))
                    elif current_model == 'OS':
                        lc.OS.append(OS.from_dict(kwargs))

                    kwargs = {'config': config}
                    current_model = line.strip('[]')

                elif '=' in line:
                    k, v = line.split('=', 1)
                    v = v.strip()
                    if v in ['yes', 'no']:
                        v = v == 'yes'
                    kwargs[k.strip()] = v

            return lc

    def linbo_groups(self):
        return list(self.linbo_configs.keys())

## The following functions need to be rewritten


def last_sync(workstation, image):
    """
    Get the date of the last sync date for a workstation w.

    :param w: Workstation
    :type w: string
    :param image: Name of the image file
    :type image: string
    :return: Last synchronisation time
    :rtype: datetime
    """

    statusfile = f'/var/log/linuxmuster/linbo/{workstation}_image.status'
    image_last_sync, diff_last_sync = '0','0'
    diff_image = image.replace('.qcow2', '.qdiff')

    if os.path.isfile(statusfile) and os.stat(statusfile).st_size != 0:
        for line in open(statusfile, 'r').readlines():
            if image in line:
                image_last_sync = line.rstrip().split(' ')[0]
            if diff_image in line:
                diff_last_sync = line.strip().split(' ')[0]

    last = max(image_last_sync, diff_last_sync)

    if last == '0':
        return False

    ## Linbo locale is en_GB, not necessarily the server locale
    saved = locale.setlocale(locale.LC_ALL)
    locale.setlocale(locale.LC_ALL, 'C.UTF-8')
    last = datetime.strptime(last, '%Y%m%d%H%M')
    locale.setlocale(locale.LC_ALL, saved)

    last = time.mktime(last.timetuple())
    return last

def group_os(workstations):
    """
    Get all os infos from linbo config file and inject it in workstations dict.
    The workstations dict is set in the function list_workstations().

    :param workstations: Dict containing all workstations
    :type workstations: dict
    :return: Completed workstations dict with linbo informations
    :rtype: dict
    """

    for group in workstations.keys():
        workstations[group]['os'] = []
        config = read_config(group)
        if config is not None:
            workstations[group]['power'] = {
                'run_halt': 0,
                'timeout': 1
                }
            workstations[group]['auto'] = {
                'disable_gui': 0,
                'bypass': 0,
                'wol': 0,
                'prestart': 0,
                'partition': 0,
            }
            for osConfig in config:
                if osConfig['SyncEnabled'] or osConfig['NewEnabled']:
                    tmpDict = {
                                'baseimage': osConfig['BaseImage'],
                                'partition': osConfig['Root'][-1],
                                'new_enabled': osConfig['NewEnabled'],
                                'start_enabled': osConfig['StartEnabled'],
                                'run_format': 0,
                                'run_sync':0,
                                'run_start':0,
                        }
                    workstations[group]['os'].append(tmpDict)

    return workstations

def list_workstations(school='default-school', groups=[]):
    """
    Generate a dict with workstations and parameters out of devices file

    :param context: user context set in views.py
    :return: Dict with all linbo informations for all workstations.
    :rtype: dict
    """

    devices_dict = {}
    devices_manager = Devices(school=school)
    devices = devices_manager.filter(groups=groups)

    for device in devices:
        if school != 'default-school':
            if device['hostname']:
                device['hostname'] = f'{school}-{device["hostname"]}'
        if os.path.isfile(os.path.join(LINBO_PATH, 'start.conf.'+str(device['group']))):
            if device['pxeFlag'] != '1' and device['pxeFlag'] != "2":
                continue
            elif device['group'] not in devices_dict.keys():
                devices_dict[device['group']] = {'grp': device['group'], 'hosts': [device]}
            else:
                devices_dict[device['group']]['hosts'].append(device)
    return group_os(devices_dict)

def last_sync_all(workstations):
    """
    Add last synchronisation informations into the workstations dict,
    and status attribute to use as class for bootstrap.

    :param workstations: Dict of workstations set in list_workstations().
    :type workstations: dict
    :return: Completed dict of workstations
    :rtype: dict
    """

    today = time.mktime(datetime.now().timetuple())

    for group, grpDict in sorted(workstations.items()):
            for host in grpDict['hosts']:
                host['images'] = []
                host['sync'] = {}
                for image in workstations[group]['os']:
                    last = last_sync(host['hostname'], image['baseimage'])
                    date = last if last else "Never"
                    tmpDict = {
                            'date': date,
                    }
                    if date == "Never" or (today - date > 30*24*3600):
                        tmpDict['status'] = "danger"
                    elif today - date > 7*24*3600:
                        tmpDict['status'] = "warning"
                    else:
                        tmpDict['status'] = "success"
                    host['sync'][image['baseimage']] = tmpDict
                    host['images'].append(image['baseimage'])