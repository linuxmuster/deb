from .convert import *
from .string_checker import *

Validator = StringChecker()